/*!
 Lo-Dash 0.10.0 lodash.com/license
 Underscore.js 1.4.2 underscorejs.org/LICENSE
*/
;(function(e,t){function s(e){if(e&&e.__wrapped__)return e;if(!(this instanceof s))return new s(e);this.__wrapped__=e}function o(e,t,n){t||(t=0);var r=e.length,i=r-t>=(n||Z);if(i)for(var s={},n=t-1;++n<r;){var o=e[n]+"";(bt.call(s,o)?s[o]:s[o]=[]).push(e[n])}return function(n){if(i){var r=n+"";return bt.call(s,r)&&-1<q(s[r],n)}return-1<q(e,n,t)}}function u(e){return e.charCodeAt(0)}function a(e,n){var r=e.b,i=n.b,e=e.a,n=n.a;if(e!==n){if(e>n||e===t)return 1;if(e<n||n===t)return-1}return r<i?-1:1}function f
(e,t,n){function r(){var u=arguments,a=s?this:t;return i||(e=t[o]),n.length&&(u=u.length?n.concat(St.call(u)):n),this instanceof r?(d.prototype=e.prototype,a=new d,u=e.apply(a,u),T(u)?u:a):e.apply(a,u)}var i=x(e),s=!n,o=t;return s&&(n=t),i||(t=e),r}function l(e,n){return e?"function"!=typeof e?function(t){return t[e]}:n!==t?function(t,r,i){return e.call(n,t,r,i)}:e:X}function c(){for(var e={b:"",c:"",e:qt,f:Qt,g:"",h:zt,i:Vt,j:dt,k:"",l:n},t,r=0;t=arguments[r];r++)for(var i in t)e[i]=t[i];t=e.a,e
.d=/^[^,]+/.exec(t)[0],r="var i,x,l="+e.d+",t="+e.d+";if(!"+e.d+")return t;"+e.k+";",e.b?(r+="var m=l.length;i=-1;if(typeof m=='number'){",e.i&&(r+="if(k(l)){l=l.split('')}"),r+="while(++i<m){x=l[i];"+e.b+"}}else {"):e.h&&(r+="var m=l.length;i=-1;if(m&&j(l)){while(++i<m){x=l[i+=''];"+e.g+"}}else {"),e.e||(r+="var u=typeof l=='function'&&s.call(l,'prototype');");if(e.f&&e.l)r+="var q=-1,r=p[typeof l]?n(l):[],m=r.length;while(++q<m){i=r[q];",e.e||(r+="if(!(u&&i=='prototype')){"),r+="x=l[i];"+e.g+""
,e.e||(r+="}");else{r+="for(i in l){";if(!e.e||e.l)r+="if(",e.e||(r+="!(u&&i=='prototype')"),!e.e&&e.l&&(r+="&&"),e.l&&(r+="h.call(l,i)"),r+="){";r+="x=l[i];"+e.g+";";if(!e.e||e.l)r+="}"}r+="}";if(e.e){r+="var f=l.constructor;";for(i=0;7>i;i++)r+="i='"+e.j[i]+"';if(","constructor"==e.j[i]&&(r+="!(f&&f.prototype===l)&&"),r+="h.call(l,i)){x=l[i];"+e.g+"}"}if(e.b||e.h)r+="}";return r+=e.c+";return t",Function("e,h,j,k,p,n,s","return function("+t+"){"+r+"}")(l,bt,m,N,Yt,Lt,Et)}function h(e){return"\\"+
Zt[e]}function p(e){return un[e]}function d(){}function v(e){return an[e]}function m(e){return xt.call(e)==_t}function g(e){var t=i;if(!e||"object"!=typeof e||m(e))return t;var n=e.constructor;return(!$t||"function"==typeof e.toString||"string"!=typeof (e+""))&&(!x(n)||n instanceof n)?Rt?(sn(e,function(e,n,r){return t=!bt.call(r,n),i}),t===i):(sn(e,function(e,n){t=n}),t===i||bt.call(e,t)):t}function y(e){var t=[];return on(e,function(e,n){t.push(n)}),t}function b(e,t,n,s,o){if(e==r)return e;n&&(t=
i);if(n=T(e)){var u=xt.call(e);if(!Gt[u]||Wt&&m(e))return e;var a=u==Dt,n=a||(u==jt?cn(e):n)}if(!n||!t)return n?a?St.call(e):rn({},e):e;n=e.constructor;switch(u){case Pt:case Ht:return new n(+e);case Bt:case It:return new n(e);case Ft:return n(e.source,ot.exec(e))}s||(s=[]),o||(o=[]);for(u=s.length;u--;)if(s[u]==e)return o[u];var f=a?n(e.length):{};return s.push(e),o.push(f),(a?pn:on)(e,function(e,n){f[n]=b(e,t,r,s,o)}),f}function w(e){var t=[];return sn(e,function(e,n){x(e)&&t.push(n)}),t.sort()
}function E(e){var t={};return on(e,function(e,n){t[e]=n}),t}function S(e,t,s,o){if(e===t)return 0!==e||1/e==1/t;if(e==r||t==r)return e===t;var u=xt.call(e);if(u!=xt.call(t))return i;switch(u){case Pt:case Ht:return+e==+t;case Bt:return e!=+e?t!=+t:0==e?1/e==1/t:e==+t;case Ft:case It:return e==t+""}var a=u==Dt||u==_t;if(Wt&&!a&&(a=m(e))&&!m(t))return i;if(!a){if(e.__wrapped__||t.__wrapped__)return S(e.__wrapped__||e,t.__wrapped__||t);if(u!=jt||$t&&("function"!=typeof e.toString&&"string"==typeof 
(e+"")||"function"!=typeof t.toString&&"string"==typeof (t+"")))return i;var u=e.constructor,f=t.constructor;if(u!=f&&(!x(u)||!(u instanceof u&&x(f)&&f instanceof f)))return i}s||(s=[]),o||(o=[]);for(u=s.length;u--;)if(s[u]==e)return o[u]==t;var u=-1,f=n,l=0;s.push(e),o.push(t);if(a){l=e.length;if(f=l==t.length)for(;l--&&(f=S(e[l],t[l],s,o)););return f}for(var c in e)if(bt.call(e,c)&&(l++,!bt.call(t,c)||!S(e[c],t[c],s,o)))return i;for(c in t)if(bt.call(t,c)&&!(l--))return i;if(qt)for(;7>++u;)if(c=
dt[u],bt.call(e,c)&&(!bt.call(t,c)||!S(e[c],t[c],s,o)))return i;return n}function x(e){return"function"==typeof e}function T(e){return e?Yt[typeof e]:i}function N(e){return xt.call(e)==It}function C(e,t,n){var i=arguments,s=0,o=2,u=i[3],a=i[4];n!==Y&&(u=[],a=[],"number"!=typeof n&&(o=i.length));for(;++s<o;)on(i[s],function(t,n){var i,s,o;if(t&&((s=ln(t))||cn(t))){for(var f=u.length;f--;)if(i=u[f]==t)break;i?e[n]=a[f]:(u.push(t),a.push(o=(o=e[n],s)?ln(o)?o:[]:cn(o)?o:{}),e[n]=C(o,t,Y,u,a))}else t!=
r&&(e[n]=t)});return e}function k(e){var t=[];return on(e,function(e){t.push(e)}),t}function L(e,t,n){var r=-1,s=e?e.length:0,o=i,n=(0>n?At(0,s+n):n)||0;return"number"==typeof s?o=-1<(N(e)?e.indexOf(t,n):q(e,t,n)):pn(e,function(e){if(++r>=n)return!(o=e===t)}),o}function A(e,t,r){var i=n,t=l(t,r);if(ln(e))for(var r=-1,s=e.length;++r<s&&(i=!!t(e[r],r,e)););else pn(e,function(e,n,r){return i=!!t(e,n,r)});return i}function O(e,t,n){var r=[],t=l(t,n);if(ln(e))for(var n=-1,i=e.length;++n<i;){var s=e[n]
;t(s,n,e)&&r.push(s)}else pn(e,function(e,n,i){t(e,n,i)&&r.push(e)});return r}function M(e,t,n){var r,t=l(t,n);return pn(e,function(e,n,s){if(t(e,n,s))return r=e,i}),r}function _(e,t,n){var r=-1,i=e?e.length:0,s=Array("number"==typeof i?i:0),t=l(t,n);if(ln(e))for(;++r<i;)s[r]=t(e[r],r,e);else pn(e,function(e,n,i){s[++r]=t(e,n,i)});return s}function D(e,t,n){var r=-Infinity,i=-1,s=e?e.length:0,o=r;if(t||!ln(e))t=!t&&N(e)?u:l(t,n),pn(e,function(e,n,i){n=t(e,n,i),n>r&&(r=n,o=e)});else for(;++i<s;)e[
i]>o&&(o=e[i]);return o}function P(e,t){var n=[];return pn(e,function(e){n.push(e[t])}),n}function H(e,t,n,r){var s=3>arguments.length,t=l(t,r);return pn(e,function(e,r,o){n=s?(s=i,e):t(n,e,r,o)}),n}function B(e,t,n,r){var s=e,o=e?e.length:0,u=3>arguments.length;if("number"!=typeof o)var a=hn(e),o=a.length;else Vt&&N(e)&&(s=e.split(""));return pn(e,function(e,f,l){f=a?a[--o]:--o,n=u?(u=i,s[f]):t.call(r,n,s[f],f,l)}),n}function j(e,t,n){var r,t=l(t,n);if(ln(e))for(var n=-1,i=e.length;++n<i&&!(r=t(
e[n],n,e)););else pn(e,function(e,n,i){return!(r=t(e,n,i))});return!!r}function F(e,t,n){if(e)return t==r||n?e[0]:St.call(e,0,t)}function I(e,t){for(var n=-1,r=e?e.length:0,i=[];++n<r;){var s=e[n];ln(s)?wt.apply(i,t?s:I(s)):i.push(s)}return i}function q(e,t,n){var r=-1,i=e?e.length:0;if("number"==typeof n)r=(0>n?At(0,i+n):n||0)-1;else if(n)return r=U(e,t),e[r]===t?r:-1;for(;++r<i;)if(e[r]===t)return r;return-1}function R(e,t,n){return e?St.call(e,t==r||n?1:t):[]}function U(e,t,n,r){for(var i=0,s=
e?e.length:i,n=n?l(n,r):X,t=n(t);i<s;)r=i+s>>>1,n(e[r])<t?i=r+1:s=r;return i}function z(e,t,n,r){var s=-1,o=e?e.length:0,u=[],a=u;"function"==typeof t&&(r=n,n=t,t=i);var f=!t&&74<o;if(f)var c={};n&&(a=[],n=l(n,r));for(;++s<o;){var r=e[s],h=n?n(r,s,e):r;f&&(a=bt.call(c,h+"")?c[h]:c[h]=[]);if(t?!s||a[a.length-1]!==h:0>q(a,h))(n||f)&&a.push(h),u.push(r)}return u}function W(e,t){return Kt||Tt&&2<arguments.length?Tt.call.apply(Tt,arguments):f(e,t,St.call(arguments,2))}function X(e){return e}function V
(e){pn(w(e),function(t){var r=s[t]=e[t];s.prototype[t]=function(){var e=[this.__wrapped__];return wt.apply(e,arguments),e=r.apply(s,e),this.__chain__&&(e=new s(e),e.__chain__=n),e}})}var n=!0,r=null,i=!1,$="object"==typeof exports&&exports,J="object"==typeof global&&global;J.global===J&&(e=J);var K=[],Q=new function(){},G=0,Y=Q,Z=30,et=e._,tt=/[-?+=!~*%&^<>|{(\/]|\[\D|\b(?:delete|in|instanceof|new|typeof|void)\b/,nt=/&(?:amp|lt|gt|quot|#x27);/g,rt=/\b__p\+='';/g,it=/\b(__p\+=)''\+/g,st=/(__e\(.*?\)|\b__t\))\+'';/g
,ot=/\w*$/,ut=/(?:__e|__t=)\(\s*(?![\d\s"']|this\.)/g,at=RegExp("^"+(Q.valueOf+"").replace(/[.*+?^=!:${}()|[\]\/\\]/g,"\\$&").replace(/valueOf|for [^\]]+/g,".+?")+"$"),ft=/\$\{((?:(?=\\?)\\?[\s\S])*?)}/g,lt=/<%=([\s\S]+?)%>/g,ct=/($^)/,ht=/[&<>"']/g,pt=/['\n\r\t\u2028\u2029\\]/g,dt="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" "),vt=Math.ceil,mt=K.concat,gt=Math.floor,yt=at.test(yt=Object.getPrototypeOf)&&yt,bt=Q.hasOwnProperty,wt=K.push,Et=
Q.propertyIsEnumerable,St=K.slice,xt=Q.toString,Tt=at.test(Tt=St.bind)&&Tt,Nt=at.test(Nt=Array.isArray)&&Nt,Ct=e.isFinite,kt=e.isNaN,Lt=at.test(Lt=Object.keys)&&Lt,At=Math.max,Ot=Math.min,Mt=Math.random,_t="[object Arguments]",Dt="[object Array]",Pt="[object Boolean]",Ht="[object Date]",Bt="[object Number]",jt="[object Object]",Ft="[object RegExp]",It="[object String]",qt,Rt,Ut=(Ut={0:1,length:1},K.splice.call(Ut,0,1),Ut[0]),zt=n;(function(){function e(){this.x=1}var t=[];e.prototype={valueOf:1,y
:1};for(var n in new e)t.push(n);for(n in arguments)zt=!n;qt=!/valueOf/.test(t),Rt="x"!=t[0]})(1);var Wt=!m(arguments),Xt="x"!=St.call("x")[0],Vt="xx"!="x"[0]+Object("x")[0];try{var $t=("[object Object]",xt.call(e.document||0)==jt)}catch(Jt){}var Kt=Tt&&/\n|Opera/.test(Tt+xt.call(e.opera)),Qt=Lt&&/^.+$|true/.test(Lt+!!e.attachEvent),Gt={};Gt[_t]=Gt["[object Function]"]=i,Gt[Dt]=Gt[Pt]=Gt[Ht]=Gt[Bt]=Gt[jt]=Gt[Ft]=Gt[It]=n;var Yt={"boolean":i,"function":n,object:n,number:i,string:i,"undefined":i},Zt=
{"\\":"\\","'":"'","\n":"n","\r":"r","	":"t","\u2028":"u2028","\u2029":"u2029"};s.templateSettings={escape:/<%-([\s\S]+?)%>/g,evaluate:/<%([\s\S]+?)%>/g,interpolate:lt,variable:""};var en={a:"o,v,g",k:"for(var a=1,b=typeof g=='number'?2:arguments.length;a<b;a++){if((l=arguments[a])){",g:"t[i]=x",c:"}}"},tn={a:"d,c,w",k:"c=e(c,w)",b:"if(c(x,i,d)===false)return t",g:"if(c(x,i,d)===false)return t"},nn={b:r},rn=c(en);Wt&&(m=function(e){return e?bt.call(e,"callee"):i});var sn=c(tn,nn,{l:i}),on=c(tn,nn
),un={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#x27;"},an=E(un),fn=c(en,{g:"if(t[i]==null)"+en.g}),ln=Nt||function(e){return xt.call(e)==Dt};x(/x/)&&(x=function(e){return"[object Function]"==xt.call(e)});var cn=yt?function(e){if(!e||"object"!=typeof e)return i;var t=e.valueOf,n="function"==typeof t&&(n=yt(t))&&yt(n);return n?e==n||yt(e)==n&&!m(e):g(e)}:g,hn=Lt?function(e){return"function"==typeof e&&Et.call(e,"prototype")?y(e):T(e)?Lt(e):[]}:y,pn=c(tn);s.VERSION="0.10.0",s.assign=rn,s
.after=function(e,t){return 1>e?t():function(){if(1>--e)return t.apply(this,arguments)}},s.bind=W,s.bindAll=function(e){for(var t=arguments,n=1<t.length?0:(t=w(e),-1),r=t.length;++n<r;){var i=t[n];e[i]=W(e[i],e)}return e},s.bindKey=function(e,t){return f(e,t,St.call(arguments,2))},s.chain=function(e){return e=new s(e),e.__chain__=n,e},s.clone=b,s.compact=function(e){for(var t=-1,n=e?e.length:0,r=[];++t<n;){var i=e[t];i&&r.push(i)}return r},s.compose=function(){var e=arguments;return function(){for(
var t=arguments,n=e.length;n--;)t=[e[n].apply(this,t)];return t[0]}},s.contains=L,s.countBy=function(e,t,n){var r={},t=l(t,n);return pn(e,function(e,n,i){n=t(e,n,i),bt.call(r,n)?r[n]++:r[n]=1}),r},s.debounce=function(e,t,n){function i(){a=r,n||(o=e.apply(u,s))}var s,o,u,a;return function(){var r=n&&!a;return s=arguments,u=this,clearTimeout(a),a=setTimeout(i,t),r&&(o=e.apply(u,s)),o}},s.defaults=fn,s.defer=function(e){var n=St.call(arguments,1);return setTimeout(function(){e.apply(t,n)},1)},s.delay=
function(e,n){var r=St.call(arguments,2);return setTimeout(function(){e.apply(t,r)},n)},s.difference=function(e){for(var t=-1,n=e?e.length:0,r=mt.apply(K,arguments),r=o(r,n),i=[];++t<n;){var s=e[t];r(s)||i.push(s)}return i},s.escape=function(e){return e==r?"":(e+"").replace(ht,p)},s.every=A,s.filter=O,s.find=M,s.first=F,s.flatten=I,s.forEach=pn,s.forIn=sn,s.forOwn=on,s.functions=w,s.groupBy=function(e,t,n){var r={},t=l(t,n);return pn(e,function(e,n,i){n=t(e,n,i),(bt.call(r,n)?r[n]:r[n]=[]).push(e
)}),r},s.has=function(e,t){return e?bt.call(e,t):i},s.identity=X,s.indexOf=q,s.initial=function(e,t,n){return e?St.call(e,0,-(t==r||n?1:t)):[]},s.intersection=function(e){var t=arguments,n=t.length,r={},i=[];return pn(e,function(e){if(0>q(i,e)){for(var s=n;--s;)if(!(r[s]||(r[s]=o(t[s])))(e))return;i.push(e)}}),i},s.invert=E,s.invoke=function(e,t){var n=St.call(arguments,2),r="function"==typeof t,i=[];return pn(e,function(e){i.push((r?t:e[t]).apply(e,n))}),i},s.isArguments=m,s.isArray=ln,s.isBoolean=
function(e){return e===n||e===i||xt.call(e)==Pt},s.isDate=function(e){return xt.call(e)==Ht},s.isElement=function(e){return e?1===e.nodeType:i},s.isEmpty=function(e){var t=n;if(!e)return t;var r=xt.call(e),s=e.length;return r==Dt||r==It||r==_t||Wt&&m(e)||r==jt&&"number"==typeof s&&x(e.splice)?!s:(on(e,function(){return t=i}),t)},s.isEqual=S,s.isFinite=function(e){return Ct(e)&&!kt(parseFloat(e))},s.isFunction=x,s.isNaN=function(e){return xt.call(e)==Bt&&e!=+e},s.isNull=function(e){return e===r},s
.isNumber=function(e){return xt.call(e)==Bt},s.isObject=T,s.isPlainObject=cn,s.isRegExp=function(e){return xt.call(e)==Ft},s.isString=N,s.isUndefined=function(e){return e===t},s.keys=hn,s.last=function(e,t,n){if(e){var i=e.length;return t==r||n?e[i-1]:St.call(e,-t||i)}},s.lastIndexOf=function(e,t,n){var r=e?e.length:0;for("number"==typeof n&&(r=(0>n?At(0,r+n):Ot(n,r-1))+1);r--;)if(e[r]===t)return r;return-1},s.map=_,s.max=D,s.memoize=function(e,t){var n={};return function(){var r=t?t.apply(this,arguments
):arguments[0];return bt.call(n,r)?n[r]:n[r]=e.apply(this,arguments)}},s.merge=C,s.min=function(e,t,n){var r=Infinity,i=-1,s=e?e.length:0,o=r;if(t||!ln(e))t=!t&&N(e)?u:l(t,n),pn(e,function(e,n,i){n=t(e,n,i),n<r&&(r=n,o=e)});else for(;++i<s;)e[i]<o&&(o=e[i]);return o},s.mixin=V,s.noConflict=function(){return e._=et,this},s.object=function(e,t){for(var n=-1,r=e?e.length:0,i={};++n<r;){var s=e[n];t?i[s]=t[n]:i[s[0]]=s[1]}return i},s.omit=function(e,t,n){var r="function"==typeof t,i={};if(r)t=l(t,n);
else var s=mt.apply(K,arguments);return sn(e,function(e,n,o){if(r?!t(e,n,o):0>q(s,n,1))i[n]=e}),i},s.once=function(e){var t,s=i;return function(){return s?t:(s=n,t=e.apply(this,arguments),e=r,t)}},s.pairs=function(e){var t=[];return on(e,function(e,n){t.push([n,e])}),t},s.partial=function(e){return f(e,St.call(arguments,1))},s.pick=function(e,t,n){var r={};if("function"!=typeof t)for(var i=0,s=mt.apply(K,arguments),o=s.length;++i<o;){var u=s[i];u in e&&(r[u]=e[u])}else t=l(t,n),sn(e,function(e,n,
i){t(e,n,i)&&(r[n]=e)});return r},s.pluck=P,s.random=function(e,t){return e==r&&t==r&&(t=1),e=+e||0,t==r&&(t=e,e=0),e+gt(Mt()*((+t||0)-e+1))},s.range=function(e,t,n){e=+e||0,n=+n||1,t==r&&(t=e,e=0);for(var i=-1,t=At(0,vt((t-e)/n)),s=Array(t);++i<t;)s[i]=e,e+=n;return s},s.reduce=H,s.reduceRight=B,s.reject=function(e,t,n){return t=l(t,n),O(e,function(e,n,r){return!t(e,n,r)})},s.rest=R,s.result=function(e,t){var n=e?e[t]:r;return x(n)?e[t]():n},s.shuffle=function(e){var t=-1,n=Array(e?e.length:0);return pn
(e,function(e){var r=gt(Mt()*(++t+1));n[t]=n[r],n[r]=e}),n},s.size=function(e){var t=e?e.length:0;return"number"==typeof t?t:hn(e).length},s.some=j,s.sortBy=function(e,t,n){var r=[],t=l(t,n);pn(e,function(e,n,i){r.push({a:t(e,n,i),b:n,c:e})}),e=r.length;for(r.sort(a);e--;)r[e]=r[e].c;return r},s.sortedIndex=U,s.tap=function(e,t){return t(e),e},s.template=function(e,t,n){e||(e=""),n||(n={});var r,i,o=s.templateSettings,u=0,a=n.interpolate||o.interpolate||ct,f="__p += '",l=n.variable||o.variable,c=
l;e.replace(RegExp((n.escape||o.escape||ct).source+"|"+a.source+"|"+(a===lt?ft:ct).source+"|"+(n.evaluate||o.evaluate||ct).source+"|$","g"),function(t,n,i,s,o,a){i||(i=s),f+=e.slice(u,a).replace(pt,h),f+=n?"'+__e("+n+")+'":o?"';"+o+";__p+='":i?"'+((__t=("+i+"))==null?'':__t)+'":"",r||(r=o||tt.test(n||i)),u=a+t.length}),f+="';",c||(l="obj",r?f="with("+l+"){"+f+"}":(n=RegExp("(\\(\\s*)"+l+"\\."+l+"\\b","g"),f=f.replace(ut,"$&"+l+".").replace(n,"$1__d"))),f=(r?f.replace(rt,""):f).replace(it,"$1").replace
(st,"$1;"),f="function("+l+"){"+(c?"":l+"||("+l+"={});")+"var __t,__p='',__e=_.escape"+(r?",__j=Array.prototype.join;function print(){__p+=__j.call(arguments,'')}":(c?"":",__d="+l+"."+l+"||"+l)+";")+f+"return __p}";try{i=Function("_","return "+f)(s)}catch(p){throw p.source=f,p}return t?i(t):(i.source=f,i)},s.throttle=function(e,t){function n(){a=new Date,u=r,s=e.apply(o,i)}var i,s,o,u,a=0;return function(){var r=new Date,f=t-(r-a);return i=arguments,o=this,0>=f?(clearTimeout(u),a=r,s=e.apply(o,i)
):u||(u=setTimeout(n,f)),s}},s.times=function(e,t,n){for(var e=+e||0,r=-1,i=Array(e);++r<e;)i[r]=t.call(n,r);return i},s.toArray=function(e){return e&&"number"==typeof e.length?(Xt?N(e):"string"==typeof e)?e.split(""):St.call(e):k(e)},s.unescape=function(e){return e==r?"":(e+"").replace(nt,v)},s.union=function(){return z(mt.apply(K,arguments))},s.uniq=z,s.uniqueId=function(e){var t=G++;return e?e+t:t},s.values=k,s.where=function(e,t){var n=hn(t);return O(e,function(e){for(var r=n.length;r--;){var i=
e[n[r]]===t[n[r]];if(!i)break}return!!i})},s.without=function(e){for(var t=-1,n=e?e.length:0,r=o(arguments,1,20),i=[];++t<n;){var s=e[t];r(s)||i.push(s)}return i},s.wrap=function(e,t){return function(){var n=[e];return wt.apply(n,arguments),t.apply(this,n)}},s.zip=function(e){for(var t=-1,n=e?D(P(arguments,"length")):0,r=Array(n);++t<n;)r[t]=P(arguments,t);return r},s.all=A,s.any=j,s.collect=_,s.detect=M,s.drop=R,s.each=pn,s.extend=rn,s.foldl=H,s.foldr=B,s.head=F,s.include=L,s.inject=H,s.methods=
w,s.select=O,s.tail=R,s.take=F,s.unique=z,V(s),s.prototype.chain=function(){return this.__chain__=n,this},s.prototype.value=function(){return this.__wrapped__},pn("pop push reverse shift sort splice unshift".split(" "),function(e){var t=K[e];s.prototype[e]=function(){var e=this.__wrapped__;return t.apply(e,arguments),Ut&&e.length===0&&delete e[0],this.__chain__&&(e=new s(e),e.__chain__=n),e}}),pn(["concat","join","slice"],function(e){var t=K[e];s.prototype[e]=function(){var e=t.apply(this.__wrapped__
,arguments);return this.__chain__&&(e=new s(e),e.__chain__=n),e}}),typeof define=="function"&&typeof define.amd=="object"&&define.amd?(e._=s,define(function(){return s})):$?"object"==typeof module&&module&&module.exports==$?(module.exports=s)._=s:$._=s:e._=s})(this);

window.theme = window.theme || {};

/* ================ SLATE ================ */
window.theme = window.theme || {};

theme.Sections = function Sections() {
  this.constructors = {};
  this.instances = [];

  $(document)
    .on('shopify:section:load', this._onSectionLoad.bind(this))
    .on('shopify:section:unload', this._onSectionUnload.bind(this))
    .on('shopify:section:select', this._onSelect.bind(this))
    .on('shopify:section:deselect', this._onDeselect.bind(this))
    .on('shopify:block:select', this._onBlockSelect.bind(this))
    .on('shopify:block:deselect', this._onBlockDeselect.bind(this));
};

theme.Sections.prototype = _.assignIn({}, theme.Sections.prototype, {
  _createInstance: function(container, constructor) {
    var $container = $(container);
    var id = $container.attr('data-section-id');
    var type = $container.attr('data-section-type');

    constructor = constructor || this.constructors[type];

    if (_.isUndefined(constructor)) {
      return;
    }

    var instance = _.assignIn(new constructor(container), {
      id: id,
      type: type,
      container: container
    });

    this.instances.push(instance);
  },

  _onSectionLoad: function(evt) {
    var container = $('[data-section-id]', evt.target)[0];
    if (container) {
      this._createInstance(container);
    }
  },

  _onSectionUnload: function(evt) {
    this.instances = _.filter(this.instances, function(instance) {
      var isEventInstance = (instance.id === evt.detail.sectionId);

      if (isEventInstance) {
        if (_.isFunction(instance.onUnload)) {
          instance.onUnload(evt);
        }
      }

      return !isEventInstance;
    });
  },

  _onSelect: function(evt) {
    // eslint-disable-next-line no-shadow
    var instance = _.find(this.instances, function(instance) {
      return instance.id === evt.detail.sectionId;
    });

    if (!_.isUndefined(instance) && _.isFunction(instance.onSelect)) {
      instance.onSelect(evt);
    }
  },

  _onDeselect: function(evt) {
    // eslint-disable-next-line no-shadow
    var instance = _.find(this.instances, function(instance) {
      return instance.id === evt.detail.sectionId;
    });

    if (!_.isUndefined(instance) && _.isFunction(instance.onDeselect)) {
      instance.onDeselect(evt);
    }
  },

  _onBlockSelect: function(evt) {
    // eslint-disable-next-line no-shadow
    var instance = _.find(this.instances, function(instance) {
      return instance.id === evt.detail.sectionId;
    });

    if (!_.isUndefined(instance) && _.isFunction(instance.onBlockSelect)) {
      instance.onBlockSelect(evt);
    }
  },

  _onBlockDeselect: function(evt) {
    // eslint-disable-next-line no-shadow
    var instance = _.find(this.instances, function(instance) {
      return instance.id === evt.detail.sectionId;
    });

    if (!_.isUndefined(instance) && _.isFunction(instance.onBlockDeselect)) {
      instance.onBlockDeselect(evt);
    }
  },

  register: function(type, constructor) {
    this.constructors[type] = constructor;

    $('[data-section-type=' + type + ']').each(function(index, container) {
      this._createInstance(container, constructor);
    }.bind(this));
  }
});

/* ================ MODULES ================ */
/*============================================================================
  Money Format
  - Shopify.format money is defined in option_selection.js.
    If that file is not included, it is redefined here.
==============================================================================*/
if ((typeof Shopify) === 'undefined') { Shopify = {}; }
if (!Shopify.formatMoney) {
  Shopify.formatMoney = function(cents, format) {
    var value = '',
        placeholderRegex = /\{\{\s*(\w+)\s*\}\}/,
        formatString = (format || this.money_format);

    if (typeof cents == 'string') {
      cents = cents.replace('.','');
    }

    function defaultOption(opt, def) {
      return (typeof opt == 'undefined' ? def : opt);
    }

    function formatWithDelimiters(number, precision, thousands, decimal) {
      precision = defaultOption(precision, 2);
      thousands = defaultOption(thousands, ',');
      decimal   = defaultOption(decimal, '.');

      if (isNaN(number) || number == null) {
        return 0;
      }

      number = (number/100.0).toFixed(precision);

      var parts   = number.split('.'),
          dollars = parts[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, '$1' + thousands),
          cents   = parts[1] ? (decimal + parts[1]) : '';

      return dollars + cents;
    }

    switch(formatString.match(placeholderRegex)[1]) {
      case 'amount':
        value = formatWithDelimiters(cents, 2);
        break;
      case 'amount_no_decimals':
        value = formatWithDelimiters(cents, 0);
        break;
      case 'amount_with_comma_separator':
        value = formatWithDelimiters(cents, 2, '.', ',');
        break;
      case 'amount_no_decimals_with_comma_separator':
        value = formatWithDelimiters(cents, 0, '.', ',');
        break;
    }

    return formatString.replace(placeholderRegex, value);
  };
}

// Timber functions
window.timber = window.timber || {};

timber.cacheSelectors = function () {
  timber.cache = {
    // General
    $window                  : $(window),
    $html                    : $('html'),
    $body                    : $('body'),

    // Navigation
    $navigation              : $('#AccessibleNav'),
    $navBar                  : $('.nav-bar'),
    $mobileSubNavToggle      : $('.mobile-nav__toggle'),
    $header                  : $('.site-header'),

    // Collection Pages
    $changeView              : $('.change-view'),

    // Product Page
    $productImage            : $('#ProductPhotoImg'),
    $thumbImages             : $('#ProductThumbs').find('a.product-single__thumbnail'),

    // Cart Page
    $cartSection             : $('#CartSection'),
    cartNoCookies            : 'cart--no-cookies',

    // Customer Pages
    $recoverPasswordLink     : $('#RecoverPassword'),
    $hideRecoverPasswordLink : $('#HideRecoverPasswordLink'),
    $recoverPasswordForm     : $('#RecoverPasswordForm'),
    $customerLoginForm       : $('#CustomerLoginForm'),
    $passwordResetSuccess    : $('#ResetSuccess')
  };
};

timber.init = function () {
  timber.cacheSelectors();
  timber.accessibleNav();
  timber.openDrawerMenu();
  timber.closeDrawerMenu();
  timber.drawersInit();
  timber.cartInit();
  timber.mobileNavToggle();
  timber.productImageSwitch();
  timber.collectionViews();
  timber.loginForms();
};

timber.accessibleNav = function () {
  var $nav = timber.cache.$navigation,
      $allLinks = $nav.find('a'),
      $topLevel = $nav.children('li').find('a'),
      $parents = $nav.find('.site-nav--has-dropdown'),
      $subMenuLinks = $nav.find('.site-nav_menudrop').find('a'),
      activeClass = 'nav-hover',
      focusClass = 'nav-focus';

  // Mouseenter
  $parents.on('mouseenter touchstart', function(evt) {
    var $el = $(this);

    if (!$el.hasClass(activeClass)) {
      evt.preventDefault();
    }

    showDropdown($el);
  });

  // Mouseout
  $parents.on('mouseleave', function() {
    hideDropdown($(this));
  });

  $subMenuLinks.on('touchstart', function(evt) {
    // Prevent touchstart on body from firing instead of link
    evt.stopImmediatePropagation();
  });

  $allLinks.focus(function() {
    handleFocus($(this));
  });

  $allLinks.blur(function() {
    removeFocus($topLevel);
  });

  $allLinks.click(function() {
    timber.closeDrawerMenu();
  });

  // accessibleNav private methods
  function handleFocus ($el) {
    var $subMenu = $el.next('ul'),
        hasSubMenu = $subMenu.hasClass('sub-nav') ? true : false,
        isSubItem = $('.site-nav_menudrop').has($el).length,
        $newFocus = null;

    // Add focus class for top level items, or keep menu shown
    if (!isSubItem) {
      removeFocus($topLevel);
      addFocus($el);
    } else {
      $newFocus = $el.closest('.site-nav--has-dropdown').find('a');
      addFocus($newFocus);
    }
  }

  function showDropdown ($el) {
    $el.addClass(activeClass);

    setTimeout(function() {
      timber.cache.$body.on('touchstart', function() {
        hideDropdown($el);
      });
    }, 250);
  }

  function hideDropdown ($el) {
    $el.removeClass(activeClass);
    timber.cache.$body.off('touchstart');
  }

  function addFocus ($el) {
    $el.addClass(focusClass);
  }

  function removeFocus ($el) {
    $el.removeClass(focusClass);
  }
};

timber.openDrawerMenu = function () {
  var $mobileMenu = $('.nav-bar'),
      $mobileMenuButton = $('#menu-opener'),
      $body = $('body');
      $mobileMenuButton.addClass('opened');
      $mobileMenu.addClass('opened');
      $body.addClass('opened-drawer');

  // Make drawer a11y accessible
  timber.cache.$navBar.attr('aria-hidden', 'false');

  // Set focus on drawer
  timber.trapFocus({
     $container: timber.cache.$navBar,
     namespace: 'drawer_focus'
  });

  // Escape key closes menu
  timber.cache.$html.on('keyup.drawerMenu', function(evt) {
    if (evt.keyCode == 27) {
      timber.closeDrawerMenu();
    }
  });
}

timber.closeDrawerMenu = function () {

  var $mobileMenu = $('.nav-bar'),
      $mobileMenuButton = $('#menu-opener'),
      $body = $('body');

  $mobileMenuButton.removeClass('opened');
  $mobileMenu.removeClass('opened');
  $body.removeClass('opened-drawer');

  // Make drawer a11y unaccessible
  timber.cache.$navBar.attr('aria-hidden', 'true');

  // Remove focus on drawer
  timber.removeTrapFocus({
    $container: timber.cache.$navBar,
    namespace: 'drawer_focus'
  });

  timber.cache.$html.off('keyup.drawerMenu');
}

timber.drawersInit = function () {
  timber.LeftDrawer = new timber.Drawers('NavDrawer', 'left');
  timber.RightDrawer = new timber.Drawers('CartDrawer', 'right', {
     'onDrawerOpen': theme.settings.ajax_cart_enable
  });
};

timber.cartInit = function() {
  if (!timber.cookiesEnabled()) {
    timber.cache.$cartSection.addClass(timber.cache.cartNoCookies);
  }
};

timber.cookiesEnabled = function() {
  var cookieEnabled = navigator.cookieEnabled;

  if (!cookieEnabled){
    document.cookie = 'testcookie';
    cookieEnabled = (document.cookie.indexOf('testcookie') !== -1);
  }
  return cookieEnabled;
};

timber.mobileNavToggle = function () {
  timber.cache.$mobileSubNavToggle.on('click', function() {
    $(this).parent().toggleClass('mobile-nav--expanded');
  });
};

/**
 * Traps the focus in a particular container
 *
* @param {object} options - Options to be used
* @param {jQuery} options.$container - Container to trap focus within
* @param {jQuery} options.$elementToFocus - Element to be focused when focus leaves container
* @param {string} options.namespace - Namespace used for new focus event handler
*/
timber.trapFocus = function (options) {
  var eventName = options.eventNamespace
    ? 'focusin.' + eventNamespace
    : 'focusin';

  if (!options.$elementToFocus) {
    options.$elementToFocus = options.$container;
    options.$container.attr('tabindex', '-1');
  }

  options.$elementToFocus.focus();

  $(document).on(eventName, function (evt) {
    if (options.$container[0] !== evt.target && !options.$container.has(evt.target).length) {
      options.$container.focus();
    }
  });
};

/**
 * Removes the trap of focus in a particular container
 *
 * @param {object} options - Options to be used
 * @param {jQuery} options.$container - Container to trap focus within
 * @param {string} options.namespace - Namespace used for new focus event handler
 */
timber.removeTrapFocus = function (options) {
  var eventName = options.namespace
    ? 'focusin.' + options.namespace
    : 'focusin';

  if (options.$container && options.$container.length) {
    options.$container.removeAttr('tabindex');
  }

  $(document).off(eventName);
};

timber.getHash = function () {
  return window.location.hash;
};

timber.updateHash = function (hash) {
  window.location.hash = '#' + hash;
  $('#' + hash).attr('tabindex', -1).focus();
};

timber.productPage = function (options) {
  var moneyFormat = options.money_format,
      variant = options.variant,
      selector = options.selector;

  // Selectors
  var $productImage = $('#ProductPhotoImg'),
      $addToCart = $('#AddToCart'),
      $productPrice = $('#ProductPrice'),
      $comparePrice = $('#ComparePrice'),
      $quantityElements = $('.quantity-selector, label + .js-qty'),
      $addToCartText = $('#AddToCartText');

  if (variant) {

    // Update variant image, if one is set
    if (variant.featured_image) {
      var newImg = variant.featured_image,
          el = $productImage[0];
      Shopify.Image.switchImage(newImg, el, timber.switchImage);
    }

    // Select a valid variant if available
    if (variant.available) {
      // Available, enable the submit button, change text, show quantity elements
      $addToCart.removeClass('disabled').prop('disabled', false);
      $addToCartText.html(theme.strings.add_to_cart);
      $quantityElements.show();
    } else {
      // Sold out, disable the submit button, change text, hide quantity elements
      $addToCart.addClass('disabled').prop('disabled', true);
      $addToCartText.html(theme.strings.sold_out);
      $quantityElements.hide();
    }

    // Regardless of stock, update the product price
    $productPrice.html( Shopify.formatMoney(variant.price, moneyFormat) );

    // Also update and show the product's compare price if necessary
    if (variant.compare_at_price > variant.price) {
      $comparePrice
        .html(Shopify.formatMoney(variant.compare_at_price, moneyFormat))
        .show();
    } else {
      $comparePrice.hide();
    }

  } else {
    // The variant doesn't exist, disable submit button.
    // This may be an error or notice that a specific variant is not available.
    // To only show available variants, implement linked product options:
    //   - http://docs.shopify.com/manual/configuration/store-customization/advanced-navigation/linked-product-options
    $addToCart.addClass('disabled').prop('disabled', true);
    $addToCartText.html(theme.strings.unavailable);
    $quantityElements.hide();
  }
};

timber.productImageSwitch = function () {
  if (timber.cache.$thumbImages.length) {
    // Switch the main image with one of the thumbnails
    // Note: this does not change the variant selected, just the image
    timber.cache.$thumbImages.on('click', function(evt) {
      evt.preventDefault();
      var newImage = $(this).attr('href');
      timber.switchImage(newImage, null, timber.cache.$productImage);
    });
  }
};

timber.switchImage = function (src, imgObject, el) {
  // Make sure element is a jquery object
  var $el = $(el);
  $el.attr('src', src);
};

timber.collectionViews = function () {
  if (timber.cache.$changeView.length) {
    timber.cache.$changeView.on('click', function() {
      var view = $(this).data('view'),
          url = document.URL,
          hasParams = url.indexOf('?') > -1;

      if (hasParams) {
        window.location = replaceUrlParam(url, 'view', view);
      } else {
        window.location = url + '?view=' + view;
      }
    });
  }
};

timber.loginForms = function() {
  function showRecoverPasswordForm() {
    timber.cache.$recoverPasswordForm.show();
    timber.cache.$customerLoginForm.hide();
  }

  function hideRecoverPasswordForm() {
    timber.cache.$recoverPasswordForm.hide();
    timber.cache.$customerLoginForm.show();
  }

  timber.cache.$recoverPasswordLink.on('click', function(evt) {
    evt.preventDefault();
    showRecoverPasswordForm();
  });

  timber.cache.$hideRecoverPasswordLink.on('click', function(evt) {
    evt.preventDefault();
    hideRecoverPasswordForm();
  });

  // Allow deep linking to recover password form
  if (timber.getHash() == '#recover') {
    showRecoverPasswordForm();
  }
};

timber.resetPasswordSuccess = function() {
  timber.cache.$passwordResetSuccess.show();
};

/*============================================================================
  Drawer modules
  - Docs http://shopify.github.io/Timber/#drawers
==============================================================================*/
timber.Drawers = (function () {
  var Drawer = function (id, position, options) {
    var defaults = {
      close: '.js-drawer-close',
      open: '.js-drawer-open-' + position,
      openClass: 'js-drawer-open',
      dirOpenClass: 'js-drawer-open-' + position
    };

    this.$nodes = {
      parent: $('body, html'),
      page: $('#PageContainer'),
      moved: $('.is-moved-by-drawer')
    };

    this.config = $.extend(defaults, options);
    this.position = position;

    this.$drawer = $('#' + id);

    if (!this.$drawer.length) {
      return false;
    }

    this.drawerIsOpen = false;
    this.init();
  };

  Drawer.prototype.init = function () {
    $(this.config.open).on('click', $.proxy(this.open, this));
    this.$drawer.find(this.config.close).on('click', $.proxy(this.close, this));
  };

  Drawer.prototype.open = function (evt) {
    // Keep track if drawer was opened from a click, or called by another function
    var externalCall = false;

    // Prevent following href if link is clicked
    if (evt) {
      evt.preventDefault();
    } else {
      externalCall = true;
    }

    // Without this, the drawer opens, the click event bubbles up to $nodes.page
    // which closes the drawer.
    if (evt && evt.stopPropagation) {
      evt.stopPropagation();
      // save the source of the click, we'll focus to this on close
      this.$activeSource = $(evt.currentTarget);
    }

    if (this.drawerIsOpen && !externalCall) {
      return this.close();
    }

    // Add is-transitioning class to moved elements on open so drawer can have
    // transition for close animation
    this.$nodes.moved.addClass('is-transitioning');
    this.$drawer.prepareTransition();

    this.$nodes.parent.addClass(this.config.openClass + ' ' + this.config.dirOpenClass);
    this.drawerIsOpen = true;

    // Set focus on drawer
    this.trapFocus(this.$drawer, 'drawer_focus');

    // Run function when draw opens if set
    if (this.config.onDrawerOpen && typeof(this.config.onDrawerOpen) == 'function') {
      if (!externalCall) {
        this.config.onDrawerOpen();
      }
    }

    if (this.$activeSource && this.$activeSource.attr('aria-expanded')) {
      this.$activeSource.attr('aria-expanded', 'true');
    }

    // Lock scrolling on mobile
    this.$nodes.page.on('touchmove.drawer', function () {
      return false;
    });

    this.$nodes.page.on('click.drawer', $.proxy(function () {
      this.close();
      return false;
    }, this));
  };

  Drawer.prototype.close = function () {
    if (!this.drawerIsOpen) { // don't close a closed drawer
      return;
    }

    // deselect any focused form elements
    $(document.activeElement).trigger('blur');

    // Ensure closing transition is applied to moved elements, like the nav
    this.$nodes.moved.prepareTransition({ disableExisting: true });
    this.$drawer.prepareTransition({ disableExisting: true });

    this.$nodes.parent.removeClass(this.config.dirOpenClass + ' ' + this.config.openClass);

    this.drawerIsOpen = false;

    // Remove focus on drawer
    this.removeTrapFocus(this.$drawer, 'drawer_focus');

    this.$nodes.page.off('.drawer');
  };

  Drawer.prototype.trapFocus = function ($container, eventNamespace) {
    var eventName = eventNamespace ? 'focusin.' + eventNamespace : 'focusin';

    $container.attr('tabindex', '-1');

    $container.focus();

    $(document).on(eventName, function (evt) {
      if ($container[0] !== evt.target && !$container.has(evt.target).length) {
        $container.focus();
      }
    });
  };

  Drawer.prototype.removeTrapFocus = function ($container, eventNamespace) {
    var eventName = eventNamespace ? 'focusin.' + eventNamespace : 'focusin';

    $container.removeAttr('tabindex');
    $(document).off(eventName);
  };

  return Drawer;
})();

// Initialize Timber's JS on docready
$(timber.init);

window.theme = window.theme || {};

theme.Header = (function() {
	
	var cache = {};

	function cacheSelectors() {
		cache = {
			$html: $('html'),
			$body: $('body'),
			$wrapper: $('.wrapper'),
			$sidebar: $('#sidebar'),
			$logo: $('#logo'),
			$meta: $('#meta'),
			$siteHeader: $('.site-header'),
			$siteHeaderSticky: $('.site-header:last-of-type') || null,
			$menu: $('#menu'),
			$nav: $('#AccessibleNav'),
			$siteLogo: $('.site-header__logo'),
			$mobileMenu: $('.nav-bar'),
			$mobileMenuButton: $('#menu-opener'),
			$responsiveMenu: $('#meta').find('.responsive-menu'),
			$responsiveClose: $('.responsive-close'),
			$options: $('#options'),
			$footer: $('#footer'),
			$content: $('#content'),
			touchM: "ontouchstart" in window,
			iOS: /(iPad|iPhone|iPod)/g.test(navigator.userAgent),
			navWidth: 0,
			logoWidth: 0
		};
	}

	function init() {
		cacheSelectors();
		if (cache.touchM) {
			cache.$body.addClass('touch');
		} else {
			cache.$body.addClass('no-touch');
		}

		if ($('header').hasClass('is-dark')) {
			$('#PageContainer').addClass('is-dark');
			$('#PageContainer').removeClass('is-light');
		} else if ($('header').hasClass('is-light')) {
			$('#PageContainer').addClass('is-light');
			$('#PageContainer').removeClass('is-dark');
		}

		cache.$footer.removeClass('loading');

		/* Enable fit vid & custom solution for posts videos */

		$('p[style="text-align: center;"] img, p[style="text-align: center;"] iframe').each(function() {
			$(this).parent().addClass('centered-media');
		});

		$('.main-content').fitVids();
		
		menuStyleCheck();
		stickyHeader();

		if ($('.link-list').length > 0) {
		  $('.link-list').clone().appendTo($('.nav-bar'));
		}

		menuDrawerButtons();
		dropDownMenus();


	}

	/* Function that decides whether to show a hammegamenu icon or all the links */
	function fitNav() {
		if (cache.$wrapper.width() < (cache.navWidth + cache.logoWidth) && cache.$siteHeader.hasClass('site-header--classic')) {
			cache.$mobileMenu.removeClass('animate');
			cache.$siteHeader.removeClass('site-header--classic');
			cache.$siteHeader.addClass('site-header--drawer mobile sticky');
			cache.$siteHeaderSticky.css('display', 'none');
			cache.$siteHeader
			.find('.btn__buy a')
			.removeClass('btn--small btn--dark')
			.addClass('btn--regular btn--light');
			setTimeout(function() {
				cache.$mobileMenu.addClass('animate');
			}, 200);
        // Make drawer a11y unaccessible
        timber.cache.$navBar.attr('aria-hidden', 'true');
    }
    else if (cache.$wrapper.width() > (cache.navWidth + cache.logoWidth) && cache.$siteHeader.hasClass('site-header--drawer')) {
    	timber.closeDrawerMenu();
    	cache.$siteHeader.addClass('site-header--classic');
    	cache.$siteHeader.removeClass('site-header--drawer mobile sticky');
    	cache.$siteHeaderSticky.css('display', 'block');
    	cache.$siteHeader
    	.find('.btn__buy a')
    	.addClass('btn--small btn--dark')
    	.removeClass('btn--regular btn--light');
    	cache.$mobileMenu.css('height', '100%');
        // Make drawer a11y accessible
        timber.cache.$navBar.attr('aria-hidden', 'false');
    }
    if (cache.$wrapper.width() < (cache.navWidth + cache.logoWidth)) {
    	cache.$mobileMenu.css('height', $(window).height());
    }
    cache.$siteLogo.css('opacity', '1');
    cache.$nav.css('opacity', '1');
}

function menuStyleCheck() {
	if (cache.$siteHeader.hasClass('site-header--classic')) {
		cache.$siteHeader = $('.site-header:not(.created-by-js)');
		timber.cache.$window.on('load', function() {
			cache.logoWidth = cache.$siteLogo.width() || 0;
			cache.$nav.children('li').each(function() {
				cache.navWidth += $(this).outerWidth(true);
			});
	        // Make drawer a11y accessible
	        timber.cache.$navBar.attr('aria-hidden', 'false');
	        fitNav();
	        timber.cache.$window.on('resize', $.debounce(250, fitNav));

   	 })	
	};
}

function stickyHeader () {

	if (cache.$siteHeader.hasClass('site-header--classic')) {

      $('.site-header').after(cache.$siteHeader.clone());
      cache.$siteHeaderSticky = $('.site-header:last-of-type');
      cache.$siteHeaderSticky.addClass('sticky created-by-js').attr('aria-hidden', true).find('a').attr('tabIndex', -1);

      setTimeout(function(){
        cache.$siteHeaderSticky.addClass('animate');
      }, 500)

      $(window).on('scroll', function(){
        if ( $(window).scrollTop() > 300 && !cache.$siteHeaderSticky.hasClass('active') ) {
          cache.$siteHeaderSticky.addClass('active');
        } else if ( $(window).scrollTop() < 300 && cache.$siteHeaderSticky.hasClass('active') ) {
          cache.$siteHeaderSticky.removeClass('active');
        }
      });

    }

}

function menuDrawerButtons (){

	cache.$mobileMenuButton.on('click', function(e) {
		if ($(this).hasClass('opened')) {
			timber.closeDrawerMenu()
		} else {
			timber.openDrawerMenu();
		}
		e.preventDefault();
	});

	setTimeout(function() {
		cache.$mobileMenu.addClass('animate');
	}, 500);
}


function dropDownMenus() {
	$('li.site-nav--has-dropdown').each(function() {
		$(this).on('touchstart', function(e) {
			if ($(this).hasClass('opened')) {
				dropMenu($(this), 'out');
			} else {
				dropMenu($(this), 'in');
			}
			e.preventDefault();
		}).on('mouseenter', function(e) {
			dropMenu($(this), 'in');
			e.preventDefault();
		}).on('mouseleave', function(e) {
			dropMenu($(this), 'out');
			e.preventDefault();
		});

		$(this).children('.site-nav_menudrop')
		.css({
			'display' : 'block',
			'opacity' : '1'
		});
		var maxW = 0;
		$(this).find('li').each(function() {
			$(this).css('position', 'fixed');
			if ($(this).width() > maxW) {
				maxW = $(this).width();
			}
			$(this).css('position', 'relative');
		});
		maxW += 51;
		$(this).children('.site-nav_menudrop').css({
			width: maxW,
			marginLeft: -maxW/2,
			display: 'none'
		});
	});


}

function dropMenu($menu, dir) {
	if (dir == 'out') {
		$menu.removeClass('opened');
		$menu.children('.site-nav_menudrop').stop().slideUp(150);
	} else {
		$menu.addClass('opened');
		$menu.children('.site-nav_menudrop').stop().slideDown(200);
	}
}

 function onSelect() {
	if (cache.$siteHeader.hasClass('site-header--classic')) {
	  		cache.logoWidth = cache.$siteLogo.width() || 0;
			cache.$nav.children('li').each(function() {
				cache.navWidth += $(this).outerWidth(true);
			});
	        // Make drawer a11y accessible
	        timber.cache.$navBar.attr('aria-hidden', 'false');
	        fitNav();
	        timber.cache.$window.on('resize', $.debounce(250, fitNav));
	    };
 }

 
function unload() {
    if (cache.$body.hasClass('opened-drawer')){
    	cache.$body.removeClass('opened-drawer');
    }
  }

return {
    init: init,
    unload: unload,
    onSelect: onSelect
  };

})();
window.theme = window.theme || {};

theme.Slideshow = (function(el) {
	
	this.cache = {
		$slider: $(el),
		sliderArgs: {
			animation: 'slider',
			animationSpeed: 300,
			slideshow: false,
			slideshowSpeed: 5000,
			directionNav: true,
			controlNav: true,
			keyboard: true,
			prevText: $.themeAssets.arrow_left,
			nextText: $.themeAssets.arrow_right,
			smoothHeight: true,
			before: function(slider) {
				$(slider).resize();
				$(slider).find('.slide').not('.flex-active-slide').removeClass('slide-hide');
			},
			after: function(slider) {
				$(slider).find('.slide').not('.flex-active-slide').addClass('slide-hide');
			},
			start: function(slider) {
				$(slider).find('.slide').not('.flex-active-slide').addClass('slide-hide');
				if ($(slider).find('.slide').not('.clone').length === 1) {
					$(slider).find('.flex-direction-nav').remove();
				}
				$(window).trigger('resize');
				slider.addClass('loaded');
				if ($('#slider').data('loaded-index') != undefined) {
					$('#slider').flexslider($('#slider').data('loaded-index'));
				}
			}
		}
	}

	if (this.cache.$slider.find('li').length === 1) {
		this.cache.sliderArgs.touch = false;
	}
	
	return this.cache.$slider.flexslider(this.cache.sliderArgs);

});

/* ================ SECTIONS ================ */
window.theme = window.theme || {};
$(timber.init);
theme.HeaderSection = (function() {

  function Header() {

  	theme.Header.init();
    
  }

  Header.prototype = _.assignIn({}, Header.prototype, {
    onUnload: function() {
      theme.Header.unload();
    },
   onSelect: function(){
       theme.Header.onSelect();
    }
  });
 

  return Header;
})();
/* eslint-disable no-new */
theme.Product = (function() {
  var defaults = {
    selectors: {
      addToCart: '#AddToCart',
      productPrice: '#ProductPrice',
      comparePrice: '#ComparePrice',
      addToCartText: '#AddToCartText',
      quantityElements: '.quantity-selector',
      optionSelector: 'productSelect',
    }
  };

  function Product(container) {
    var $container = this.$container = $(container);
    var sectionId = $container.attr('data-section-id');

    this.settings = $.extend({}, defaults, {
      sectionId: sectionId,
      enableHistoryState: true,
      selectors: {
        originalSelectorId: 'productSelect-' + sectionId,
        addToCart: '#AddToCart-' + sectionId,
        productPrice: '#ProductPrice-' + sectionId,
        comparePrice: '#ComparePrice-' + sectionId,
        addToCartText: '#AddToCartText-' + sectionId,
        quantityElements: '#quantity-selector-' + sectionId,
        slider: '#slider-' + sectionId,
        selectorWrapper: '.selector-wrapper' + sectionId,
        SKU: '.variant-sku'
      }
    });

    // disable history state if on homepage
    if($('body').hasClass('template-index')) {
      this.settings.enableHistoryState = false;
    }

    // Stop parsing if we don't have the product json script tag when loading
    // section in the Theme Editor
    if (!$('#ProductJson-' + sectionId).html()) {
      this.addQuantityButtons();
      return;
    }

    this.productSingleObject = JSON.parse(document.getElementById('ProductJson-' + sectionId).innerHTML);
    this.init();

    // Pre-loading product images to avoid a lag when a thumbnail is clicked, or
    // when a variant is selected that has a variant image
    Shopify.Image.preload(this.productSingleObject.images);
  }

  Product.prototype = _.assignIn({}, Product.prototype, {
    init: function() {
      this.stringOverrides();
      this.initProductVariant();
      this.initSliderImages();
      this.addQuantityButtons();
      theme.customSelectorArrow(this.$container);

      $('.image-popup', this.$container).magnificPopup({
      type: 'image',
      gallery: {
        enabled: true,
        tCounter: ''
      },
      mainClass: 'mfp-fade'
    });
    },

    onUnload: function() {
      delete theme.slideshows[this.settings.selectors.slider];
    },

    stringOverrides: function() {
      // Override defaults in theme.strings with potential
      // template overrides

      theme.productStrings = theme.productStrings || {};
      $.extend(theme.strings, theme.productStrings);
    },

    addQuantityButtons: function(){
      if ($(this.settings.selectors.quantityElements).children('input#Quantity').length > 0) {

        $(this.settings.selectors.quantityElements).children('input#Quantity')
        .after(
          '<div class="input-holder plus"><button type="button" value="" class="plus" aria-label="'+ theme.strings.increase_quantity + '">' +
          $.themeAssets.plus +
          '</button></div>')
        .before(
          '<div class="input-holder minus"><button type="button" value="" class="minus" aria-label="' + theme.strings.reduce_quantity + '">' +
          $.themeAssets.minus +
          '</button></div>')
      };

    },

    initProductVariant: function() {
      // this.productSingleObject is a global JSON object defined in theme.liquid
      if (!this.productSingleObject) {
        return;
      }

      var self = this;
      this.optionSelector = new Shopify.OptionSelectors(self.settings.selectors.originalSelectorId, {
        selectorClass: self.settings.selectors.optionSelectorClass,
        product: self.productSingleObject,
        onVariantSelected: self.productVariantCallback,
        enableHistoryState: self.settings.enableHistoryState,
        settings: self.settings
      });

      // Clean up variant labels if the Shopify-defined
      // defaults are the only ones left
      this.simplifyVariantLabels(this.productSingleObject);
    },

    simplifyVariantLabels: function(productObject) {
     // Hide variant dropdown if only one exists and title contains 'Default'
    if (productObject.variants.length && productObject.variants[0].title.indexOf('Default') >= 0) {
      $('.selector-wrapper').hide();
    }
   },


   initSliderImages: function(){
    var slideshow = this.settings.selectors.slider;
    $(slideshow).imagesLoaded().done( function( instance ) {
      theme.slideshows[slideshow] = new theme.Slideshow(slideshow);
    });

  },

    // **WARNING** This function actually inherits `this` from `this.optionSelector` not
    // from `product` when passed in as a callback for `option_selection.js`
    productVariantCallback: function(variant) {

      if (variant) {
        // Update variant image, if one is set
        if (variant.featured_image) {
          var $slider = $(this.settings.selectors.slider);
          var newImg = $slider.find('.slide[data-variant-img="' + variant.featured_image.id + '"]');
          if (newImg.length > 0) {
            if ($slider.hasClass('loaded')) {
              $slider.flexslider(newImg.data('index'));
            } else {
              $slider.data('loaded-index', newImg.data('index'));
            }
          }
        }

        // Update the product price
        $(this.settings.selectors.productPrice).html(Shopify.formatMoney(variant.price, theme.settings.moneyFormat));

        // Show SKU
        $(this.settings.selectors.SKU).html(variant.sku);

        // Update and show the product's compare price if necessary
        if (variant.compare_at_price > variant.price) {
          $(this.settings.selectors.comparePrice)
          .html(Shopify.formatMoney(variant.compare_at_price, theme.settings.moneyFormat)).show();
        } else {
          $(this.settings.selectors.comparePrice).hide();
        }

        // Select a valid variant if available
        if (variant.available) {
          // We have a valid product variant, so enable the submit button
          $(this.settings.selectors.addToCart).removeClass('btn--disabled').prop('disabled', false);
          $(this.settings.selectors.addToCartText).text(theme.strings.add_to_cart);
          $(this.settings.selectors.quantityElements).removeClass('hidden');
        } else {
          // Variant is sold out, disable the submit button and change the text
          $(this.settings.selectors.addToCart).addClass('btn--disabled').prop('disabled', true);
          $(this.settings.selectors.addToCartText).text(theme.strings.sold_out);
          $(this.settings.selectors.quantityElements).addClass('hidden');
        }
      } else {
        // The variant doesn't exist, disable submit button and change the text.
        // This may be an error or notice that a specific variant is not available.
        $(this.settings.selectors.addToCart).addClass('btn--disabled').prop('disabled', true);
        $(this.settings.selectors.addToCartText).text(theme.strings.unavailable);
        $(this.settings.selectors.quantityElements).addClass('hidden');
      }
    }

  });

return Product;
})();

theme.slideshows = {};

theme.SlideshowSection = (function() {
  function SlideshowSection(container) {
    var $container = this.$container = $(container);
    var id = $container.attr('data-section-id');
    var slideshow = this.slideshow = '#flexslider--' + id;
    theme.slideshows[slideshow] = new theme.Slideshow(slideshow);
  }

  return SlideshowSection;
})();

theme.SlideshowSection.prototype = _.assignIn({}, theme.SlideshowSection.prototype, {
  onUnload: function() {
    delete theme.slideshows[this.slideshow];
  },

  onBlockSelect: function(evt) {
    var $slideshow = $(this.slideshow);
    // Ignore the cloned version
    var $slide = $('#slide-' + evt.detail.blockId + ':not(.clone)');
    var slideIndex = $slide.data('flexslider-index');
    var $slideImg = $slide.find('img') || $slide.find('svg');

    $slide.imagesLoaded($slideImg,function(){
    	$slideshow.flexslider(slideIndex);
    	$slideshow.flexslider("pause");

    });
    
  },

  onBlockDeselect: function() {
    // Resume autoplay
    $(this.slideshow).flexslider('play');
  }
});
window.theme = window.theme || {};

theme.Kickstarter = (function() {

  function Kickstarter() {

  	theme.crowdCampaign();
    
  }

  Kickstarter.prototype = _.assignIn({}, Kickstarter.prototype, {
    init: function() {
    	theme.crowdCampaign();
    },
    onSelect: function(){
      theme.crowdCampaign();
    }
  });
 
  return Kickstarter;
})();
window.theme = window.theme || {};

theme.FAQs = (function() {

  function FAQs(container) {
    var $container = this.$container = $(container);
    var sectionId = $container.attr('data-section-id');

    this.faqSelector = '.jumpstart-accordion-' + this.sectionId;

  	theme.accordionFAQs(this.$container);

    this.$blocks = $('.section', $container);
    this.$opened = $('.opened', $container);
  }

  FAQs.prototype = _.assignIn({}, FAQs.prototype, {
    init: function() {

      this.$opened.find('.content').slidedown(0);

      this.$blocks.find('.title').prepend($.themeAssets.plus + $.themeAssets.minus);
      
      this.$blocks.on('click', function(evt) {
        var blockId = $(evt.target).attr('data-block-id');
        this.focusFAQ(blockId);
      }); 
    },
    focusFAQ: function(blockId, isEditorEvent) {
      $accordionItem = $('.section-' + blockId);
      if ($accordionItem.hasClass('opened') && !isEditorEvent) {
        $accordionItem.removeClass('opened');
        $accordionItem.children('div').stop().slideUp(300);
      }
      else {
        $accordionItem.addClass('opened');
        $accordionItem.children('div').stop().slideDown(300);
        this.$blocks.not($accordionItem).removeClass('opened').children('div').stop().slideUp(300);
      }
    },
    onBlockSelect: function(evt){
      this.focusFAQ(evt.detail.blockId, true);
      
    },
    onload: function(){
      theme.accordionFAQs(this.$container);
      
    }
  });
 
  return FAQs;
})();

/* ================ TEMPLATES ================ */
window.theme = window.theme || {};

theme.Collection = (function() {

  function Collection() {

  	theme.collectionGridMasonry();
    
  }

  Collection.prototype = _.assignIn({}, Collection.prototype, {
    init: function() {
    	theme.collectionGridMasonry();
    },
    onSelect: function(){   	
      theme.collectionGridMasonry();
    }
  });
 
  return Collection;
})();


theme.cacheSelectors = (function(){
  theme.cache = {
    $html : $('html'),
        $body : $('body'),
        $wrapper : $('.wrapper'),
        $sidebar : $('#sidebar'),
        $logo : $('#logo'),
        $meta : $('#meta'),
        $siteHeader : $('.site-header'),
        $menu : $('#menu'),
        $nav : $('#AccessibleNav'),
        $siteLogo : $('.site-header__logo'),
        $mobileMenu : $('.nav-bar'),
        $mobileMenuButton : $('#menu-opener'),
        $responsiveMenu : $('#meta').find('.responsive-menu'),
        $responsiveClose : $('.responsive-close'),
        $options : $('#options'),
        $footer : $('#footer'),
        $content : $('#content'),
        touchM : "ontouchstart" in window,
        iOS : /(iPad|iPhone|iPod)/g.test(navigator.userAgent),
        navWidth : 0,
        logoWidth : 0

  }

});

theme.customSelectorArrow = (function(el) {
    var scope = el || document;
    $('select', $(scope)).each(function() {
      $(this).wrap('<div class="jumpstart-selector"></div>');
      $(this).parent().attr('style', $(this).attr('style'));
      $(this).parent().append('<span class="arrow">' + $.themeAssets.arrow_down + '</span>');
    });
  });

theme.collectionGridMasonry = (function() {
      if ( (typeof $.fn.packery !== 'undefined') && ($('.collection-list').length > 0) ) {
      $('.collection-list').imagesLoaded(function() {
        $('.collection-list').packery({
          itemSelector: '.product',
          transitionDuration: 0
        });
      });
    }
  });

theme.parallaxBg = (function() {
    if ( $('.parallax-bg').length > 0 || $('#section-a').length > 0 ) {
      if ($('#section-a').length > 0) {
        var $parallelBg = $('#section-a span.parallel-bg'),
            $parallelTxt = $('#section-a .wrapper').addClass('parallel-txt');
        $parallelBg.parent().addClass('parallax-bg');
      } else {
        var $parallelBg = $('.parallel-bg'),
            $parallelTxt = $('.parallel-txt');
      }
      $(window).on('scroll', function(){
        if ($(window).scrollTop() < $parallelBg.height()) {
          $parallelBg.css('transform', 'translate3d(0px, ' + ($(window).scrollTop()/4) + 'px, 0px)');
          $parallelTxt.css('transform', 'translate3d(0px, ' + ($(window).scrollTop()/8) + 'px, 0px)');
        }
      });

    }
  });

theme.quantityButtons = (function() {
    if ($('input#Quantity').length > 0) {

      $(document).on( 'click', '.plus, .minus', function() {

        var $qty = $(this).siblings('#Quantity'),
            currentVal = parseFloat($qty.val()),
            max = parseFloat($qty.attr('max')),
            min = parseFloat($qty.attr('min')),
            step = $qty.attr('step');

        if ( ! currentVal || currentVal === '' || currentVal === 'NaN' ) currentVal = 0;
        if ( max === '' || max === 'NaN' ) max = '';
        if ( min === '' || min === 'NaN' ) min = 0;
        if ( step === 'any' || step === '' || step === undefined || parseFloat( step ) === 'NaN' ) step = 1;

        if ($(this).is('.plus')) {
          if ( max && ( max == currentVal || currentVal > max ) ) {
            $qty.val(max);
          } else {
            $qty.val(currentVal + parseFloat( step ));
          }
        }
        else {
          if ( min && ( min == currentVal || currentVal < min ) ) {
            $qty.val( min );
          } else if ( currentVal > 0 ) {
            $qty.val( currentVal - parseFloat( step ) );
          }
        }
        $qty.trigger( 'change' );
      });

    }
     });

theme.passwordFooter = (function(){
  if ($('.template-password').length > 0) {
      var $pageContainer = $('#PageContainer'),
          $passwordFooter = $('#password-footer');
      $(window).on('resize', function() {
        if ($(window).height() < $pageContainer.height()) {
          $passwordFooter.removeClass('full');
        } else {
          $passwordFooter.addClass('full');
        }
      }).trigger('resize');
    }
  });

theme.infiniteBlog = (function(){
  var $infiniteLink = $('#infinite-link'),
        $infiniteURL = $infiniteLink.children('a'),
        $blogList = $('.blog-list');

    if ($infiniteLink.length > 0) {
      $infiniteURL.on('click', function(e) {
        $infiniteURL.addClass('btn--disabled').text('Loading ...');
        var href = $(this).attr('href');
        $.ajax({
          url: href,
          success: function(data) {
            var $data = $(data),
                $posts = $data.find('a.article'),
                $infinite = $data.find('#infinite-link');
            $posts.imagesLoaded(function() {
              $posts.css('display', 'none');
              $blogList.append($posts);
              $posts.slideDown(300);
              if ($infinite.length > 0) {
                $infiniteURL.removeClass('btn--disabled')
                  .text('More posts')
                  .prop('href', $infinite.children('a').prop('href'));
              } else {
                $infiniteURL.text('All posts loaded');
              }
            });
          }
        });
        e.preventDefault();
      });
    }
});

theme.homeGallery = (function(){

  if ($('.home-gallery').length > 0) {
      $('.home-gallery').imagesLoaded(function() {
        $('.home-gallery').find('.item').each(function() {
          var $img = $(this).find('img');
          if ( $img[0].naturalWidth <= $img[0].naturalHeight ) {
            $(this).addClass('one-quarter medium-down--one-half');
          } else {
            $(this).addClass('one-half medium-down--one-whole');
          }
        });
        $('.home-gallery').find('.packery-container').packery({
          itemSelector: '.grid-item',
          gutter: 0,
          percentPosition: true,
          transitionDuration: 0
        });
        $('.home-gallery').addClass('init');
        $('.home-gallery').find('.packery-container').packery();
      });
    }

});

theme.iframePopUp = (function(){
  $('.video-overlay').magnificPopup({
      type: 'iframe',
      mainClass: 'mfp-fade'
    });
});

theme.accordionFAQs = (function(el){
  var scope = el || document;

  if ($('.jumpstart-accordion', $(scope)).length > 0) {
      $('.jumpstart-accordion', $(scope)).each(function() {
        var $sections = $(this).children('div');
        var $opened = $sections.filter('.opened');
        $opened.children('div').slideDown(0);
        $(this)
          .children('div')
          .children('h3')
          .prepend($.themeAssets.plus + $.themeAssets.minus)
          .click(function() {
            console.log('onclick fired');
            var $this = $(this).parent();
            if ($this.hasClass('opened')) {
              console.log('has opened class')
              $this.removeClass('opened');
              $this.children('div').stop().slideUp(300);
            }
            else {
              $this.addClass('opened');
              $this.children('div').stop().slideDown(300);
              $sections.not($this).removeClass('opened').children('div').stop().slideUp(300);
            }
          }
        );
      });
    }
  });

theme.crowdCampaign = (function(){
 if ($('.home-kickstarter').length > 0) {

      // PIE

      $('.kickstarter__graphic.pie').html('<canvas id="kickstarter__pie--help" width="110" height="110"></canvas><canvas id="kickstarter__pie" width="110" height="110"></canvas>');

      var progress = 0,
          pieI = null,
          pieValue = Math.min( parseInt($('.kickstarter__graphic').data('value')) / 100, 1 ),
          pieColor = $('.kickstarter__graphic').data('color'),
          pieCanvas = document.getElementById('kickstarter__pie'),
          context = pieCanvas.getContext('2d'),
          centerX = pieCanvas.width / 2,
          centerY = pieCanvas.height / 2,
          radius = 45,
          progress = 0;

      context.lineWidth = 15;
      context.strokeStyle = pieColor;
      context.lineCap = 'round';

      pieI = setInterval(function() {
        progress = progress + 0.0025;
        context.clearRect(0, 0, pieCanvas.width, pieCanvas.height);
        context.beginPath();
        context.arc(centerX, centerY, radius, 0, (2*progress) * Math.PI, false);
        context.stroke();
        if (progress >= pieValue) {
          clearInterval(pieI);
        }
      }, 5);

      var pieCanvasHelp = document.getElementById('kickstarter__pie--help'),
          contextHelp = pieCanvasHelp.getContext('2d'),
          centerXHelp = pieCanvasHelp.width / 2,
          centerYHelp = pieCanvasHelp.height / 2,
          radiusHelp = 45;

      contextHelp.lineWidth = 15;
      contextHelp.strokeStyle = '#e9e9e9';
      contextHelp.lineCap = 'round';
      contextHelp.beginPath();
      contextHelp.arc(centerXHelp, centerYHelp, radiusHelp, 0, 2 * Math.PI, false);
      contextHelp.stroke();

      // BAR

      var barValue = Math.min(parseInt($('.kickstarter__graphic.bar').data('value')), 100);
      $('.kickstarter__graphic.bar').append('<div class="value"></div>');
      $('.kickstarter__graphic.bar .value').css('width', barValue + '%');

    }

});

$(document).ready(function() {
  var sections = new theme.Sections();

  sections.register('header-section', theme.HeaderSection);
  sections.register('slideshow-section', theme.SlideshowSection);
  sections.register('product', theme.Product);
  sections.register('home-product', theme.Product);
  sections.register('collection-template', theme.Collection);
  sections.register('list-collection-template', theme.Collection);
  sections.register('home-kickstarter', theme.Kickstarter);
  sections.register('home-faq', theme.FAQs);


});


(function($) {

  $(document).ready(function($){

    "use strict";

    /* Elements */

    var $html = $('html'),
        $body = $('body'),
        $wrapper = $('.wrapper'),
        $sidebar = $('#sidebar'),
        $logo = $('#logo'),
        $meta = $('#meta'),
        $siteHeader = $('.site-header'),
        $menu = $('#menu'),
        $nav = $('#AccessibleNav'),
        $siteLogo = $('.site-header__logo'),
        $mobileMenu = $('.nav-bar'),
        $mobileMenuButton = $('#menu-opener'),
        $responsiveMenu = $meta.find('.responsive-menu'),
        $responsiveClose = $('.responsive-close'),
        $options = $('#options'),
        $footer = $('#footer'),
        $content = $('#content'),
        touchM = "ontouchstart" in window,
        iOS = /(iPad|iPhone|iPod)/g.test(navigator.userAgent),
        navWidth = 0,
        logoWidth = 0;

  });

})(jQuery);

theme.init = function() {
  theme.cacheSelectors();
  theme.parallaxBg();
  theme.customSelectorArrow();
  theme.quantityButtons();
  theme.passwordFooter();
  theme.infiniteBlog();
  theme.homeGallery();
  theme.iframePopUp();

  if (theme.cache.$body.hasClass('template-index')) {
      if ( ($('.main-content').children('.index-sections').children('.shopify-section').length % 2) != 0 ) {
        $('.social-footer').addClass('even');
      }
    }

};
$(theme.init);

