if((typeof Shopify) === 'undefined') {
  Shopify = {};
}
/*ajax update cartpage only*/
Shopify.updateCartPage = function(qtyInput) {

  var lineItem = qtyInput.attr('data-lineItem'),
    qty = qtyInput.val(),
    money_format = qtyInput.parents('form').attr('data-money_format'),
    $cartRow = qtyInput.parents('.cartRow'),
    $cartHeading = $('#cartHeading'),
    $cartTotal = $('#cartTotal'),
    $cartItemCount = $('#cartItemCount'),
    $cartForm = $('#cartForm'),
    emptyCart = 'Votre panier est vide. Continuez sur notre catalogue <a href="/collections/all">ici</a>.',
    itemsCart = 'Total :';

  $('.qtyInput').attr('disabled', 'disabled');
	
  $.ajax({
    type: 'POST',
    url: '/cart/change.js',
    data: 'quantity=' + qty + '&line=' + lineItem,
    dataType: 'json',
    success: function(cart) {
      // Re-initialize additional cart buttons
      
      if (window.Shopify && Shopify.StorefrontExpressButtons) {
        Shopify.StorefrontExpressButtons.initialize();
      }
      
      
      
      //remove line item if val is 0
      if(qty == 0) {
        $cartRow.remove();
      }
      //update cart price
      var total_price = cart.total_price;
     // alert();
      if(total_price === 0 && 0) {
        $cartHeading.html(emptyCart);
        $cartForm.remove();
      } else {
        $cartTotal.html(Shopify.formatMoney(cart.total_price, money_format));
      }
      updateShippingBar(cart.total_price);
      $('.qtyInput').attr('disabled', false);
      $cartItemCount.html(cart.item_count);
      window.location.reload();
    }
  });
}
