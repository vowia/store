/*! lazysizes - v5.0.0 */
!function(a,b){var c=b(a,a.document);a.lazySizes=c,"object"==typeof module&&module.exports&&(module.exports=c)}(window,function(a,b){"use strict";if(b.getElementsByClassName){var c,d,e=b.documentElement,f=a.Date,g=a.HTMLPictureElement,h="addEventListener",i="getAttribute",j=a[h],k=a.setTimeout,l=a.requestAnimationFrame||k,m=a.requestIdleCallback,n=/^picture$/i,o=["load","error","lazyincluded","_lazyloaded"],p={},q=Array.prototype.forEach,r=function(a,b){return p[b]||(p[b]=new RegExp("(\\s|^)"+b+"(\\s|$)")),p[b].test(a[i]("class")||"")&&p[b]},s=function(a,b){r(a,b)||a.setAttribute("class",(a[i]("class")||"").trim()+" "+b)},t=function(a,b){var c;(c=r(a,b))&&a.setAttribute("class",(a[i]("class")||"").replace(c," "))},u=function(a,b,c){var d=c?h:"removeEventListener";c&&u(a,b),o.forEach(function(c){a[d](c,b)})},v=function(a,d,e,f,g){var h=b.createEvent("Event");return e||(e={}),e.instance=c,h.initEvent(d,!f,!g),h.detail=e,a.dispatchEvent(h),h},w=function(b,c){var e;!g&&(e=a.picturefill||d.pf)?(c&&c.src&&!b[i]("srcset")&&b.setAttribute("srcset",c.src),e({reevaluate:!0,elements:[b]})):c&&c.src&&(b.src=c.src)},x=function(a,b){return(getComputedStyle(a,null)||{})[b]},y=function(a,b,c){for(c=c||a.offsetWidth;c<d.minSize&&b&&!a._lazysizesWidth;)c=b.offsetWidth,b=b.parentNode;return c},z=function(){var a,c,d=[],e=[],f=d,g=function(){var b=f;for(f=d.length?e:d,a=!0,c=!1;b.length;)b.shift()();a=!1},h=function(d,e){a&&!e?d.apply(this,arguments):(f.push(d),c||(c=!0,(b.hidden?k:l)(g)))};return h._lsFlush=g,h}(),A=function(a,b){return b?function(){z(a)}:function(){var b=this,c=arguments;z(function(){a.apply(b,c)})}},B=function(a){var b,c=0,e=d.throttleDelay,g=d.ricTimeout,h=function(){b=!1,c=f.now(),a()},i=m&&g>49?function(){m(h,{timeout:g}),g!==d.ricTimeout&&(g=d.ricTimeout)}:A(function(){k(h)},!0);return function(a){var d;(a=!0===a)&&(g=33),b||(b=!0,d=e-(f.now()-c),d<0&&(d=0),a||d<9?i():k(i,d))}},C=function(a){var b,c,d=99,e=function(){b=null,a()},g=function(){var a=f.now()-c;a<d?k(g,d-a):(m||e)(e)};return function(){c=f.now(),b||(b=k(g,d))}};!function(){var b,c={lazyClass:"lazyload",loadedClass:"lazyloaded",loadingClass:"lazyloading",preloadClass:"lazypreload",errorClass:"lazyerror",autosizesClass:"lazyautosizes",srcAttr:"data-src",srcsetAttr:"data-srcset",sizesAttr:"data-sizes",minSize:40,customMedia:{},init:!0,expFactor:1.5,hFac:.8,loadMode:2,loadHidden:!0,ricTimeout:0,throttleDelay:125};d=a.lazySizesConfig||a.lazysizesConfig||{};for(b in c)b in d||(d[b]=c[b]);k(function(){d.init&&F()})}();var D=function(){var g,l,m,o,p,y,D,F,G,H,I,J,K=/^img$/i,L=/^iframe$/i,M="onscroll"in a&&!/(gle|ing)bot/.test(navigator.userAgent),N=0,O=0,P=0,Q=-1,R=function(a){P--,(!a||P<0||!a.target)&&(P=0)},S=function(a){return null==J&&(J="hidden"==x(b.body,"visibility")),J||"hidden"!=x(a.parentNode,"visibility")&&"hidden"!=x(a,"visibility")},T=function(a,c){var d,f=a,g=S(a);for(F-=c,I+=c,G-=c,H+=c;g&&(f=f.offsetParent)&&f!=b.body&&f!=e;)(g=(x(f,"opacity")||1)>0)&&"visible"!=x(f,"overflow")&&(d=f.getBoundingClientRect(),g=H>d.left&&G<d.right&&I>d.top-1&&F<d.bottom+1);return g},U=function(){var a,f,h,j,k,m,n,p,q,r,s,t,u=c.elements;if((o=d.loadMode)&&P<8&&(a=u.length)){for(f=0,Q++;f<a;f++)if(u[f]&&!u[f]._lazyRace)if(!M||c.prematureUnveil&&c.prematureUnveil(u[f]))aa(u[f]);else if((p=u[f][i]("data-expand"))&&(m=1*p)||(m=O),r||(r=!d.expand||d.expand<1?e.clientHeight>500&&e.clientWidth>500?500:370:d.expand,c._defEx=r,s=r*d.expFactor,t=d.hFac,J=null,O<s&&P<1&&Q>2&&o>2&&!b.hidden?(O=s,Q=0):O=o>1&&Q>1&&P<6?r:N),q!==m&&(y=innerWidth+m*t,D=innerHeight+m,n=-1*m,q=m),h=u[f].getBoundingClientRect(),(I=h.bottom)>=n&&(F=h.top)<=D&&(H=h.right)>=n*t&&(G=h.left)<=y&&(I||H||G||F)&&(d.loadHidden||S(u[f]))&&(l&&P<3&&!p&&(o<3||Q<4)||T(u[f],m))){if(aa(u[f]),k=!0,P>9)break}else!k&&l&&!j&&P<4&&Q<4&&o>2&&(g[0]||d.preloadAfterLoad)&&(g[0]||!p&&(I||H||G||F||"auto"!=u[f][i](d.sizesAttr)))&&(j=g[0]||u[f]);j&&!k&&aa(j)}},V=B(U),W=function(a){var b=a.target;if(b._lazyCache)return void delete b._lazyCache;R(a),s(b,d.loadedClass),t(b,d.loadingClass),u(b,Y),v(b,"lazyloaded")},X=A(W),Y=function(a){X({target:a.target})},Z=function(a,b){try{a.contentWindow.location.replace(b)}catch(c){a.src=b}},$=function(a){var b,c=a[i](d.srcsetAttr);(b=d.customMedia[a[i]("data-media")||a[i]("media")])&&a.setAttribute("media",b),c&&a.setAttribute("srcset",c)},_=A(function(a,b,c,e,f){var g,h,j,l,o,p;(o=v(a,"lazybeforeunveil",b)).defaultPrevented||(e&&(c?s(a,d.autosizesClass):a.setAttribute("sizes",e)),h=a[i](d.srcsetAttr),g=a[i](d.srcAttr),f&&(j=a.parentNode,l=j&&n.test(j.nodeName||"")),p=b.firesLoad||"src"in a&&(h||g||l),o={target:a},s(a,d.loadingClass),p&&(clearTimeout(m),m=k(R,2500),u(a,Y,!0)),l&&q.call(j.getElementsByTagName("source"),$),h?a.setAttribute("srcset",h):g&&!l&&(L.test(a.nodeName)?Z(a,g):a.src=g),f&&(h||l)&&w(a,{src:g})),a._lazyRace&&delete a._lazyRace,t(a,d.lazyClass),z(function(){var b=a.complete&&a.naturalWidth>1;p&&!b||(b&&s(a,"ls-is-cached"),W(o),a._lazyCache=!0,k(function(){"_lazyCache"in a&&delete a._lazyCache},9)),"lazy"==a.loading&&P--},!0)}),aa=function(a){if(!a._lazyRace){var b,c=K.test(a.nodeName),e=c&&(a[i](d.sizesAttr)||a[i]("sizes")),f="auto"==e;(!f&&l||!c||!a[i]("src")&&!a.srcset||a.complete||r(a,d.errorClass)||!r(a,d.lazyClass))&&(b=v(a,"lazyunveilread").detail,f&&E.updateElem(a,!0,a.offsetWidth),a._lazyRace=!0,P++,_(a,b,f,e,c))}},ba=C(function(){d.loadMode=3,V()}),ca=function(){3==d.loadMode&&(d.loadMode=2),ba()},da=function(){if(!l){if(f.now()-p<999)return void k(da,999);l=!0,d.loadMode=3,V(),j("scroll",ca,!0)}};return{_:function(){p=f.now(),c.elements=b.getElementsByClassName(d.lazyClass),g=b.getElementsByClassName(d.lazyClass+" "+d.preloadClass),j("scroll",V,!0),j("resize",V,!0),a.MutationObserver?new MutationObserver(V).observe(e,{childList:!0,subtree:!0,attributes:!0}):(e[h]("DOMNodeInserted",V,!0),e[h]("DOMAttrModified",V,!0),setInterval(V,999)),j("hashchange",V,!0),["focus","mouseover","click","load","transitionend","animationend"].forEach(function(a){b[h](a,V,!0)}),/d$|^c/.test(b.readyState)?da():(j("load",da),b[h]("DOMContentLoaded",V),k(da,2e4)),c.elements.length?(U(),z._lsFlush()):V()},checkElems:V,unveil:aa,_aLSL:ca}}(),E=function(){var a,c=A(function(a,b,c,d){var e,f,g;if(a._lazysizesWidth=d,d+="px",a.setAttribute("sizes",d),n.test(b.nodeName||""))for(e=b.getElementsByTagName("source"),f=0,g=e.length;f<g;f++)e[f].setAttribute("sizes",d);c.detail.dataAttr||w(a,c.detail)}),e=function(a,b,d){var e,f=a.parentNode;f&&(d=y(a,f,d),e=v(a,"lazybeforesizes",{width:d,dataAttr:!!b}),e.defaultPrevented||(d=e.detail.width)&&d!==a._lazysizesWidth&&c(a,f,e,d))},f=function(){var b,c=a.length;if(c)for(b=0;b<c;b++)e(a[b])},g=C(f);return{_:function(){a=b.getElementsByClassName(d.autosizesClass),j("resize",g)},checkElems:g,updateElem:e}}(),F=function(){F.i||(F.i=!0,E._(),D._())};return c={cfg:d,autoSizer:E,loader:D,init:F,uP:w,aC:s,rC:t,hC:r,fire:v,gW:y,rAF:z}}});    
  
/* Jonathan Snook - MIT License - https://github.com/snookca/prepareTransition */
(function(a){a.fn.prepareTransition=function(){return this.each(function(){var b=a(this);b.one("TransitionEnd webkitTransitionEnd transitionend oTransitionEnd",function(){b.removeClass("is-transitioning")});var c=["transition-duration","-moz-transition-duration","-webkit-transition-duration","-o-transition-duration"];var d=0;a.each(c,function(a,c){d=parseFloat(b.css(c))||d});if(d!=0){b.addClass("is-transitioning");b[0].offsetWidth}})}})(jQuery);


/* replaceUrlParam - http://stackoverflow.com/questions/7171099/how-to-replace-url-parameter-with-javascript-jquery */
function replaceUrlParam(e,r,a){var n=new RegExp("("+r+"=).*?(&|$)"),c=e;return c=e.search(n)>=0?e.replace(n,"$1"+a+"$2"):c+(c.indexOf("?")>0?"&":"?")+r+"="+a};

/*============================================================================
  Money Format
  - Shopify.format money is defined in option_selection.js.
    If that file is not included, it is redefined here.
==============================================================================*/


if ((typeof Shopify) === 'undefined') { Shopify = {}; }
if (!Shopify.formatMoney) {
  Shopify.formatMoney = function(cents, format) {
    var value = '',
        placeholderRegex = /\{\{\s*(\w+)\s*\}\}/,
        formatString = (format || this.money_format);

    if (typeof cents == 'string') {
      cents = cents.replace('.','');
    }

    function defaultOption(opt, def) {
      return (typeof opt == 'undefined' ? def : opt);
    }

    function formatWithDelimiters(number, precision, thousands, decimal) {
      precision = defaultOption(precision, 2);
      thousands = defaultOption(thousands, ',');
      decimal   = defaultOption(decimal, '.');

      if (isNaN(number) || number == null) {
        return 0;
      }

      number = (number/100.0).toFixed(precision);

      var parts   = number.split('.'),
          dollars = parts[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, '$1' + thousands),
          cents   = parts[1] ? (decimal + parts[1]) : '';

      return dollars + cents;
    }

    switch(formatString.match(placeholderRegex)[1]) {
      case 'amount':
        value = formatWithDelimiters(cents, 2);
        break;
      case 'amount_no_decimals':
        value = formatWithDelimiters(cents, 0);
        break;
      case 'amount_with_comma_separator':
        value = formatWithDelimiters(cents, 2, '.', ',');
        break;
      case 'amount_no_decimals_with_comma_separator':
        value = formatWithDelimiters(cents, 0, '.', ',');
        break;
    }

    return formatString.replace(placeholderRegex, value);
  };
}
Shopify.redirectToCheckout = function(){
  	window.location.href = "/checkout";
  }
// Timber functions
window.timber = window.timber || {};

timber.cacheSelectors = function () {
  timber.cache = {
    // General
    $html                    : $('html'),
    $body                    : $('body'),

    // Navigation
    $header                  : $('header'),
    $megamenuNav               : $('.megamenuNav'),
    $aniNav                  : $('#megamenuMenu'),
    $maniNavCom              : $('#regularMenu'),
    $searchForm              : $('#headerSearch'),
    $searchStore             : $('#searchStore'),
    $closeSearch             : $('#closeSearch'),
    $navigation              : $('#AccessibleNav'),
    
    // Collection Pages
    $changeView              : $('.change-view'),

    // Product Page
    $productImage            : $('.featuredImage img'),
    $thumbImages             : $('.productThumbs a'),

    // Customer Pages
    $recoverPasswordLink     : $('#RecoverPassword'),
    $hideRecoverPasswordLink : $('#HideRecoverPasswordLink'),
    $recoverPasswordForm     : $('#RecoverPasswordForm'),
    $customerLoginForm       : $('#CustomerLoginForm'),
    $passwordResetSuccess    : $('#ResetSuccess')
  };
};


timber.init = function () {
  FastClick.attach(document.body);
  timber.cacheSelectors();
  timber.productImageSwitch();
  timber.loginForms();
  timber.navMenu();
  timber.accessibleNav();
  
};


timber.getHash = function () {
  return window.location.hash;
};

timber.productPage = function (options) {
  
  var moneyFormat = options.money_format,
      variant = options.variant,
      selector = options.selector;

  var productId = options.selector.product.id;
  // Selectors
  var actualProductID = $('.product_id_'+productId).attr('data-product_id');
  
  var $productImage = $('.featuredImage_'+actualProductID+' img'),
      $productImage_stickycart = $('.featuredImage_sticky_'+productId+' img'),
     $addToCart = $('.add_to_cart_btn_'+productId),
      $productPrice = $('.ProductPrice_'+productId),
      $comparePrice = $('.ComparePrice_'+productId),
      $productPrice_stickycart = $('.ProductPrice_stickycart_'+productId),
      $comparePrice_stickycart = $('.ComparePrice_stickycart_'+productId),
      $quantityElements = $('.quantity-selector, label + .js-qty'),
       $addToCartText = $('.add_to_cart_txt_'+actualProductID),
  	  $addToCartAll = $('.add_to_cart_btn_'+actualProductID),
$addToCartTextAll = $('.add_to_cart_txt_'+actualProductID);

  if (variant) {
   

    // Update variant image, if one is set
    if (variant.featured_image) {
    	
      var newImg = variant.featured_image,
          el = $productImage[0];
      console.log($(el).parent().attr('class'));
      Shopify.Image.switchImage(newImg, el, timber.switchImage);
    }
    if (variant.featured_image) {
      
      var newImg1 = variant.featured_image,
          el = $productImage_stickycart[0];
      Shopify.Image.switchImage(newImg1, el, timber.switchImage);
    }
   // $('.productMainImage_'+actualProductID).attr('data-attrchange',"false");
	//console.log('this place');
    // Select a valid variant if available
    if (variant.available) {
      // Available, enable the submit button, change text, show quantity elements
      $addToCartAll.removeClass('disabled').prop('disabled', false);
      $addToCartTextAll.html($addToCart.attr('data-text'));
      $quantityElements.show();
    } else {
      
      // Sold out, disable the submit button, change text, hide quantity elements
      $addToCartAll.addClass('disabled').prop('disabled', true);
      
      $addToCartTextAll.html("Épuisé");
      $quantityElements.hide();
    }

    // Regardless of stock, update the product price
    $productPrice.html( Shopify.formatMoney(variant.price, moneyFormat) );
    $productPrice_stickycart.html( Shopify.formatMoney(variant.price, moneyFormat) );

    // Also update and show the product's compare price if necessary
    if (variant.compare_at_price > variant.price) {
      $comparePrice
        .html(Shopify.formatMoney(variant.compare_at_price, moneyFormat))
        .show();
    } else {
      $comparePrice.hide();
    }
    if (variant.compare_at_price > variant.price) {
      $comparePrice_stickycart
        .html(Shopify.formatMoney(variant.compare_at_price, moneyFormat))
        .show();
    } else {
      $comparePrice_stickycart.hide();
    }

  } else {
    // The variant doesn't exist, disable submit button.
    // This may be an error or notice that a specific variant is not available.
    // To only show available variants, implement linked product options:
    //   - http://docs.shopify.com/manual/configuration/store-customization/advanced-navigation/linked-product-options
    $addToCartAll.addClass('disabled').prop('disabled', true);
    $addToCartTextAll.html("Épuisé");
    $quantityElements.hide();
  }
};

timber.productPageRegular = function (options) {
  var moneyFormat = options.money_format,
      variant = options.variant,
      selector = options.selector;

  var productId = options.selector.product.id;
  var actualProductID = $('.product_id_'+productId).attr('data-product_id');  
  
  // Selectors
  var $productImage = $('.featuredImage_'+options.prod_id+' img'),
      $productImage_stickycart = $('.featuredImage_sticky_'+productId+' img'),
      $addToCart = $('.add_to_cart_btn_'+productId),
      $productPrice = $('.ProductPrice_'+productId),
      $comparePrice = $('.ComparePrice_'+productId),
      $productPrice_stickycart = $('.ProductPrice_stickycart_'+productId),
      $comparePrice_stickycart = $('.ComparePrice_stickycart_'+productId),
      $quantityElements = $('.quantity-selector, label + .js-qty'),
      $addToCartText = $('.add_to_cart_txt_'+actualProductID),
  		$addToCartAll = $('.add_to_cart_btn_'+actualProductID),
  	$addToCartTextAll = $('.add_to_cart_txt_'+actualProductID);

  if (variant) {
	//console.log('inga');
    // Update variant image, if one is set
    if (variant.featured_image) {
      var newImg = variant.featured_image,
          el = $productImage[0];
      Shopify.Image.switchImage(newImg, el, timber.switchImage);
      
    }
    if (variant.featured_image) {
      
      var newImg1 = variant.featured_image,
          el = $productImage_stickycart[0];
      Shopify.Image.switchImage(newImg1, el, timber.switchImage);
    }
//    $('.productMainImage_'+actualProductID).attr('data-attrchange',"false");

    // Select a valid variant if available
    if (variant.available) {
      // Available, enable the submit button, change text, show quantity elements
      $addToCartAll.removeClass('disabled').prop('disabled', false);
      $addToCartTextAll.html($addToCart.attr('data-text'));
      $quantityElements.show();
    } else {
      //alert("Épuisé");
      //console.log($addToCartTextAll);
      // Sold out, disable the submit button, change text, hide quantity elements
      $addToCartAll.addClass('disabled').prop('disabled', true);
      $addToCartTextAll.html("Épuisé");
      $quantityElements.hide();
    }

    // Regardless of stock, update the product price
    $productPrice.html( Shopify.formatMoney(variant.price, moneyFormat) );
    $productPrice_stickycart.html( Shopify.formatMoney(variant.price, moneyFormat) );

    // Also update and show the product's compare price if necessary
    if (variant.compare_at_price > variant.price) {
      $comparePrice
        .html(Shopify.formatMoney(variant.compare_at_price, moneyFormat))
        .show();
    } else {
      $comparePrice.hide();
    }
    if (variant.compare_at_price > variant.price) {
      $comparePrice_stickycart
        .html(Shopify.formatMoney(variant.compare_at_price, moneyFormat))
        .show();
    } else {
      $comparePrice_stickycart.hide();
    }

  } else {
    // The variant doesn't exist, disable submit button.
    // This may be an error or notice that a specific variant is not available.
    // To only show available variants, implement linked product options:
    //   - http://docs.shopify.com/manual/configuration/store-customization/advanced-navigation/linked-product-options
    $addToCartAll.addClass('disabled').prop('disabled', true);
    $addToCartTextAll.html("Épuisé");
    $quantityElements.hide();
  }
};

timber.productImageSwitch = function () {
 
  //if (timber.cache.$thumbImages.length) {
    // Switch the main image with one of the thumbnails
    // Note: this does not change the variant selected, just the image
    timber.cache.$thumbImages.on('tap', function(evt) {
     evt.preventDefault();
      var newImage = $(this).attr('href');
      $(this).parent().find('a').removeClass('active');
      $(this).addClass('active');
      var $productId = $(this).attr('data-product_id');
      timber.switchImage(newImage, null, '.featuredImage_'+$productId+' img');
      return false;
    });
  	timber.cache.$thumbImages.on('click', function(evt) {
      evt.preventDefault();
      var newImage = $(this).attr('href');
      $(this).parent().find('a').removeClass('active');
      $(this).addClass('active');
      var $productId = $(this).attr('data-product_id');
      timber.switchImage(newImage, null, '.featuredImage_'+$productId+' img');
      return false;
    });
  //}
};

// $(document).ready(function() {
// $( "#thumbs_list li" ).on('click', function(evt) {
//   alert('hi');
// });
// });


timber.switchImage = function (src, imgObject, el) {

  // Make sure element is a jquery object
  
  var $pid = $(el).parents('.product_image_list_wrapper').attr('data-product_id');
  //console.log($('.productMainImage .slick-slide.slick-current.slick-active img').attr('src'));
  if($(el).parent().hasClass('featuredImage_sticky')){
  	var $el = $(el);
  	$el.attr('src', src);
  }else{
  	src = src.replace("https:", "");
    
	var srcObj = src.split('?v');

    src = srcObj[0];
    //console.log(src);
    //console.log('switch image');
    //src = src.replace("_grande", "_600x600");
    //console.log(src);
    
    var count = $(".productMainImage_"+$pid+" .slick-slide a[href='"+src+"']").attr('data-count');
  	$('.productMainImage_'+$pid).attr('data-attrchange','false');
 	console.log('here image');
    if(typeof count != "undefined"){
      
      //console.log($('.productMainImage_'+$pid).attr('data-attrchange'));
      
      setTimeout(function(){
      	if(!$('.productMainImage_'+$pid).parents('.cart_upsell_popup').length){
      	$('.productMainImage_'+$pid).slick('slickGoTo', count );
        }
      }, 100);

    	
      $('.thumbs_list_frame_'+$pid).slick('setPosition');
      // $('.thumbs_list_frame_'+$pid).find("div[data-image_zoom='zoom_images_count_"+count+"']").trigger('.click');
        //$('.thumbs_list_frame_'+$pid).slick('slickGoTo', count );
    }
    
  }
  
  
  
  

  return;
  $(".productThumbs a.active").removeClass('active');
  $(".productThumbs a[href='"+src+"']").addClass('active');

};

timber.loginForms = function() {
  function showRecoverPasswordForm() {
    timber.cache.$recoverPasswordForm.show();
    timber.cache.$customerLoginForm.hide();
  }

  function hideRecoverPasswordForm() {
    timber.cache.$recoverPasswordForm.hide();
    timber.cache.$customerLoginForm.show();
  }

  timber.cache.$recoverPasswordLink.on('click', function(evt) {
    evt.preventDefault();
    showRecoverPasswordForm();
  });

  timber.cache.$hideRecoverPasswordLink.on('click', function(evt) {
    evt.preventDefault();
    hideRecoverPasswordForm();
  });

  // Allow deep linking to recover password form
  if (timber.getHash() == '#recover') {
    showRecoverPasswordForm();
  }
};

timber.resetPasswordSuccess = function() {
  timber.cache.$passwordResetSuccess.show();
};



timber.navMenu = function(){
  
  timber.openMenu = function(){
    timber.cache.$maniNavCom.attr('style','display: inline-block;');
    setTimeout(function() {
    	timber.cache.$megamenuNav.addClass('active');
        timber.cache.$maniNavCom.addClass('active');
        $('body').addClass('open_mobile_menu');
    }, 10);
  }

 
  timber.closeMenu = function(){
    var $nav = timber.cache.$navigation,
	$parents = $nav.find('.site-nav--has-dropdown');
    
    timber.cache.$megamenuNav.removeClass('active');
    timber.cache.$maniNavCom.removeClass('active');
    $parents.find('.menu-arrow').removeClass('m-arrow-up');
    $parents.find('.menu-arrow').addClass('m-arrow-down');
    $parents.removeClass('open_mob_menu');
    $('body').removeClass('open_mobile_menu');
    $parents.removeClass('active');
  }
  
  
  timber.cache.$megamenuNav.on('click', function(evt) {
    evt.preventDefault();
    if(!$(this).hasClass('active')){
      
      timber.openMenu();
    }else{
      timber.closeMenu();  
    }
  }); 
  
 
   timber.cache.$aniNav.find('.parentLink').on('click', function(evt) {
     evt.preventDefault();
      $(this).parent('li').toggleClass( "active" )
    });
  
  timber.cache.$searchStore.on('click', function(evt) {
    evt.preventDefault();   
    timber.cache.$searchForm.toggleClass( "active" )
    timber.cache.$header.toggleClass( "active" )
    setTimeout(function() { $('input[name="q"]').focus() }, 0);
    
  })
  
   
  timber.cache.$closeSearch.on('click', function(evt) {
    evt.preventDefault();   
    timber.cache.$searchForm.toggleClass( "active" )
    timber.cache.$header.toggleClass( "active" )
  })
  
  
 
   
}

$('.header-cart-wrapper-inner .header-cart-txt.header_cart_icon').click(function(){
  		addScrollBarEvent();
  		var windowWidth = $(window).width();
    	addUpsellItemCartSlide();
        if (windowWidth > 768 || 1) {
          	if(!$('html').hasClass('open_mobile_cart')){
              $('html').addClass('open_mobile_cart');
              addScrollBarEvent();
              return false;
            }
        }
  });
timber.accessibleNav = function () {
  var $nav = timber.cache.$navigation,
      $allLinks = $nav.find('a'),
      $topLevel = $nav.children('li').find('a'),
      $parents = $nav.find('.site-nav--has-dropdown'),
      $subMenuLinks = $nav.find('.site-nav_menudrop').find('a'),
      activeClass = 'active',
      focusClass = 'active-focus';

  
  
  
  if (window.innerWidth > 740) {
    // Mouseenter
	$( ".menu_has_drop .main_mega_heading" ).on('mouseenter touchstart', function(evt) {
      var $el = $(this);

      if (!$el.parent().hasClass(activeClass)) {
        // force stop the click from happening
        //evt.preventDefault();
        ///evt.stopImmediatePropagation();
      }

      showDropdown($el);
    });
    $("#AccessibleNav > li").on('mouseenter touchstart', function(evt) {
   
      $(this).find('.menu-arrow').removeClass('m-arrow-down');
      $(this).find('.menu-arrow').addClass('m-arrow-up');
      $('body').addClass('menu_hover_open');
    });
    // Mouseout
    $( ".menu_has_drop .main_mega_heading" ).on('mouseleave', function() {
      hideDropdown($(this));
    });
    $("#AccessibleNav > li").on('mouseleave', function() {
         $(this).find('.menu-arrow').removeClass('m-arrow-up');
    	$(this).find('.menu-arrow').addClass('m-arrow-down');
      	$('body').removeClass('menu_hover_open');
    });
  }else{
	$( ".menu_has_drop .main_mega_heading" ).on('tap', function(evt) {
      var $el = $(this);
      //console.log($el.parent().attr('class'));
      evt.preventDefault();
      evt.stopImmediatePropagation();
      //console.log($el.parent().attr('class'));
      if($el.parent().hasClass(activeClass)){
       $el.parent().find('.menu-arrow').removeClass('m-arrow-up');
    $el.parent().find('.menu-arrow').addClass('m-arrow-down');
        hideDropdown($el); 
      }else{
        
        showDropdown($el);
        $el.parent().find('.menu-arrow').removeClass('m-arrow-down');
      $el.parent().find('.menu-arrow').addClass('m-arrow-up');
      };
      return false;
         
    });
    $( ".menu_has_drop .main_mega_heading" ).on('click', function(evt) {
      var $el = $(this);
	
      if (!$el.hasClass(activeClass)) {
        // force stop the click from happening
        evt.preventDefault();
        evt.stopImmediatePropagation();
      } 
    });
  }


  $subMenuLinks.on('touchstart', function(evt) {
    // Prevent touchstart on body from firing instead of link
    evt.stopImmediatePropagation();
  });

  $allLinks.focus(function() {
    
    handleFocus($(this));
  });

  $allLinks.blur(function() {
    removeFocus($topLevel);
  });

  // accessibleNav private methods
  function handleFocus ($el) {
    var $subMenu = $el.next('ul'),
        hasSubMenu = $subMenu.hasClass('sub-nav') ? true : false,
        isSubItem = $('.site-nav_menudrop').has($el).length,
        $newFocus = null;

    // Add focus class for top level items, or keep menu shown
    if (!isSubItem) {
      removeFocus($topLevel);
      addFocus($el);
    } else {
      $newFocus = $el.closest('.site-nav--has-dropdown').find('a');
      addFocus($newFocus);
    }
  }
 
  function showDropdown ($el) {
   
   	

    $el.parent().addClass('open_mob_menu');
    
    $el.parent().addClass(activeClass);
	//$('body').addClass('menu_hover_open');
    setTimeout(function() {
      timber.cache.$body.on('touchstart', function() {
        //hideDropdown($el);
      });
    }, 250);
    
  }

  function hideDropdown ($el) {
	


    $el.parent().removeClass('open_mob_menu');
    
    //$('body').removeClass('menu_hover_open');
    $el.parent().removeClass(activeClass);
    timber.cache.$body.off('touchstart');
  }

  function addFocus ($el) {
    $el.addClass(focusClass);
  }

  function removeFocus ($el) {
    $el.removeClass(focusClass);
  }
};





// Initialize Timber's JS on docready
$(timber.init);

isAppLoaded = true;
function scrollFX() {
  var $window = $(window),
    scrollTop = $window.scrollTop(),
    windowHeight = $window.height(),
    windowWidth = $window.width(),
    $boxes = $('[data-scroll-speed]'),
    $paraOne = $('.paraOne'),
    $paraTwo = $('.paraTwo'),
    tranY1 = $window.scrollTop() / 2.5 + 'px',
    tranY2 = $window.scrollTop() / 10000 + 'px',
    $header = $('header'),
    headerHeight = $('header').outerHeight(),
    $headerFX = $('header.lockFX'),
    $mainWrap = $('#mainWrap'),
    $scrollDown = $('.scrollDown'),
    altProdHeader = $('header.scrollFX');
  
  $('body').attr('data-scrollpos',scrollTop);
  //$('.SectionHeader__Heading').text(scrollTop);

  if($scrollDown.size() > 0) {
     if(scrollTop > 20) {
       $scrollDown.addClass('hidden');
     }else{
       $scrollDown.removeClass('hidden');
     }
  }
  if($headerFX.size() > 0 && 0) {
    var fullScreenSliderHeight = $('.fullScreenSlider').outerHeight();
    if(scrollTop > fullScreenSliderHeight) {	
      $header.addClass('locked');
      $mainWrap.css('margin-top', headerHeight);
    } else {
      $header.removeClass('locked');
      $mainWrap.css('margin-top', 0);
    }
  }

  if(altProdHeader.size() > 0) {
    if(scrollTop > 20) {
      altProdHeader.addClass('scrolled');
    } else {
      $header.removeClass('scrolled');
    }
  }

  $boxes.each(function() {
      var $this = $(this),
        oTop = scrollTop - $this.offset().top,
        scrollspeed = parseInt($this.data('scroll-speed')),
        val = -oTop / scrollspeed;
      $this.css('transform', 'translateY(' + val + 'px)');
    });

  //Hero
  if($paraOne.size() > 0) {
    $paraOne.css({
      transform: 'translateY(' + tranY1 + ')',
      MozTransform: 'translateY(' + tranY1 + ')',
      WebkitTransform: 'translateY(' + tranY1 + ')',
      msTransform: 'translateY(' + tranY1 + ')'
    });
    $paraTwo.css({
      transform: 'translateY(' + tranY2 + ')',
      MozTransform: 'translateY(' + tranY2 + ')',
      WebkitTransform: 'translateY(' + tranY2 + ')',
      msTransform: 'translateY(' + tranY2 + ')'
    });
  }
}

function openPopOut(target, t, line_item) {
  var $target = $(target),
    $popUps = $target.parents('#popUps'),
    $body = $('body'),
    $frame = $('#frame'),
    currentPos = $(window).scrollTop(),
    closePopout

  $popUps.css('background','rgba(0,0,0,0.9)');
  $popUps.addClass('active');
  $body.addClass('popOutFix');
  $frame.addClass('popOutFix');
  $target.show();
  if($target.attr('id') == 'gallery') {
    $popUps.css('background','rgba(255,255,255,0.9)');
    var scrolltoimg = $('.productThumbs').length ? $('.productThumbs a.active').attr('data-index_id') : '#indexImage_1';
    if(typeof scrolltoimg == "undefined"){
    	scrolltoimg = '#indexImage_1';
    }
    var $popUpsTop = $popUps.offset().top;
    //alert($popUpsTop);
    scrolltoimg = $target.find('img').filter(scrolltoimg).offset().top;
   // alert(scrolltoimg);
    scrolltoimg = scrolltoimg - $popUpsTop;
    $popUps.scrollTop(scrolltoimg);
  }
  setTimeout(function(){
    $target.addClass('active');
    
    //$('.shopify-section #popUps').scrollTop('0');
  },600);

  $('.closePopOut').click(function(e) {
    if(!$(e.target).parents('#prodForm').length){
    	e.preventDefault();
    }
    closePopout();
  });
  $target.find('form').submit(function(e) {
    closePopout();
  });
  closePopout = function() {
    if($target.attr('id') == 'CartUpsellPopup'){
       return;
    }
     
    $target.removeClass('active');
    $body.scrollTop(currentPos);
    setTimeout(function(){
      $popUps.removeClass('active');
      $body.removeClass('popOutFix');
      $frame.removeClass('popOutFix');
      $target.hide();
    },600);
  }
}

function setSlick(target) {
  //alert(target);
  target.each(function() {
    var $t = $(this),
      $n = $t.closest('.slickSlider').find('span.next'),
      $p = $t.closest('.slickSlider').find('span.prev'),
      $full = parseInt($t.attr('data-full'), 10),
      $tab = parseInt($t.attr('data-tab'), 10),
      $mob = parseInt($t.attr('data-mob'), 10),
      slides = $t.find('li').size(),
      $auto = $t.attr('data-auto')
    if($auto === "true") {
      $auto = true
    } else {
      $auto = false
    }
    var $time = parseInt($t.attr('data-timeout'), 10)
    if(slides >= 1) {
      var SlickSlider = $t.slick({
        autoplay: $auto,
        autoplaySpeed: $time,
        slidesToShow: $full,
        pauseOnHover: true,
        speed: 700,
        infinite: true,
        arrows: false,
        accessibility: false,
        dots: false,
        slidesToScroll: 1,
        responsive: [
          {
            breakpoint: 1080,
            settings: {
              slidesToShow: $full
            }
          },
          {
            breakpoint: 736,
            settings: {
              slidesToShow: $tab
            }
          },
          {
            breakpoint: 568,
            settings: {
              slidesToShow: $mob
            }
          }
        ],
        touchDrag: true,
        mouseDrag: false
      });
      $t.on('swipe', function(event, slick, currentSlide){
        showSectionByEffect();
        // left
      });
      $n.click(function() {
        SlickSlider.slick('slickNext');
        showSectionByEffect();
      });
      $p.click(function() {
        SlickSlider.slick('slickPrev');
        showSectionByEffect();
      });
      var $sizeAllow = 3;
      
      if(window.innerWidth < 568){
      	$sizeAllow = 1;
      }
      if($t.find('li').size() <= $sizeAllow){
      	 $n.hide();
         $p.hide();
      }else{
      	 $n.show();
         $p.show();
      }
      //alert($sizeAllow);
      //alert($t.find('li').size());
      
    }
  });
}

function igramFeed(access_token) {
  var access_token = $('#instafeed').attr('data-access_token');
  var hoverText = $('#instafeed').attr('data-text_hover');
    targetDiv = $('#instafeed')
  if(targetDiv.size() > 0) {
    $.ajax({
      type: "GET",
      dataType: "jsonp",
      url: 'https://api.instagram.com/v1/users/self/media/recent/?access_token='+ access_token,
      success: function(data) {
        var count = 9;
        var $html = '<div class="oneThird">';
        for(var i = 0; i < 4; i++){
          $html += '<div class="insta_div"><a href="' + data.data[i].link + '" target="_blank"><div class="insta_hover"><span>'+hoverText+'</span></div><img src="' + data.data[i].images.low_resolution.url + '" alt=""></a></div>';
        }
        $html += '</div>';
        
        $html += '<div class="oneThird">';
        var i = 4;          
        $html += '<div class="insta_div install_full"><a href="' + data.data[i].link + '" target="_blank"><div class="insta_hover"><span>'+hoverText+'</span></div><img src="' + data.data[i].images.standard_resolution.url + '" alt=""></a></div>';
        
        
        $html += '</div>';
        
       	$html += '<div class="oneThird">';
        for(var i = 5; i < count; i++) {
          $html += '<div class="insta_div"><a href="' + data.data[i].link + '" target="_blank"><div class="insta_hover"><span>'+hoverText+'</span></div><img src="' + data.data[i].images.low_resolution.url + '" alt=""></a></div>';
        }
        $html += '</div>';
        targetDiv.append($html);
      }	
    }).complete(function() {});
  }
}

function BS(target) {
  target.each(function() {
    $(this).backstretch($(this).attr('data-img'))
  });
}

function showNewsLetterLanding() {
  
}

function showNewsLetterLeaving() {

}

function isotopeblog(){
  $('.blogListing').imagesLoaded(function(){
    $('.blogListing').isotope({
       itemSelector: 'li',
       percentPosition: true,
       layoutMode: 'fitRows'
    });
  });
}

$(document).ready(function() {
  	
  	
  $('#AddToCart').click(function(event) {
	
    var formIsValid = true;
    var message = "Please fill this out and you will be able to add the item to your cart.";
    $(this).find('[name^="customsize"]').filter('.required, [required="required"]').each(function() {
      $(this).removeClass('error');
      if (formIsValid && $(this).val() == '') {
        formIsValid = false;
        message = $(this).attr('data-error') || message;
        $(this).addClass('error');
      }
    });
    if (formIsValid){
      
      //return true;
    }
    else {
      alert(message);
      event.stopPropagation();
    }
  }).find('input, select, textarea').focus(function() {
    $(this).removeClass('error');
  });
});
/*$(window).bind("load", function() {
   $(".breadcrumb_hide").show();
})*/
$(window).load(function() {
  $(".breadcrumb_hide").show();
  setTimeout(function(){ $('.accentCollection').css('position','static');
	setTimeout(function(){ $('.accentCollection').css('position','relative'); }, 100) }, 500)
  
});

$(document).ready(function() {
  bgSliderUpdate();
  BS($('.backStretch'));
  igramFeed();
  scrollFX();

  //Account Actions
  $('.address-delete').click(function(e) {
    e.preventDefault();
    var $el = $(this),
    formId = $el.data('form-id'),
    confirmMessage = $el.data('confirm-message');
    if (confirm(confirmMessage || "Are you sure you wish to delete this address?")) {
      Shopify.postLink('/account/addresses/' + formId, {'parameters': { '_method': 'delete' }});
    }
  });

  $('.editAddress').click(function(e) {
    e.preventDefault();
    var $id = $(this).attr('href').replace('#', '');
    $('#EditAddress_addNew').hide();
    $('.editAddressForm').hide();
    $('#EditAddress_' + $id).show();
    $('#EditAddress_' + $id).find('.cancelEdit').click(function(e) {
      e.preventDefault();
      $('#EditAddress_' + $id).hide();
      $('#EditAddress_addNew').show();
    });
  });

  //product page
  $('.accordHeaderLinks a').click(function(e) {
    e.preventDefault();
    var $t = $(this),
      section = $('.accordian section');
    $t.siblings().removeClass('active');
    $t.addClass('active');
    section.removeClass('active').filter($t.attr('href')).addClass('active')
  });

  //Pop Out functions
  $('.hasPop').click(function(e) {
    e.preventDefault();
    if($(window).width() > 736 || 1){
      var t = $(this),
        getPopout = t.attr('data-getPopout'),
        getPopout = $('#popUps .innerWrapper').filter(getPopout)
      t.addClass('active');
      openPopOut(getPopout, t);
	
    }
  });

  //back to top button
  $('.toTop').click(function(e) {
    e.preventDefault();
    $("html, body").animate({
      scrollTop: 0
    }, "1200");
  });

  //ajax update cart
  $('.qtyInput').change(function(){
    var qtyInput = $(this);
    Shopify.updateCartPage(qtyInput);
  });

  
  $(document).mouseleave(function(){
    showNewsLetterLeaving();
  });
  
	
});

$(window).load(function() {
  setSlick($('.slickSlider ul'));
  
  showNewsLetterLanding();
  
  $('main').animate({opacity: "1"},600)
});

$(window).scroll(function() {
  scrollFX();
});

$(window).resize(function() {
  
});

$(window).bind("load",function(e){
   if (typeof(atc_hover_color) !== 'undefined') {
  $('.productInfo form .button#AddToCart').mouseenter(function() {
      var $t = $(this);
     	isMouseOut = true;
     	
        var delayEffect = parseFloat(atc_hover_dely) * 1000;
     	
     	//setTimeout(function(){ $(this).attr('style','background: '+atc_hover_color+';') }, delayEffect);
     	setTimeout(function(){
          if(isMouseOut == true){
          	$t.css('background',atc_hover_color); 
          }
        }, delayEffect);

    });
    $('.productInfo form .button#AddToCart').mouseleave(function() {
      	isMouseOut = false;
        var $t = $(this);
     	$t.removeAttr('style');
    });
  }
  if (typeof(cart_slide_hover_color) !== 'undefined') {
    $('.header-cart .cart_button_checkout').mouseenter(function() {
        var $t = $(this);
          isMouseOut = true;

          var delayEffect = parseFloat(cart_slide_hover_dely) * 1000;

          //setTimeout(function(){ $(this).attr('style','background: '+atc_hover_color+';') }, delayEffect);
          setTimeout(function(){
            if(isMouseOut == true){
              $t.css('background',cart_slide_hover_color); 
            }
          }, delayEffect);

      });
      $('.header-cart .cart_button_checkout').mouseleave(function() {
          isMouseOut = false;
          var $t = $(this);
          $t.removeAttr('style');
      });
    }
  if (typeof(button_checkout_hover_color) !== 'undefined') {
    $('.header-cart .cart_button_secure').mouseenter(function() {
        var $t = $(this);
          isMouseOut = true;

          var delayEffect = parseFloat(button_checkout_hover_dely) * 1000;

          //setTimeout(function(){ $(this).attr('style','background: '+atc_hover_color+';') }, delayEffect);
          setTimeout(function(){
            if(isMouseOut == true){
              $t.css('background',button_checkout_hover_color); 
            }
          }, delayEffect);

      });
      $('.header-cart .cart_button_secure').mouseleave(function() {
          isMouseOut = false;
          var $t = $(this);
          $t.removeAttr('style');
      });
    }
    if (typeof(button_cartpage1_hover_color) !== 'undefined') {
    $('.cartfoot #extra_button_2_id.button').mouseenter(function() {
        var $t = $(this);
          isMouseOut = true;

          var delayEffect = parseFloat(button_cartpage1_hover_dely) * 1000;

          //setTimeout(function(){ $(this).attr('style','background: '+atc_hover_color+';') }, delayEffect);
          setTimeout(function(){
            if(isMouseOut == true){
              $t.css('background',button_cartpage1_hover_color); 
            }
          }, delayEffect);

      });
      $('.cartfoot #extra_button_2_id.button').mouseleave(function() {
          isMouseOut = false;
          var $t = $(this);
          $t.removeAttr('style');
      });
    }
  	if (typeof(button_cartpage2_hover_color) !== 'undefined') {
    $('.cartfoot #goToCheckout.button').mouseenter(function() {
        var $t = $(this);
          isMouseOut = true;

          var delayEffect = parseFloat(button_cartpage2_hover_dely) * 1000;

          //setTimeout(function(){ $(this).attr('style','background: '+atc_hover_color+';') }, delayEffect);
          setTimeout(function(){
            if(isMouseOut == true){
              $t.css('background',button_cartpage2_hover_color); 
            }
          }, delayEffect);

      });
      $('.cartfoot #goToCheckout.button').mouseleave(function() {
          isMouseOut = false;
          var $t = $(this);
          $t.removeAttr('style');
      });
    }
  if (typeof(button_upsell_hover_color) !== 'undefined') {
    $('.header-cart #AddToCartCS').mouseenter(function() {
        var $t = $(this);
          isMouseOut = true;

          var delayEffect = parseFloat(button_upsell_hover_dely) * 1000;

          //setTimeout(function(){ $(this).attr('style','background: '+atc_hover_color+';') }, delayEffect);
          setTimeout(function(){
            if(isMouseOut == true){
              $t.css('background',button_upsell_hover_color); 
            }
          }, delayEffect);

      });
      $('.header-cart #AddToCartCS').mouseleave(function() {
          isMouseOut = false;
          var $t = $(this);
          $t.removeAttr('style');
      });
    }
  if (typeof(button_general_hover_color) !== 'undefined') {
    $('.button:not(.add_to_cart_btn):not(.cart_button_checkout):not(.cart_button_secure):not(.cart_page_btn):not(.add_to_cart_cs):not(.btn_custom_config)').mouseenter(function() {
        var $t = $(this);
          isMouseOut = true;

          var delayEffect = parseFloat(button_general_hover_dely) * 1000;

          //setTimeout(function(){ $(this).attr('style','background: '+atc_hover_color+';') }, delayEffect);
          setTimeout(function(){
            if(isMouseOut == true){
              $t.css('background',button_general_hover_color); 
            }
          }, delayEffect);

      });
      $('.button:not(.add_to_cart_btn):not(.cart_button_checkout):not(.cart_button_secure):not(.cart_page_btn):not(.add_to_cart_cs):not(.btn_custom_config)').mouseleave(function() {
          isMouseOut = false;
          var $t = $(this);
          $t.removeAttr('style');
      });
    }
  $('.lazyloadimage').each(function(){
  	$(this).addClass('lazyload');
  });
  //alert($('.lazyloadimagebg').length);
  
  setInterval(function(){ 
    	
    $('.add_to_cart_btn').addClass('shake');
    setTimeout(function() {
        $('.add_to_cart_btn').removeClass('shake');
      }, 1000);
    
  }, 6000);
  
  setInterval(function(){ 
    	
    if($('.lazyloadimagebg').length > 0){
    	$('.lazyloadimagebg').each(function(){
         var $t = $(this);
         var $img = $t.attr('data-bg');

         $('<img/>').attr('src', $img).on('load', function() {
            $(this).remove();
            $t.css('background-image',"url('"+$img+"')");
            $t.removeClass('lazyloadimagebg');
            $t.addClass('lazyloadedimagebg');
        });
      });
    }
  }, 200);
   
});
loadGridPadding();
$(window).bind("load resize",function(e){
  //alert('loaded');
  $('body').removeClass('loading_body');
  $('body').removeClass('page_loading');
  
  
  
  BS($('.backStretch'));
  scrollFX();

  if($(window).width()<736){
    var findClass = $('.fullPageSectionsWrap .bgImage.fixedPosition');
    if(findClass.length){
    
      findClass.each(function(){
        $t = $(this);
        var bgurl = $t.css('background-image');
       // alert(bgurl);
        bgurl = bgurl.replace('url(', "");
        bgurl = bgurl.replace(')', "");                        
        $t.html('<img src='+bgurl+'>');
        $t.css('background-image','');
        $t.removeClass('bgImage');
        $t.removeClass('fixedPosition');
      })
      
    }
  }
});

bgSliderUpdate();
	headerHeightSet('load');
$(window).bind("load resize scroll touchmove",function(e){
  var evt = e.originalEvent.type;
	headerHeightSet(evt);
  bgSliderUpdate();
  
});
  
  function headerHeightSet(evt){
  	  var footerHeight = $('.band_footer').height();
  if(footerHeight > 0){
  	footerHeight = footerHeight;
  }
  if($('.sticky_addcart').length && $(window).width() < 736){
    if($('.sticky_addcart.hide_mobile_sticky_varient').length){
      	footerHeight = footerHeight + 35;
    }else{
    	footerHeight = footerHeight + 69;
    }
  	
  }
  $('.footer_band_space').css('margin-bottom',footerHeight+'px');
  
  var headerClass = 'header.locked';
  
  
  
  if($(window).width()>736 || 1){
  	
    
      if($('body').hasClass('template-index')){
        var headerClass = '.strapLine';
      }

    
	
    $('.prod_form.prod_form_footer.sticky_addcart.top').css('top',$('header.locked').height()+'px');
  }
  
    if($('header.band_enable_sticky').length){
    	$('header.band_enable_sticky').css('margin-top',$('.band_enable_sticky .strapLine').height()+'px');
      if($(window).width()>736){
      	$('.prod_form.prod_form_footer.sticky_addcart.top').css('top',$('.band_enable_sticky .strapLine').height()+'px');
      }
    }
    if($('header').length == 0 && $(window).width()>736){
    	$('.prod_form.prod_form_footer.sticky_addcart.top').css('top','0px');
    }
  
  
  var wheight = $(window).height(),
      sections = $('.fullPageSection .fixedPosition'),
      top = $(window).scrollTop(),
      
      headerHeight = $(headerClass).height(),
      wrap = $('.fullPageSectionsWrap');
    if(headerHeight == null){
    	headerHeight = 0;
    }
  
  if($('header.locked').length){
   	$('.header_wrapper').css('height',headerHeight+'px');
  }
    //console.log(headerHeight);
  

  if(sections.size()>0 && $(window).width()>736){
    sections.each(function(){
      var t = $(this),
          wrap = t.parent().parent(),
          parent = t.parent('.fullPageSection'),
          ptop = parent.offset().top - headerHeight;
      if(evt === "load" || evt === "resize"){
        t.height(wheight-headerHeight);
      }
      if(top > ptop){
       $(this).addClass('screenLock').css('top',headerHeight);
      }else{
        $(this).removeClass('screenLock').css('top',0);
      };
      //$(this).attr('data-w',(top - headerHeight )+wheight);
      //$(this).attr('data-y',wrap.offset().top + wrap.height() -headerHeight);      
	  if((top - headerHeight )+wheight  > wrap.offset().top + wrap.height() -headerHeight ){
        wrap.addClass('atBottom');
      }else{
        wrap.removeClass('atBottom');
      }
    });
    
  }
  }

function loadGridPadding(){
  $('.grid_sections, .main_video_full_wrap, .main_video_wrap').each(function(){
    if (window.innerWidth > 740) {
    	$(this).attr('style',$(this).attr('style_desktop'));
    }else{
    	$(this).attr('style',$(this).attr('style_mobile'));
    }
  });
}

function bgSliderUpdate(){
  
  if (window.innerWidth > 740) {
    $('.shopify-section').each(function(){
        var $t = $(this);
        var topPos = $t.offset().top;
        var winHeight = $(window).height();
        var heightToUpdate = $(window).height() - topPos;
       
        	heightToUpdate = heightToUpdate - 15;
      
		
        $t.find('.preventOverflow').css('height',heightToUpdate+'px');
      	$t.find('.preventOverflow').removeClass('hidewhennoheight');
        if($t.find('.homepage-banner-video').length){
// 			var videoWidth = $t.find('.homepage-banner-video video').attr('width');
//           	var videoHeight = $t.find('.homepage-banner-video video').attr('height');
//           	var winWidth = window.innerWidth;
          
//           	var radioDiff = winWidth/videoWidth;
          
//           	var newHeight = radioDiff * videoHeight;
//           	//alert(winWidth);
//           	$t.find('.homepage-banner-video video').css('height',newHeight+'px');
        }
     });
     
  }
  
  if($('.homepage-banner-video').length){
    var isBigHeight = $('.homepage-banner-video').width()/$('.homepage-banner-video').height();
    
    var videoWidth = $('.homepage-banner-video video').attr('width');
    var videoHeight = $('.homepage-banner-video video').attr('height');
    var winWidth = window.innerWidth;
    var radioDiff = winWidth/videoWidth;

   	var newHeight = radioDiff * videoHeight;
    //alert(isBigHeight);
    //alert(newHeight+' - '+$('.homepage-banner-video').height());
    if(newHeight > $('.homepage-banner-video').height()){
      	
    	$('.homepage-banner-video video').css('height',newHeight+'px');	
    	$('.homepage-banner-video video').css('width','100%');	
    }else{
      	var radioDiff = $('.homepage-banner-video').height()/videoHeight;
      	//alert(radioDiff);
      	var newWidth = radioDiff * videoWidth; 
      	
    	$('.homepage-banner-video video').css('height',$('.homepage-banner-video').height()+'px');	
    	$('.homepage-banner-video video').css('width',newWidth+'px');	
    }
    
   
  }
}

// -----------------------------------------------------------
// Select wrapper

var formSelectInit = function($el) {

  if (!$el.parent('.form-select-wrapper').length && !$el.hasClass('product-single__variants') && !$el.hasClass('select-bundle')) {
    $el.wrap('<div class="form-select-wrapper" />').parent().prepend('<span class="selected-text">' + $el.find('option:selected').text() + '</span>');
  }

  var formSelectText = function() {
    var newOption = $el.find('option:selected').text();
    $el.siblings('.selected-text').text(newOption);

    if ($el.hasClass('address-country')) {
      $el.closest('form').find('.address-province').trigger('change');
    }
  }

  var formSelectEvents = function() {
    $el.on('change', function() {
      formSelectText();
    });
  }

  formSelectEvents();
}

$(window).load(function() {
  var $select = $('select');

  if ($select.length) {
    $select.each(function(i, select) {
      formSelectInit($(select));
    });
  }
});


// -----------------------------------------------------------
// Header cart

var headerCart = function($el) {
  var moneyFormat = $el.data('header-cart'),
      $empty = $el.find('.header-cart-empty');

  var headerCartToggle = function(direction) {
    if (direction === 'show') {
      $el.addClass('animating');
         
      setTimeout(function() {
        var windowWidth = $(window).width();
        $el.addClass('visible');
        if (windowWidth < 768) {
        	//$('html').addClass('open_mobile_cart');
        }
        headerCartItemHeight();

        $('[data-product-form]').trigger('updateButton');
      }, 200);
    } else {
      $el.removeClass('visible');
      setTimeout(function() {
        $el.removeClass('animating');
      }, 200);
    }
  }

  var headerCartItemHeight = function() {
    var $headerCartItem = $el.find('[data-header-cart-item]');
    $headerCartItem.height('auto');

    $el.imagesLoaded(function() {
      $headerCartItem.each(function(i, el) {
        var $item = $(el);
        $item.height($item.height());
      });
    });
  }

  var headerCartUpdate = function(cart) {
	updateShippingBar(cart.total_price);
    var total = Shopify.formatMoney(cart.total_price, moneyFormat);
    $el.find('[data-header-cart-total]').html(total);
    var cartSaving = 0;
    var totalWithoutDiscount = 0;
    //console.log(itemQty);
    $('.cart_offer_amount').each(function(){
    	var itemQty = parseInt($(this).parent().find('.side_cart_qty input').val());
      	cartSaving = cartSaving + (parseInt($(this).attr('data-amount')) * itemQty);
    	totalWithoutDiscount = totalWithoutDiscount + (parseInt($(this).attr('data-without-discount')) * itemQty);
      	//alert(itemQty);
    });
    //alert(cartSaving);
    $el.find('[data-header-cart-saving]').html(Shopify.formatMoney(cartSaving, moneyFormat));
    $el.find('[data-header-cart-total-wo-discount]').html(Shopify.formatMoney(totalWithoutDiscount, moneyFormat))
    if(cartSaving){
    	$('.header-cart-footer-saving').show();
    }else{
    	$('.header-cart-footer-saving').hide();    
    }
    
    $('#cartItemCount').text(cart.item_count);

    if (cart.item_count === 0) {
      setTimeout(function() {
        //$empty.removeClass('hidden');
      }, 300);
    } else {
      //$empty.addClass('hidden');
    }
    addUpsellItemCartSlide();
  }

  var headerCartBuildProduct = function(cart, alreadyInCart, cartItem, quantity) {
    updateCartFully('open_cart');
    headerCartUpdate(cart);
   	headerCartToggle('show');
    
	return false;
    if (alreadyInCart) {
      //console.log('[data-price="'+cartItem.final_price+'"][data-header-cart-item="' + cartItem.id + '"]');
      
      $el.find('[data-price="'+cartItem.final_price+'"][data-header-cart-item="' + cartItem.id + '"]').find('input').val(quantity);
      if(product_cart_redirect == 'same'){
      		headerCartUpdate(cart);
      	headerCartToggle('show');
      }
    } else {
	//alert('new');
      Shopify.getProduct(cartItem.handle, function(product) {
        var options = product.options;
        //console.log(product);
        var variant;

        for (var i in product.variants) {
          if (product.variants[i].id === cartItem.id) {
            variant = product.variants[i];
          }
        }
        var varentTxt = '';
         for (var i in cartItem.options_with_values ) {

          if(cartItem.variant_options[i] != 'Default Title' && i != 'filterRelevantNotifications'){
          	varentTxt += '<span class="varient_cart_text">'+cartItem.options_with_values[i].value+'</span>'
          }
          
        }       
//         for (var i in cartItem.variant_options) {
//           if(cartItem.variant_options[i] != 'Default Title' && i != 'filterRelevantNotifications'){
//           	varentTxt += '<span> <strong>'+cartItem.variant_options[i]+'</strong></span>'
//           }
          
//         }

        var variantOptions = '';
        //console.log(cartItem);
        if (!cartItem.variant_options.length === 1 && cartItem.variant_options[0] === 'Default Title') {
          for (var i in cartItem.variant_options) {
            //console.log(cartItem.variant_options[i]);
           // variantOptions = variantOptions ? variantOptions + '<span>' + options[i].name + ' <strong>' + cartItem.variant_options[i] + '</strong></span>' : '<span>' + options[i].name + ' <strong>' + cartItem.variant_options[i] + '</strong></span>';
          }
        }
        var img = cartItem.image;
        if(typeof Shopify.Image != "undefined"){
          
			img = Shopify.Image.getSizedImageUrl(cartItem.image, '160x');
        }
        var image = img,
            price = Shopify.formatMoney(cartItem.final_line_price, moneyFormat);

        var variantQuantity = variant.inventory_management === 'shopify' && variant.inventory_policy === 'deny'
                                ? variant.inventory_quantity
                                : 0;
        variantQuantity = variantQuantity === 0
                            ? ''
                            : 'max="' + variantQuantity + '"';
		
        	var linkAtag = '<a href="' + cartItem.url + '">' + cartItem.product_title + '</a>';
        
        var variantComparePrice = '';
        var differentAmount = 0;
        
        if(variant.compare_at_price){
            var differentAmount = variant.compare_at_price - cartItem.price;
        	var variantComparePrice = ' <span class="money strip"> '+Shopify.formatMoney(variant.compare_at_price, moneyFormat)+' </span>';
        }
        
        
        	var minusIcon = '<?xml version="1.0" encoding="utf-8"?> <!-- Generator: Adobe Illustrator 17.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0) --> <!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd"> <svg version="1.1" id="Calque_3" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="20px" height="20px" viewBox="0 0 595.28 841.89" enable-background="new 0 0 595.28 841.89" xml:space="preserve"> <path fill="#FFFFFF" d="M572.401,398.176H22.85c-12.591,0-22.8,10.209-22.8,22.8c0,12.591,10.209,22.8,22.8,22.8h549.55 c12.591,0,22.8-10.209,22.8-22.8C595.201,408.385,584.992,398.176,572.401,398.176z"/> </svg>';
        
        
        
          	var plusIcon = '<?xml version="1.0" encoding="utf-8"?> <!-- Generator: Adobe Illustrator 17.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0) --> <!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd"> <svg version="1.1" id="Calque_3" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="20px" height="20px" viewBox="0 0 595.28 841.89" enable-background="new 0 0 595.28 841.89" xml:space="preserve"> <path fill="#FFFFFF" d="M572.439,398.175H320.452V146.188c0-12.592-10.209-22.801-22.801-22.801 c-12.592,0-22.801,10.209-22.801,22.801v251.987H22.862c-12.592,0-22.801,10.21-22.801,22.801c0,12.592,10.21,22.801,22.801,22.801 h251.987v251.987c0,12.592,10.21,22.801,22.801,22.801c12.592,0,22.801-10.209,22.801-22.801V443.777h251.987 c12.592,0,22.801-10.209,22.801-22.801C595.24,408.384,585.031,398.175,572.439,398.175z"/> </svg>';
        
       // console.log(cartItem);
        var quantityLabel = '';
        var varentTxtWrap = '';
        if(varentTxt != '' || variantOptions != ''){
        	varentTxtWrap = '<div class="header-cart-item-options" data-header-cart-options>' + varentTxt +
                variantOptions +
          	  	'</div>';
        }
        $el.find('[data-header-cart-items]').prepend(
          '<article class="header-cart-item" data-header-cart-item="' + cartItem.id + '" data-price="'+cartItem.final_price+'" data-product_id="'+cartItem.product_id +'">' +
            '<a class="header-cart-item-image" href="' + cartItem.url + '">' +
              '<img src="' + image + '">' +
            '</a>' +
            '<div class="header-cart-item-info"><span class="remove_cart_product"><svg width="9" viewBox="0 0 10 10"><path d="M9.677 8.118a1.102 1.102 0 11-1.559 1.56L5 6.558 1.882 9.677a1.102 1.102 0 11-1.56-1.559L3.442 5 .323 1.882A1.102 1.102 0 111.882.322L5 3.442 8.118.323a1.102 1.102 0 111.56 1.559L6.558 5l3.118 3.118z" fill="#cacaca" fill-rule="nonzero"></path></svg></span>' +
              '<h3>'+linkAtag+'</h3>' + varentTxtWrap +
              	'<div class="cart_slide_price_qty_wrapper"><div class="cart_slide_price"><span class="money">' + price + variantComparePrice + '</span>' + 
          	  	'<span class="cart_offer_amount" data-amount="'+differentAmount+'" data-without-discount="'+variant.compare_at_price+'"></span></div>'+
                '<div class="header-cart-item-options slide_cart_qty_wrap" data-header-cart-options=""><span class="side_cart_qty">' +
                  quantityLabel +'<button class="slide_card_minus" type="button" data-header-cart-quantity-decrease="' + cartItem.id  +'">'+minusIcon+'</button> ' +
          		  '<input type="number" min="0" ' + variantQuantity + ' value="' + cartItem.quantity + '" data-header-cart-quantity-update="' + cartItem.id  +'">' +
                  '<button class="slide_card_plus" type="button" data-header-cart-quantity-increase="' + cartItem.id  +'">'+plusIcon+'</button> ' +
                '</span></div>' +
              '</div></div>' +
            
          '</article>'
        );
		headerCartUpdate(cart);
        headerCartToggle('show');
        addUpsellItemCartSlide();
        addScrollBarEvent();
      });
    }
    
  }
  $('#AddToCartCS').click(function(){
  	//headerCartAddItem($(this).attr('data-variant_id'));
  });
  var headerCartAddItem = function(variantId,final_price) {
    var alreadyInCart = false;

    if ($el.find('[data-header-cart-item="' + variantId + '"]').length) {
      alreadyInCart = true;
      	
    }

    Shopify.getCart(function(cart) {
      var quantity;
      var cartItem;
      //console.log(cart)
      $.each(cart.items, function(i, el) {
       	
        if (el.id === parseInt(variantId, 10) && el.final_price == final_price) {
          cartItem = el;
          quantity = el.quantity;
        }
      });
      if(alreadyInCart){
        
      	if($el.find('[data-header-cart-item="' + variantId + '"]').attr('data-price') != cartItem.final_price){
        	alreadyInCart = false;
        }
      }

      headerCartUpdate(cart);
      headerCartBuildProduct(cart, alreadyInCart, cartItem, quantity);
    });
  }

  var headerCartEditQuantity = function(event, direction) {
    var $target = $(event.currentTarget),
        id = $target.data('header-cart-quantity-' + direction),
        $input = $target.closest('[data-header-cart-options]').find('input'),
        maxQuantity = $input.attr('max') ? parseInt($input.attr('max'), 10) : 1000000,
        quantity = parseInt($input.val(), 10);
    	var lineitem = $target.parents('.header-cart-item').attr('data-lineitem');
	
    quantity = direction === 'increase' ? quantity + 1 : quantity - 1;
    quantity = quantity <= maxQuantity ? quantity : quantity - 1;
    
    if(direction == 'update'){
    	quantity = parseInt($input.val(), 10);
    }else{
    	$input.val(quantity);
    }

    if (quantity === 0) {
      
      var $parent = $target.parents('.header-cart-item').attr('data-product_id');
      var parentElement = false;
      if($('.upsell_object_'+$parent).length){
        //console.log($( ".header-cart-item[data-header-cart-item='"+$('.upsell_object_'+$parent).attr('data-variant_id')+"']" ).attr('data-header-cart-item'));
      	if($( ".header-cart-item[data-header-cart-item='"+$('.upsell_object_'+$parent).attr('data-variant_id')+"']" ).length){
          	//console.log('hello');
			parentElement = $( ".header-cart-item[data-header-cart-item='"+$('.upsell_object_'+$parent).attr('data-variant_id')+"']" );
          	setTimeout(function(){ 
            

              $( ".header-cart-item[data-header-cart-item='"+$('.upsell_object_'+$parent).attr('data-variant_id')+"']" ).find('input').val(0);
              $( ".header-cart-item[data-header-cart-item='"+$('.upsell_object_'+$parent).attr('data-variant_id')+"']" ).find('input').trigger('change');
            }, 1000);
          	//headerCartRemove(parentElement, $('.upsell_object_'+$parent).attr('data-variant_id'), headerCartUpdate);
          	
        }
      }
      //console.log($parent);
      
      var $item = $target.closest('[data-header-cart-item]');
      
      headerCartRemove($item, id, headerCartUpdate);
      
    } else {
//       Shopify.changeItem(id, quantity, function(cart) {
//         updateCartFully();

//         headerCartUpdate(cart);
//       });
      $.ajax({
        type: 'POST',
        url: '/cart/change.js',
        data: 'quantity=' + quantity + '&line=' + lineitem,
        dataType: 'json',
        success: function(cart) {
           updateCartFully('changed_item');
           headerCartUpdate(cart);
             }
        });
    }
    addUpsellItemCartSlide();
  }

  var headerCartRemove = function($item, id, callback) {
    Shopify.removeItem(id, function(cart) {
      $item.addClass('removed');

      setTimeout(function() {
        //$item.remove();
        headerCartUpdate(cart);
        updateCartFully();

      }, 200);
		
      callback(cart);
    });
  }

  var headerCartEvents = function() {
    $el.on('click', '[data-header-cart-quantity-increase]', function(event) {
      headerCartEditQuantity(event, 'increase');
    });
    $el.on('change', '[data-header-cart-quantity-update]', function(event) {
      headerCartEditQuantity(event, 'update');
    });

    $el.on('click', '[data-header-cart-quantity-decrease]', function(event) {
      headerCartEditQuantity(event, 'decrease');
    });

    $el.on('update', function(event, variantId) {

        var variantId = variantId.split("-");
     // console.log(variantId)
      headerCartAddItem(variantId[0],variantId[1]);
    });
	
    $el.on('mouseleave', function() {
      headerCartToggle('hide');
    });
	
    $(window).on('resize', function() {
      headerCartItemHeight();
    });
  }
//alert('one');
  headerCartItemHeight();
  headerCartEvents();
}
$('.prod_form').click(function() {
//console.log('form event');
//	$('.productMainImage').attr('data-attrchange','false');
});
$(window).load(function() {

});
    headerCart($('[data-header-cart]'));

  
  	

// -----------------------------------------------------------
// Product add to cart

var productAdd = function($el,cartType) {

  var adding = false;

  var productUpdateButton = function(reset, success) {
    //console.log($el.attr('data-product_id'));
    var $button = $('.add_to_cart_btn_'+$el.attr('data-product_id')),
        $buttonText = $button.find('#AddToCartText'),
        text = $button.attr('data-text');

    if (reset) {
      $button.css('background','');
      $button
        .removeClass('active')
        .attr('disabled', 'disabled');
      
      $('#AddToCartCS')
        .removeClass('active')
        .removeClass('disabled')
        .removeAttr('disabled');
      if (success) {
        $buttonText.text(text);
       // window.buttonInterval = setInterval(function() {
          $buttonText.text(text);
          $button
            .removeClass('disabled')
            .removeAttr('disabled');
       //   clearInterval(window.buttonInterval);
       // }, 4000);
      } else {
        $button
          .removeClass('disabled')
          .removeAttr('disabled');
      }
    } else {
      $('#AddToCartCS')
      	.addClass('active disabled')
        .attr('disabled', 'disabled');
      $button
        .addClass('active disabled')
        .attr('disabled', 'disabled');
    }
  }

  var productAddError = function(errors) {
    var error = $.parseJSON(errors.responseText);

    if (error.message === 'Cart Error' || 1) {
      $el.find('#AddToCart').append(
        '<span class="product-form-error">' + error.description + '</span>'
      );

      var $error = $el.find('.product-form-error');

      $error.addClass('animating');
      setTimeout(function() {
        $error.addClass('visible');
        productUpdateButton(true);
        adding = false;
        setTimeout(function() {
          $error.removeClass('visible');
          setTimeout(function() {
            $error.remove();
          }, 250);
        }, 3000);
      }, 200);
    }
  }

  var productAddItem = function(event,productId,variantId) {
    if (!adding) {
      
      adding = true;
      productUpdateButton();
      

      /* start code for kolt bundle quantity */
	  var koltBundleQt = $('.kolt-bundle-qt');
      
      if(koltBundleQt && koltBundleQt.length > 0){
        event.stopPropagation();
        var select_list_qt = $('.container-bundle-qt.active .qt-variants-select')
        var title_var_qt = "";
        if(select_list_qt && select_list_qt.length > 0){
          select_list_qt.each(function(item_select){
            title_var_qt += $(select_list_qt[item_select]).val();
            if(item_select < select_list_qt.length -1){
              if(select_list_qt[item_select+1].id.indexOf(select_list_qt[item_select].id) != -1)
				title_var_qt += "/";                
              else
	            title_var_qt += " / ";
            }
          })
          var variant_id = "";
          $('.container-bundle-qt.active #ProductSelect-product-template option').each(function(){
            var variant_title = $(this).text()
            if(title_var_qt.trim() == variant_title.trim()){
              variant_id = $(this).val();
            }
          });
          if(variant_id)
            var data_obj = {id:variant_id, quantity: 1};
        }
        else{
          var input_select = $('.container-bundle-qt.active input[name="id"]');
          if(input_select.val())
          	var data_obj = {id:input_select.val(), quantity: 1};
        }
      }
      
      if(variantId){
      	var data_obj = {id:variantId, quantity: 1};
      }
      
      var delegateTarget = event.delegateTarget;
      if(data_obj && event.delegateTarget && event.delegateTarget.className.indexOf("sticky") > -1){
        if($(event.delegateTarget).find("input.quantity")){
			data_obj.quantity = $(event.delegateTarget).find("input.quantity").val(); 
          	data_obj.quantity = parseInt(data_obj.quantity);
        }
      }
      
      if(typeof CHKX !== "undefined" && CHKX.variables && CHKX.variables.shopActive && product_cart_redirect == "checkout" && data_obj){
        var urlCheckoutX = "https://"+CHKX.variables.subdomain+".checkout-x.com/f/"+CHKX.common.shopId()+"/c/n/";
        urlCheckoutX += data_obj.id+":"+data_obj.quantity;
		window.location.href=urlCheckoutX;
        return;
      }
      /* end code for kolt bundle quantity */
      
      jQuery.ajax({
        type: 'POST',
        url: '/cart/add.js',
        data: (data_obj !== undefined ? data_obj : jQuery('.product_main_form_'+productId).serialize()),
        dataType: 'json',
        success: function(response) {
         // alert('add');
          if($('body').hasClass('popOutFix')){
				Shopify.redirectToCheckout();
                  //alert('hello');
            	return;
            }
          	if(variantId){
              if($('#AddToCartCS').attr('data-after_added') == 'Hide'){
              	$('#upsell_product_main').slideUp();
              }
            }
          
          $('[data-header-cart]').trigger('update', response.variant_id+"-"+response.final_price);
          adding = false;
			
       
          if(product_cart_redirect == 'same'){
            if(!$('html').hasClass('open_mobile_cart')){
              //$('html').addClass('open_mobile_cart');

            }
            }

		
          if(product_cart_redirect == 'checkout'){
              $('.header-cart').remove();
            if(upsell_enable == true){
              openPopOut('#CartUpsellPopup');
              $('.cart_upsell_popup .productMainImage').slick('setPosition');
          $('#CartUpsellPopup .product-single__variants option:eq(0)').prop('selected', true);
            }else{
                  window.location.href = "/"+product_cart_redirect;
            }


                    var windowWidth = $(window).width();
                    if (windowWidth > 768 || 1) {
                        if(!$('html').hasClass('open_mobile_cart')){
                          $('html').addClass('open_mobile_cart');
                          return false;
                        }

                    }


            }else if(product_cart_redirect == 'cart'){
          	 window.location.href = "/"+product_cart_redirect;
          }
        },
        error: function(XMLHttpRequest, textStatus) {
          productAddError(XMLHttpRequest);
        }
      });
    }
  }

  var productAddEvents = function() {
    
    $el.on('click', '#AddToCart', function(event) {
      event.preventDefault();
      var productId = $(this).attr('data-product_id');
     
      productAddItem(event,productId);
    });
   	//$('body').on('click', '#AddToCartCS', function(event) {
    
    


    $el.on('updateButton', function() {
      productUpdateButton(true, true);
    });
    if(cartType == 'upsell'){
    	$('#AddToCartCS').click(function(event){

          event.preventDefault();
          var productId = $(this).attr('data-product_id');
         var variantId = $(this).attr('data-variant_id');
          productAddItem(event,productId,variantId);

            return false;
        });
    }
  }

  productAddEvents();
}

function openUpsellPopup(productId){
	var popUpId = '#CartUpsellPopup_upsell_'+productId;
	if($(popUpId).length){
      openPopOut(popUpId);
      $(popUpId+' .productMainImage').slick('destroy');
      $(popUpId+' .thumbs_list_frame').slick('destroy');
      loadProductSlider($(popUpId+' .productImages'));
    }
}

if ($('.home-kickstarter').length > 0) {

      // PIE

      $('.kickstarter__graphic.pie').html('<canvas id="kickstarter__pie--help" width="110" height="110"></canvas><canvas id="kickstarter__pie" width="110" height="110"></canvas>');

      var progress = 0,
          pieI = null,
          pieValue = Math.min( parseInt($('.kickstarter__graphic').data('value')) / 100, 1 ),
          pieColor = $('.kickstarter__graphic').data('color'),
          pieCanvas = document.getElementById('kickstarter__pie'),
          context = pieCanvas.getContext('2d'),
          centerX = pieCanvas.width / 2,
          centerY = pieCanvas.height / 2,
          radius = 45,
          progress = 0;

      context.lineWidth = 15;
      context.strokeStyle = pieColor;
      context.lineCap = 'round';

      pieI = setInterval(function() {
        progress = progress + 0.0025;
        context.clearRect(0, 0, pieCanvas.width, pieCanvas.height);
        context.beginPath();
        context.arc(centerX, centerY, radius, 0, (2*progress) * Math.PI, false);
        context.stroke();
        if (progress >= pieValue) {
          clearInterval(pieI);
        }
      }, 5);

      var pieCanvasHelp = document.getElementById('kickstarter__pie--help'),
          contextHelp = pieCanvasHelp.getContext('2d'),
          centerXHelp = pieCanvasHelp.width / 2,
          centerYHelp = pieCanvasHelp.height / 2,
          radiusHelp = 45;

      contextHelp.lineWidth = 15;
      contextHelp.strokeStyle = '#e9e9e9';
      contextHelp.lineCap = 'round';
      contextHelp.beginPath();
      contextHelp.arc(centerXHelp, centerYHelp, radiusHelp, 0, 2 * Math.PI, false);
      contextHelp.stroke();

      // BAR

      var barValue = Math.min(parseInt($('.kickstarter__graphic.bar').data('value')), 100);
      $('.kickstarter__graphic.bar').append('<div class="value"></div>');
      $('.kickstarter__graphic.bar .value').css('width', barValue + '%');

    }

$(document).ready(function(){
  	var isNoVarient = $('.product-single__variants').length;
    if($('.productInfo').length && isNoVarient == 0){
        

        var isInput = $('#prodForm > input').length;
        //$('.discount_price_per').hide();
        if(isInput == 0){
          //alert('here');
          $('.discount_price_per').show();
          var moneyFormat = $('.header-cart').data('header-cart');
          var offerPer = (($('#prodForm > input').attr('data-compare_at_price') - $('#prodForm > input').attr('data-price'))/$('#prodForm > input').attr('data-compare_at_price')) * 100;
          var offerAmount = $('#prodForm > input').attr('data-compare_at_price') - $('#prodForm > input').attr('data-price');
          offerAmount = Shopify.formatMoney(offerAmount, moneyFormat);
          offerPer = Math.round(offerPer);
          $('.discount_price_amount').text(offerAmount);
          $('.discount_price_percentage').text(offerPer);
        }
    }
  
  
});


jQuery(document).ready(function(){
    // This button will increment the value
    $('.qtyplus').click(function(e){
        // Stop acting like a button
        e.preventDefault();
        // Get the field name
        fieldName = $(this).attr('field');
        // Get its current value
        var currentVal = parseInt($('input[id='+fieldName+']').val());
        // If is not undefined
        if (!isNaN(currentVal)) {
            // Increment
            $('input[id='+fieldName+']').val(currentVal + 1);
          	$('input[id='+fieldName+']').attr('value',currentVal + 1);
        } else {
            // Otherwise put a 0 there
            $('input[id='+fieldName+']').val(0);
          	$('input[id='+fieldName+']').attr('value',0);
        }
      
    });
    // This button will decrement the value till 0
    $(".qtyminus").click(function(e) {
        // Stop acting like a button
        e.preventDefault();
        // Get the field name
        fieldName = $(this).attr('field');
        // Get its current value
        var currentVal = parseInt($('input[id='+fieldName+']').val());
        // If it isn't undefined or its greater than 0
        if (!isNaN(currentVal) && currentVal > 0) {
            // Decrement one
            $('input[id='+fieldName+']').val(currentVal - 1);
          	$('input[id='+fieldName+']').attr('value',currentVal + 1);
        } else {
            // Otherwise put a 0 there
            $('input[id='+fieldName+']').val(0);
          	$('input[id='+fieldName+']').attr('value',0);
        }
    });
  
  
  /*
  
  	$('.header-cart-wrapper-inner a').click(function(){
  		var windowWidth = $(window).width();
        if (windowWidth > 768 || 1) {
          	if(!$('.header-cart').hasClass('invisible')){
              $('.header-cart').toggleClass('invisible');
              $('.header-cart').toggleClass('visible');
              return false;
            }
        }
    	
 
  });

    $('.header-cart-wrapper-inner a').click(function(){
    var hidden = $('.header-cart.slide.invisible');

        hidden.animate({"right":"10px"}, "slow");

    });*/
	$(document).on("click",".open_mobile_cart", function (event) {
    if($(event.target).hasClass('open_mobile_cart')){
    	$('html').removeClass('open_mobile_cart');
          	$('.header-cart').removeClass('visible');
            $('.header-cart').removeClass('animating');
          	return false;
    }
  });
  $('#mainWrap,.mobile_cart_close i').click(function(){
  		var windowWidth = $(window).width();
        if (windowWidth < 768 || 1) {
          if($('html').hasClass('open_mobile_cart')){
          	$('html').removeClass('open_mobile_cart');
          	$('.header-cart').removeClass('visible');
            $('.header-cart').removeClass('animating');
          	return false;
          }
          	
        }
 
  });
  
  
    $('body').on('click', '[name="checkout"], [name="goto_pp"], [name="goto_gc"]', function() {
      if ($('#agree').is(':checked')) {
        $(this).submit();
      }
      else {
        $('.cart_term_error').slideDown();
        return false;
      }
     });
     
  
   
    $('body').on('click', '.cart_button_secure', function() {
      
      	 if(upsell_enable == true){
        	openPopOut('#CartUpsellPopup');
      		$('.cart_upsell_popup .productMainImage').slick('setPosition');
      		$('#CartUpsellPopup .product-single__variants option:eq(0)').prop('selected', true);
          }else{
				return true;
          }
      
      
      return false;
     });
   
  
});
 (function($) {
    $.fn.hasScrollBar = function() {
        return this.get(0).scrollHeight > this.height();
    }
})(jQuery);
  function addUpsellItemCartSlide(){
    
    var needProductId = $('.header-cart-items .header-cart-item:last').attr('data-product_id');
    $('#upsell_product_main').hide();
    

    if(needProductId){
      
      //<input class="upsell_object_3679157551188" data-title="All New for test" data-img="//cdn.shopify.com/s/files/1/2154/6253/products/download_100x100.jpg?v=1604165506" data-variant_title="Default Title" data-price="1000" data-compare_at_price="1200" data-product_id="4790464610388" data-variant_id="32928340705364" type="hidden">
      if($('.upsell_object_'+needProductId).length){
      	var $t = $('.upsell_object_'+needProductId);
        var price = Shopify.formatMoney($t.attr('data-price'), moneyFormat);
        var comparePrice = $t.attr('data-compare_at_price') ? Shopify.formatMoney($t.attr('data-compare_at_price'), moneyFormat) : '';
        var showHideAfter = $t.attr('data-after_added');
        
        $('.upsell_img_main').attr('src',$t.attr('data-img'));
        $('.cart_slide_upsell_title').html($t.attr('data-title'));
        $('.cart_slide_upsell_varient_title').text($t.attr('data-variant_title'));
        $('.cv_upsell_compprice').html(comparePrice);
        $('.cv_upsell_price').html(price);
        $('#AddToCartCS').attr('data-product_id',$t.attr('data-product_id'));
        $('#AddToCartCS').attr('data-variant_id',$t.attr('data-variant_id'));
        $('#AddToCartCS').removeAttr('disabled');
        $('#AddToCartCS').removeClass('active');
        $('#AddToCartCS').removeClass('disabled');
        $('#AddToCartCS').attr('data-after_added',$t.attr('data-after_added'));
        $( ".header-cart-item[data-header-cart-item='"+$t.attr('data-variant_id')+"']" ).addClass('upsell_cart_product');
        if(showHideAfter == 'Show' || !$( ".header-cart-item[data-header-cart-item='"+$t.attr('data-variant_id')+"']" ).length){
        	$('#upsell_product_main').show();
        }
        
      }
    }
    $('.header-cart').attr('data_cart_size',$('.header-cart .header-cart-item').length);
    addScrollBarEvent();
    
  }
  function addScrollBarEvent(){
  	if($('.header-cart-items').hasScrollBar() == true){
    	$('.header-cart-items').parent().addClass('scroll_bar_active')
    }else{
    	$('.header-cart-items').parent().removeClass('scroll_bar_active')
    }
  }
$('.header-cart-items').on('scroll', function() {
// 		console.log('first',Math.round($(this).scrollTop() + $(this).innerHeight()));
//   console.log('next',Math.round($(this)[0].scrollHeight));
        if(Math.round($(this).scrollTop()) + Math.round($(this).innerHeight() >= $(this)[0].scrollHeight)) {
          //console.log('add class');
          $('.header-cart').addClass('scroll_reach_bottom');
//            $('.cart_slide_scroll_svg_warp').slideUp( "1000", function() {
//              $('.cart_slide_below_bg svg').slideDown( "1000");
//            });


        }else{

          $('.header-cart').removeClass('scroll_reach_bottom');
//           $('.cart_slide_below_bg svg').slideUp('1000', function() {
// 			$('.cart_slide_scroll_svg_warp').slideDown('1000');

//           });
        
   
        }
    })
$('.cart_slide_scroll_svg_warp').click(function(){
  	//$('.header-cart-items').scrollTop($('.header-cart-items')[0].scrollHeight);
	//$(".header-cart-items").animate({ scrollTop: $('.header-cart-items').prop("scrollHeight")}, 500);
      var $target = $('.header-cart-items'); 
  	//alert( $('.header-cart-items')[0].scrollHeight - $target.height());
    $target.animate({scrollTop: $('.header-cart-items')[0].scrollHeight - $target.height()}, 500);
  	return false;
});
function openpopupnew(url,name) {
 // alert(url);
  window.open(url,name,'width=500,height=300');	
}
$(document).ready(function() {
	$('body').on('click', '.featuredImage.trigger_zoom', function(e) {
      	//alert('ya');
    	return false;
    });
	$('body').on('click', '.featuredImage.trigger_zoom', function(e) {
      	e.stopImmediatePropagation();
      var $productId = $(this).attr('data-product_id');
      var $links = $('.fancybox_'+$productId);
      var counter = 0;
      //if($(this).parents('.productImages').find('.productThumbs a.active').length){
      	var counter = $(this).attr('data-count');
      //}
      //alert(counter);
      $.fancybox.open( $links, {
          loop : true
      }, counter );
      	
      return false;
      	
    });
    $('body').on('click', '.featuredImage.trigger_zoom img1', function() {
    	var $zoomImageClass = '.zoom_images';
		
      	var counter = 0;
      	
      	var $links = $('.fancybox');
      	$.fancybox.open($links);
      
      	if($(this).parents('.productImages').find('.productThumbs a.active').length){
      		//$zoomImageClass = '.zoom_images.'+$(this).parents('.productImages').find('.productThumbs a.active').attr('data-image_zoom');
      		//var instance = $.fancybox.getInstance();

          	//var counter = $(this).parents('.productImages').find('.productThumbs a.active').attr('data-counter');
			//alert(counter);	
          	//instance.jumpTo( counter );
        }
      	//$(this).parents('.productImages').find('.zoom_images').trigger('click');
      	//$.fancybox.getInstance().jumpTo(counter);

      	//$(this).parents('.productImages').find(".zoom_images[data-image='"+$src+"']").trigger('click');
		//$.fancybox.open($($zoomImageClass));
      	
      	//$(this).parents('.productImages').find($zoomImageClass).trigger('click');
        
      	
      	
    });
  	$('.editor_app_grid a').click(function(){
		var windowWidth = $(window).width();
    //$('body').on('click', '.scroll_link_trigger', function() {
      //alert('hi');$("#product_image_list")
      var $p =	$($(this).attr('href'));
      if($p.length){
      
      	//console.log($p.offset().top);
        //console.log($(document).scrollTop());
        if($p.offset().top > $(document).scrollTop()){
        	var heightToscroll = (Math.ceil($p.offset().top)) - ($('header.locked').height() + 40);
        }else{
        	//var heightToscroll = (Math.ceil($p.offset().top - $p.offset().top)) - ($('header.locked').height() + 40);
          var heightToscroll = (Math.ceil($p.offset().top)) - ($('header.locked').height() + 40);
        }
        if (windowWidth > 768){
        	if($('.sticky_addcart.top').length){
                heightToscroll = heightToscroll - ($('.sticky_addcart.top').height());
            }
        }else{
        	if($('.sticky_addcart.topmob').length){
                heightToscroll = heightToscroll - ($('.sticky_addcart.topmob').height());
            }
        }
        //console.log(heightToscroll);
        $('html, body').animate({
          scrollTop: heightToscroll
        }, 500);

        return false;
        }
   });
  	$('.scroll_link_trigger').click(function(){

    //$('body').on('click', '.scroll_link_trigger', function() {
      //alert('hi');
      var $p =	$($(this).attr('href'));
      if($p.length){
      
      

        var heightToscroll = (Math.ceil($p.offset().top)) - $('header.locked').height();


        $('html, body').animate({
          scrollTop: heightToscroll
        }, 500);

        return false;
        }
   });
  	$('.scroll_link1').click(function(){
      var $p =	$(this).parents('.shopify-section');

      var heightToscroll = ($p.offset().top + $p.height()) - $('body > header').height();


      $('html, body').animate({
        scrollTop: heightToscroll
      }, 500);
      
      return false;
   });
  $('[data-product-form]').each(function(){
  	productAdd($(this));
  });
if($('#AddToCartCS').length){
  	productAdd($(this),'upsell');
  }
   
    function onPlayerStateChange(event) {
        if(!playing){
            alert('hi');
            playing = true;
        }
    }
  
    $('.popupVideo').click(function(){
		var $link = $(this).attr('href');
    	$('.popup_video iframe').attr('src',$link);
        $('.popup_video').addClass('active');
      	return false;
   	});
  	$('.close_video_popup').click(function(){
		var $p = $(this).parent();
      	$p.removeClass('active');
      	$p.find('iframe').attr('src','');
      	return false;
   	});
  	var userAgent = window.navigator.userAgent;

    if (userAgent.match(/iPad/i) || userAgent.match(/iPhone/i)) {
      if (!userAgent.match(/Messenger/i) && !userAgent.match(/Instagram/i)) {
      	if($('.shopify-section .preventOverflow').length){
          $('.shopify-section .preventOverflow').each(function(){
          	var $t = $(this);
            var $img = $t.css('background-image');
            $img = 'rgba(0, 0, 0, 0) '+$img+' no-repeat scroll 50% 50% / cover';
            //alert($t.css('background-image'));
            $t.css('background',$img);
          });
        }
      }
    }
    else {
      	
       //alert('here');
    }
  	var decodeHTML = function (html) {
      var txt = document.createElement('textarea');
      txt.innerHTML = html;
      return txt.value;
  	};
});
  
//   $('.band_icon1 svg').on('load', function() {
//    $(this).parent().parent().addClass('loaded_icon');
//   console.log('loaded');
// });
//   $('.band_slider_item').each(function(){
//     if($(this).find('svg').length == 0){
//     	$(this).addClass('loaded_icon');
//     }
//   });
//   if($('.strapLine_slider').length){
//   	var checksliderBandVar = setInterval(checksliderBand, 100);
//     function checksliderBand() {
//       var loadedCount = $('.band_slider_item.loaded_icon').length;
//       console.log(loadedCount);
//       if(loadedCount == 0){
        
//       	clearInterval(checksliderBandVar);
//       }
      
//       //
//     }
//   }

  $('.band_sliders').on('init', function(event, slick){
    console.log('intr');
    $('.strapLine_slider').addClass('slider_loaded');
  	$('.band_icon svg').on('load', function() {
       //$(this).parent().parent().addClass('loaded_icon');

    });
  });

$('.band_sliders').slick({
  infinite: true,
  slidesToShow: 3,
  slidesToScroll: 3,
  autoplay: true,
  autoplaySpeed: 2000,
  arrows: false,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
  ]
});
  

$('body').on('click', '.single-option-radio label', function(e) {
      //	$(this).parents('#productHead').find('.productMainImage').attr('data-attrchange','false');
    });
  function loadProductSlider($t){

  	  if($t.find('.product_image_list_wrapper').length){
        var $pid = $t.find('.product_image_list_wrapper').attr('data-product_id');
        var $actualPid = $t.find('.product_image_list_wrapper').attr('data-actual_pro_id');


		$('.productMainImage_'+$pid).on('init', function(event, slick){
    		$(this).parent().removeClass('slider_loading_zoom');
          	showSectionByEffect();
          	$('.productMainImage_'+$pid).attr('data-attrchange','true');
          	
        });
        $('.thumbs_list_frame_'+$pid).on('init', function(event, slick){
    		$(this).parents('.productImages').find('.thum_slider_loading_zoom').removeClass('thum_slider_loading_zoom');
          	showSectionByEffect();
          	
        });
        var SlickSliderMainImage = $('.productMainImage_'+$pid).slick({
          slidesToShow: 1,
          slidesToScroll: 1,
          arrows: false,
          infinite:false,
          //touchThreshold:1,
          //fade: true,
          asNavFor: '.thumbs_list_frame_'+$pid
        });
        $('.productMainImage_'+$pid).on('beforeChange', function(event, slick, currentSlide, nextSlide){
          //console.log('here')
          $(this).parents('.productImages').find('.zoomOutCustom_trigger_product').removeClass('zoomOutCustom_trigger_product');
        });
        
        $('.product_image_list_next_'+$pid).click(function() {
          //$('.productMainImage_'+$pid).attr('data-attrchange','false');
          SlickSliderMainImage.slick('slickNext')
        });
        $('.product_image_list_prev_'+$pid).click(function() {
          //$('.productMainImage_'+$pid).attr('data-attrchange','false');
          SlickSliderMainImage.slick('slickPrev')
        });

        $('.product_image_list_prev_'+$pid).css('display','none');
        
        $('.productMainImage_'+$pid).on('afterChange', function(slide, currentSlide){


               $('.thumbs_list_frame_'+$pid+' .slick-slide .thum_img_wrap.current_slide').removeClass('current_slide');
              $('.thumbs_list_frame_'+$pid+' .slick-slide[data-slick-index="'+currentSlide.currentSlide +'"] .thum_img_wrap').addClass('current_slide');

              var slideCount = currentSlide.slideCount - 1;

              var currentSlide = currentSlide.currentSlide;
         // console.log(currentSlide);
              //return;
            var totalImageCount = $('.thumbs_list_frame_'+$pid+' .slick-slide').length;
         // 	console.log(totalImageCount);
          if(totalImageCount - currentSlide < 3){
          	$('.thumbs_list_frame_'+$pid).slick('slickGoTo',currentSlide - 2 );
          }
			
              changeActiveThumnail(currentSlide);

              if(currentSlide == slideCount) {

                  $('.product_image_list_next_'+$pid).css('display','none');
              }
              else {
                  $('.product_image_list_next_'+$pid).removeAttr("style")
              }

              if(currentSlide == 0) {
                 $('.product_image_list_prev_'+$pid).css('display','none');
              }
              else {
                 $('.product_image_list_prev_'+$pid).removeAttr("style")
              }  


              // Change Varient
          //console.log($pid);

              var $t = $('.productMainImage_'+$pid).find('.slick-slide.slick-current img');

              var $img = $t.attr('data-img');

              var $productId = $actualPid;
          
         // console.log($('.productMainImage_'+$pid).attr('data-attrchange'));
          if($('.productMainImage_'+$pid).attr('data-attrchange') == 'false'){
            //console.log('inside');
            $('.productMainImage_'+$pid).attr('data-attrchange','true');
            return;
          }
         // $('.productMainImage_'+$pid).attr('data-attrchange','true');
		//
			
              if($("#ProductSelect_"+$pid+" option[data-img='"+$t.attr('data-img')+"']").length){
				//console.log('inga');
                  var varVal = $("#ProductSelect_"+$pid+" option[data-img='"+$t.attr('data-img')+"']").attr('value');
					//console.log(varVal);
                 // $('#ProductSelect_'+$actualPid+'-option-0 .product_varient_sel_radio_'+varVal).trigger('click');

                  var varText = $("#ProductSelect_"+$pid+" option[data-img='"+$t.attr('data-img')+"']").text();

                  var varText = varText.split(' — ');
                  varText = varText[0].trim(varText);	

                  var varText = varText.split('/');
				
                  varText = varText[0].trim(varText);
                //console.log(varText);
               // console.log('#ProductSelect_'+$pid+'-option-0 input[value="'+varText+'"]');
               // console.log($('#ProductSelect_'+$pid+'-option-0 input[value="'+varText+'"]').length);
                  $('#ProductSelect_'+$pid+'-option-0 input[value="'+varText+'"]').trigger('click');
                 $('#ProductSelect_'+$pid+'-option-0 input[value="'+varText+'"]').trigger('click');


                $("select#ProductSelect_"+$pid+"-option-0").val(varText);
                  $("select#ProductSelect_"+$pid+"-option-0").trigger('change');
                		
                $("select#ProductSelect_"+$pid+"-option-0").selectric('refresh');
                  
              }else{
                console.log("#ProductSelect_"+$pid+" option[data-img='"+$t.attr('data-img')+"']");
              }
          });
          var minSlides = 4;
          if($(window).width() < 736){
            
                  var minSlides = 4;
            
            
            
             
          }
        

          var SlickSliderThumb = $('.thumbs_list_frame_'+$pid).slick({
            slidesToShow: minSlides,
            slidesToScroll: 1,
            arrows: false,
            //centerMode: true,
            centerPadding: '40px',
            infinite:false,
            focusOnSelect: true,
           // asNavFor: '.productMainImage_'+$pid
          });
        
          $('.thumbs_list_down_'+$pid+' i').click(function() {
              SlickSliderThumb.slick('slickNext');


            });
          $('.thumbs_list_up_'+$pid+' i').click(function() {
            SlickSliderThumb.slick('slickPrev')
          });

          $('.thumbs_list_frame_'+$pid).on('init', function(slide){

                showHideImageThumArrow(SlickSliderThumb,$pid);

           //   }, 100);
            //alert('ya');

            //return;


          });
		var width = $(window).width();
            $(window).on('resize', function() {
              
              if ($(this).width() !== width) {
                
                setTimeout(function(){
                  	//$('.productMainImage_'+$pid).slick('refresh');
                	$('.thumbs_list_frame_'+$pid).slick('refresh');
                  $('.thumbs_list_frame_'+$pid).slick('setPosition');
                  $(window).scroll();
                	width = $(this).width();
                }, 100);
              }
            });

          $('.thumbs_list_frame_'+$pid).on('afterChange', function(slide, currentSlide){
              setTimeout(function(){
                var $t = $(this);
                showHideImageThumArrow(SlickSliderThumb,$pid);
              }, 100);
            return;



          });

        $('.thumbs_list_frame_'+$pid+' .slick-slide').on('click', function (event) {
          //alert($(this).data('data-slick-index'));
          $('.thumbs_list_frame_'+$pid+' .slick-slide.slick-current').removeClass('slick-current');
          $(this).addClass('slick-current');
          SlickSliderMainImage.slick('slickGoTo', $(this).attr('data-slick-index'));
        });

        $('.thumbs_list_down_'+$pid).removeClass('hidearrow');
        showHideImageThumArrow(SlickSliderThumb,$pid);
        setTimeout(function(){


    //       $('.product_tumail_bottom .thumbs_list_frame').css('max-width','100%');
    //     	$('.product_tumail_bottom .thumbs_list_frame').css('width','auto');


        }, 4000);




         $('.featuredImage img').load(function() { 
               setTimeout(function(){
                $('.product_tumail_bottom .thumbs_list_frame').css('visibility','visible');
           }, 1000);

        });


      }
  }
  $(".productMainImage").on('click mouseenter touchstart', function(evt) {
  	//$(this).attr('data-attrchange','false');
  });
$(window).load(function() {
//$(document).ready(function() {
  	$('.productImages').each(function(){
  var $t = $(this);
  loadProductSlider($t);

});
  });
$(document).ready(function() {
  var hash = window.location.hash.substr(1);
  
  if(hash == 'upsell' && upsell_enable == true){
  	 
  }
  if(upsell_enable == true){
  	$('#cartForm').submit(function(){
      
  	});
  }
  $("a[data-getpopout='#CartUpsellPopup']").click(function(){
     $('.cart_upsell_popup .productMainImage').slick('setPosition');
    
  	$('#CartUpsellPopup .product-single__variants option:eq(0)').prop('selected', true);
  });
  });
function showHideImageThumArrow(SlickSliderThumb,$pid){
	//console.log(SlickSliderThumb.find(".slick-track > .slick-slide[tabindex='-1']:last-child").length);
  if(SlickSliderThumb.find(".slick-track > .slick-slide.slick-active:last-child").length == 1){
    $('.thumbs_list_down_'+$pid).addClass('hidearrow');
  }else{
    $('.thumbs_list_down_'+$pid).removeClass('hidearrow');
  }

    if(SlickSliderThumb.find(".slick-track > .slick-slide.slick-active:first-child").length == 1){
    $('.thumbs_list_up_'+$pid).addClass('hidearrow');
  }else{
    $('.thumbs_list_up_'+$pid).removeClass('hidearrow');
  }
}
$('.single-option-selector').on('change', function() {
          //bxslider.goToSlide(5);
      //alert('hi');
          
          //resetbxSliderOnChangeVarientPos(bxslider);
    });
    changeActiveThumnail(0);
    $(document).on('data-attribute-changed', function() {
          //bxslider.goToSlide(5);

          //resetbxSliderOnChangeVarientPos(bxslider);
    });  

function changeActiveThumnail(currentPos){
  
	$('#thumbs_list_frame .slick-track > div').removeClass('active_mainimage');
  	$( "#thumbs_list_frame .slick-track > div[data-counter='"+currentPos+"']" ).addClass('active_mainimage');
}

function resetbxSliderOnChangeVarientPos(bxslider){
      
      	setTimeout(function(){ 
                          
                         
          var currentImage = $("#thumbs_list_frame a[href='"+$('.featuredImage img').attr('src')+"']").attr('data-counter');
          $("#thumbs_list_frame a[href='"+$('.featuredImage img').attr('src')+"']").addClass('active');
          currentImage = parseInt(currentImage) + 1;
          //alert(currentImage);
          if(currentImage >= 5){
          	 var addCNo = 0;
            if(currentImage % 4 != 0){
                addCNo = 1;
            }
            currentImage = parseInt(currentImage/4);
        //
            currentImage = currentImage + addCNo;
            currentImage = currentImage - 1;
          }else{
          		currentImage = 0;
          }
         //	currentImage = 0;
		//	alert(currentImage);
          if(typeof bxslider.goToSlide === 'function'){
          	bxslider.goToSlide(currentImage);
          }
          

        }, 100);
      }
$(window).bind("load",function(e){
  $(document).trigger('data-attribute-changed');
  $('.accentCollection').css('position','static');
  setTimeout(function(){ $('.accentCollection').css('position','relative'); }, 100)
  $('.product_tab_heading a.active').removeClass('active');
  $('.tab_details.active').removeClass('active');
  $('.tab_mobile_trigger.active').removeClass('active');
  if (window.innerWidth > 740) {
    $('.product_page_tabs').each(function(){
    	$(this).find('.product_tab_heading a:first').addClass('active');
    	$(this).find('.tab_details:first').addClass('active');
    });
    
    
  }else{
    $('.tab_mobile_trigger:first').find('i').removeClass('fa-chevron-down');
	$('.tab_mobile_trigger:first').find('i').addClass('fa-chevron-up');
    $('.tab_mobile_trigger:first').addClass('active');
    $('.tab_details:first').show();
    $('.tab_details:first').addClass('active');
  }
});
      
$(document).ready(function(){
  $('.terms_popup_trigger').click(function(){
    $.getJSON( "/pages/.json", function( data ) {
	
    var htmlTag = '<h1 class="top-heading-wrap">'+data.page.title+'</h1>'+data.page.body_html;
   	$('.term_page_wrapper').html(htmlTag);
    
   	
  });
  });
  $('body').on('click', '.thum_img_wrap', function(e) {
      	//$(this).parents('.productImages').find('.productMainImage').attr('data-attrchange','false');
    });
  $(document).on('change', '.single-option-selector', function(event) {

//   		var $form = $(this).parents('form');
    
//     	alert($form.find('.product-single__variants').val());
    
  });	
  
  
  $('.homepage-banner-video').click(function(){
      var $t = $(this);

      if($t.attr('data-video-status') == 'pause'){
		$t.find('i').attr('class','fa fa-pause');
        $t.find('video').get(0).play();
        $t.attr('data-video-status','play');
      }else{
        $t.find('i').attr('class','fa fa-play');
		$t.find('video').get(0).pause();
      	$t.attr('data-video-status','pause');
      }
  });
  
  $('.pupupImageWith').click(function(){
		$('#footer_gallery img').attr('src',$(this).attr('data-image'));
  });
  
  $('.accentCollection').css('position','static');
  setTimeout(function(){ $('.accentCollection').css('position','relative'); }, 100);
  $('.inpageVideo').click(function(){
    var $url = $(this).attr('href');
    var $p = $(this).parents('.homepage-image');
    var $height = $p.height();
    var $width = $p.width();
    var tag = '<div class="image_page_video"><iframe src="'+$url+'" allowfullscreen="" frameborder="0"></iframe></div>';
  	$p.append(tag);
    return false;
  });
  
  $(document).on('click', '.spr-summary-actions-newreview', function(event) {
    $('.accentCollection').css('position','static');
    if($('#shopify-product-reviews .spr-form').css('display') == 'block') {
      $(this).parents('#shopify-product-reviews').addClass('form_review_open');
     // $('#shopify-product-reviews .slick-arrow').css("display", "none"); 
    } else if ($('#shopify-product-reviews .spr-form').css('display') == 'none') {
      $(this).parents('#shopify-product-reviews').removeClass('form_review_open');
     // $('#shopify-product-reviews .slick-arrow').css("display", "flex"); 
    }        
	setTimeout(function(){ $('.accentCollection').css('position','relative'); }, 100)
  });


  $(document).on('click', '#relatedWrapperWrap .spr-badge-caption', function(event) {
    return false;
  });
  $(document).on('click', '#productHead .spr-badge', function(event) {
   // var $pid = $(this).parents('form').attr('data-product_id');
   // alert("a[data-tab-id='prodTabReview_"+$pid+"']");
    var $pid = $(this).attr('id');
    $pid = $pid.replace("spr_badge_", "");
    if($(".product_page_tabs_"+$pid+" .product_tab_heading a[data-tab-id='prodTabReview_"+$pid+"']").length){
      	if(window.innerWidth < 734){
      		$(".product_page_tabs_"+$pid+" .product_tab_heading a[data-tab-id='prodTabReview_"+$pid+"']").trigger('click');
            $('html,body').animate({
            scrollTop: $(".product_page_tabs_"+$pid+" a.tab_mobile_trigger[data-tab-id='prodTabReview_"+$pid+"']").offset().top - 50},
            'slow');
        }else{
        	$(".product_page_tabs_"+$pid+" .product_tab_heading a[data-tab-id='prodTabReview_"+$pid+"']").trigger('click');
            $('html,body').animate({
            scrollTop: $(".product_page_tabs_"+$pid+" .product_tab_heading a[data-tab-id='prodTabReview_"+$pid+"']").offset().top - 200},
            'slow');
        }
      	
    }else{
    	
        $('html,body').animate({
        scrollTop: $("#shopify-product-reviews").offset().top - 100},
        'slow');
    }
  });
  $('.tab_mobile_trigger').click(function(){
    var $this = $(this);
    
  	//$('.product_tab_heading a.active').removeClass('active');
    //$('.tab_details.active').removeClass('active');
    
    
    $('.accentCollection').addClass('remove_band_tmp');
    if($this.hasClass('active')){
      $this.removeClass('active');
      
      $this.find('i').addClass('fa-chevron-down');
      $this.find('i').removeClass('fa-chevron-up');
      $('#'+$this.attr('data-tab-id')).slideUp('fast',function(){ 
        $('#'+$this.attr('data-tab-id')).removeClass('active');
        setTimeout(function(){ $('.accentCollection').css('position','relative'); }, 100)
      });
    }else{
      $this.find('i').removeClass('fa-chevron-down');
      $this.find('i').addClass('fa-chevron-up');
      $this.addClass('active');
      $('#'+$this.attr('data-tab-id')).show();
      $('#'+$this.attr('data-tab-id')).addClass('active');
      $('#'+$this.attr('data-tab-id')).slideDown('fast',function(){
        
		$('.accentCollection').css('position','static');
        setTimeout(function(){ $('.accentCollection').css('position','relative'); }, 100)
      });
    }
    
    $('#'+$this.attr('data-tab-id')).addClass('active');
    $('.accentCollection').css('position','static');
	setTimeout(function(){ $('.accentCollection').removeClass('remove_band_tmp');
                          $('.accentCollection').css('position','relative');
                         }, 100)
    
    return false;
  });
  
  
  
  $(document).on('click', '.product_tab_heading a', function(event) {
    var $this = $(this);
    var $tabs = $(this).parents('.product_page_tabs');
  	$tabs.find('.product_tab_heading a.active').removeClass('active');
    $tabs.find('.tab_details.active').removeClass('active');
    
    $this.addClass('active');
    $('#'+$this.attr('data-tab-id')).addClass('active');
    $('.accentCollection').css('position','static');
	setTimeout(function(){ $('.accentCollection').css('position','relative'); }, 100)
    return false;
  });
	$('.productThumbs .slick-slide1').on('tap', function(evt) {
	//alert('hi');	
      var $t = $(this).find('.thum_img_wrap');

      var $img = $t.attr('data-img');

      var $productId = $t.attr('data-product_id');


      if($("#ProductSelect_"+$productId+" option[data-img='"+$t.attr('data-img')+"']").length){

          var varVal = $("#ProductSelect_"+$productId+" option[data-img='"+$t.attr('data-img')+"']").attr('value');

          $('#ProductSelect_'+$productId+'-option-0 .product_varient_sel_radio_'+varVal).trigger('click');

          var varText = $("#ProductSelect_"+$productId+" option[data-img='"+$t.attr('data-img')+"']").text();

          var varText = varText.split(' — ');
          varText = varText[0].trim(varText);	

          var varText = varText.split('/');

          varText = varText[0].trim(varText);
          $('#ProductSelect_'+$productId+'-option-0 input[value="'+varText+'"]').trigger('click');
        //alert(varText);	
          //$("select#ProductSelect-option-0 option:contains('"+varText+"')").trigger('click');

        $("select#ProductSelect_"+$productId+"-option-0").val(varText);
          $("select#ProductSelect_"+$productId+"-option-0").trigger('change');
        		
        $("select#ProductSelect_"+$productId+"-option-0").selectric('refresh');
          
      }
    //return false;
  });
  $('.productThumbs .slick-slide1').on('click', function(evt) {
   
  //$('.productThumbs .slick-slide').click(function(){
	//alert('hi');	
    
    var $t = $(this).find('.thum_img_wrap');
    
    var $img = $t.attr('data-img');
    
    var $productId = $t.attr('data-product_id');
    
   
    if($("#ProductSelect_"+$productId+" option[data-img='"+$t.attr('data-img')+"']").length){
    	
      	var varVal = $("#ProductSelect_"+$productId+" option[data-img='"+$t.attr('data-img')+"']").attr('value');
      	
      	$('#ProductSelect_'+$productId+'-option-0 .product_varient_sel_radio_'+varVal).trigger('click');
    	
    	var varText = $("#ProductSelect_"+$productId+" option[data-img='"+$t.attr('data-img')+"']").text();
		
      	var varText = varText.split(' — ');
      	varText = varText[0].trim(varText);	
      
      	var varText = varText.split('/');
      
      	varText = varText[0].trim(varText);
      	$('#ProductSelect_'+$productId+'-option-0 input[value="'+varText+'"]').trigger('click');
      //alert(varText);	
		//$("select#ProductSelect-option-0 option:contains('"+varText+"')").trigger('click');
      	
      $("select#ProductSelect_"+$productId+"-option-0").val(varText);
      	$("select#ProductSelect_"+$productId+"-option-0").trigger('change');
      		
      $("select#ProductSelect_"+$productId+"-option-0").selectric('refresh');
    	
    }	
    //return false;
  });
 
  
  $('#view_scroll_right1').click(function(){
  	bxslider.goToNextSlide();
     return false;
  });
   $('#view_scroll_left1').click(function(){
  	bxslider.goToPrevSlide();
     return false;
  });
  
  $('#thumbs_list').trigger('goto', 0);
  if($('.clockNew').length && $('.timmer_data').length){
    CountDownTimer($('.timmer_data').attr('data-date'),$('.clockNew'),$('.timmer_data').attr('data-restart'));

    if($('.timmer_data').attr('data-stock_min_count') && $('.timmer_data').attr('data-stock_max_count') && $('.timmer_data').attr('data-stock_reset_time')){
      resetStock($('.product_stack_count'),parseInt($('.timmer_data').attr('data-stock_min_count')),parseInt($('.timmer_data').attr('data-stock_max_count')),parseInt($('.timmer_data').attr('data-stock_reset_time')));
    }

  }
  //$('#thumbs_list_frame').width(parseInt($('#thumbs_list_frame >li').outerWidth(true) * $('#thumbs_list_frame >li').length) + 'px');
  $('.search_top_trigger').click(function(){
  	$('.top_search_area').addClass('search_top_open');
    
  });
  $('.close_search').click(function(){
  	$('.top_search_area').removeClass('search_top_open');
    return false;
  });
  
  $('#accordion .panel-title a').click(function(){
    var $t = $(this);
    var $p = $t.parents('#accordion');
  	var isClosed = $t.hasClass('collapsed');
    if(isClosed){
        if($p.find('.in').length){
          	var $open = $p.find('.in')
			$open.slideUp( "slow", function() {
              $open.removeClass('in');
            });
          	$open.parents('.panel').find('.panel-title a').addClass('collapsed');
        }
      	var $toOpen = $t.parents('.panel').find('.panel-collapse');
      	$t.removeClass('collapsed');
      	$toOpen.slideDown( "slow", function() {
          $toOpen.addClass('in');
        });
      	
    }else{
    	var $open = $p.find('.in')
        $open.slideUp( "slow", function() {
          $open.removeClass('in');
        });
      	$open.parents('.panel').find('.panel-title a').addClass('collapsed');
    }
    return false;
  });
});
checkBrowser();

if($('.shipping_bar_top').length){
	updateShippingBar(parseInt($('.shipping_bar_top').attr('data-cart_amount')));
}
      
function updateShippingBar(total_amount){
  	//alert(total_amount);
    var moneyFormat = $('.shipping_bar_top').attr('data-header-currency');
  	//var moneyFormat = '';
    //alert(moneyFormat);
  	var actual_total_amount = total_amount/100;
  	var total_amount_format = Shopify.formatMoney(total_amount, moneyFormat);
  	
  		var shipping_bar_goad = 50;
  	
    var balance_amount = shipping_bar_goad - actual_total_amount;
    
    var shipping_bar_goad_format = Shopify.formatMoney(shipping_bar_goad * 100, moneyFormat);
	var balance_amount_format = Shopify.formatMoney(balance_amount * 100, moneyFormat);
  	
  
    var shipping_bar_initial_message = "Livraison Gratuite à partir de [amount]";
    var shipping_bar_progress_message = "Plus que [balance] pour en profiter !";
    var shipping_bar_achieved_message = "Félicitations! Vous avez la Livraison Offerte !";
     
	shipping_bar_initial_message = shipping_bar_initial_message.replace("[amount]", shipping_bar_goad_format);
  	shipping_bar_progress_message = shipping_bar_progress_message.replace("[balance]", balance_amount_format);
  
  	$('.shipping_bar_top').removeClass('shipping_bar_achive');
  	$('.shipping_bar_top').removeClass('shipping_bar_progress');
  	$('.shipping_bar_top').removeClass('shipping_bar_initial');
  
  	if(actual_total_amount >= shipping_bar_goad){
      	$('.shipping_bar_top').addClass('shipping_bar_achive');
    	$('.shipping_bar_top').html(shipping_bar_achieved_message);	
    }else if(actual_total_amount > 0){
      $('.shipping_bar_top').addClass('shipping_bar_progress');
    	$('.shipping_bar_top').html(shipping_bar_progress_message);	
    }else{
      	$('.shipping_bar_top').addClass('shipping_bar_initial');
    	$('.shipping_bar_top').html(shipping_bar_initial_message);
    }
	
}
function checkBrowser() { 
     if((navigator.userAgent.indexOf("Opera") || navigator.userAgent.indexOf('OPR')) != -1 ) 
    {
        
    }
    else if(navigator.userAgent.indexOf("Chrome") != -1 )
    {
        $('body').addClass('brow_chrome');
    }
    else if(navigator.userAgent.indexOf("Safari") != -1)
    {
        $('body').addClass('brow_safari');
    }
    else if(navigator.userAgent.indexOf("Firefox") != -1 ) 
    {
        $('body').addClass('brow_firefox'); 
    }
    else if((navigator.userAgent.indexOf("MSIE") != -1 ) || (!!document.documentMode == true )) //IF IE > 10
    {
      
    }  
    else 
    {
       
    }
    }      

      function resetStock($ele,$min,$max,$time){
        var stockTimer;



        function updateStock(){
          var num = getRandomInt($min,$max);
          $ele.text(num);
        }
        //alert($time*1000);
        stockTimer = setInterval(updateStock, $time*1000);
      }

      function getRandomInt(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
      }


      function CountDownTimer(dt, ele,restart)
      {
        do{
          var end = new Date(dt);
          var now = new Date();
          var distance = end - now;
          dt = end.getTime() + (parseInt(restart) * 1000);
          //alert(distance);
        }while(distance < 0)

          //alert(end.getTime());

          //var end = new Date(end.getTime() + (86400000));
          //alert(end.getTime());
          var _second = 1000;
        var _minute = _second * 60;
        var _hour = _minute * 60;
        var _day = _hour * 24;
        var timer;

        function showRemaining() {
          var now = new Date();
          var distance = end - now;
          var htmlDate = '';
          if (distance < 0) {

            clearInterval(timer);
            //document.getElementById(id).innerHTML = 'EXPIRED!';

            //return;
          }else{
            var days = Math.floor(distance / _day);
            var hours = Math.floor((distance % _day) / _hour);
            var minutes = Math.floor((distance % _hour) / _minute);
            var seconds = Math.floor((distance % _minute) / _second);

            htmlDate = days + 'jours ';
            htmlDate += hours + 'hrs ';
            htmlDate += minutes + 'mins ';
            htmlDate += seconds + 'secs';
          }
          ele.html(htmlDate); 

        }

        timer = setInterval(showRemaining, 1000);
      }
      if(window.location.href == 'https://www.magicmecanic.com/collections/frontpage'){
        window.location.href = 'https://www.magicmecanic.com/';
      }

 
/*===========================mob megamenu==================*/
      
     $( document ).ready(function() {
	
//        $('.main_mega_heading_drop .main_mega_heading,.hasDrop .main_mega_heading').click(function(evt){
         
//          if($(window).width() < 736){
           // alert('new');
// 			evt.preventDefault();
//            	var $p = $(this).parent();
//             var $Pclass = $p.attr('class').indexOf("open_mob_menu");
//             //alert($Pclass);

//             if($Pclass > 0){
//              	//alert('newww1');
//             	$p.find('.menu-arrow').removeClass('m-arrow-up');
//               	$p.find('.menu-arrow').addClass('m-arrow-down');
              
//               	$p.removeClass('open_mob_menu');
//             }else{
           
//               	$p.find('.menu-arrow').removeClass('m-arrow-down');
//             	$p.find('.menu-arrow').addClass('m-arrow-up');
              	
//               	$p.addClass('open_mob_menu');
//             }
        		
        		
        
           	//$(this).parent().find('.mob_subdrop').toggleClass('mob_subdrop_tog');
//          	return false;
//          }
//       });
       
       $('.header-cart-wrapper-inner').hover(function(){
        		$('body').toggleClass('menu_hover_open');
        		
          
          });

     });
 jQuery(document).scroll(function() {
  var y = $(this).scrollTop();
   
  if (y > 100) {
    $('.prod_form.prod_form_footer.sticky_addcart.bottom').fadeIn();
  } else {
    $('.prod_form.prod_form_footer.sticky_addcart.bottom').fadeOut();
  }
   
  if (y > 100) {
    $('.prod_form.prod_form_footer.sticky_addcart.top').fadeIn();
  } else {
    $('.prod_form.prod_form_footer.sticky_addcart.top').fadeOut();
  }
   

   
});

jQuery(document).scroll(function() {      
      var x = $(this).scrollTop();
   		
  	   if (x > 0.1) {
          $('.main_header').addClass('scroll_bg');
        } else {
          $('.main_header').removeClass('scroll_bg');
        }

       if (x > 0.1) {
          $('.main_mega_heading').addClass('scroll_bg_txt');
        } else {
          $('.main_mega_heading').removeClass('scroll_bg_txt');
		}

});  


      if($('.template-index').length == 0){
        if($('#mainWrap > .shopify-section:first > .space_top_header').length){
        	$('body').addClass('template-index');
        }
        if($('#mainWrap > .shopify-section:first .space_top_header_grid').length){
        	$('body').addClass('template-index');
        }
        if($('#mainWrap .stripMainHead.fixedHeight').length){
        	$('body').addClass('template-index');
        }
      }
  		
    
jQuery(document).ready(function(){
  
    $('.upsell_trigger').click(function(){
      if($(this).hasClass('hasPop')){
       
          //alert('first');
      }else{
          //alert('next');
          Shopify.redirectToCheckout();
      }
      $(this).removeClass('hasPop');
    });
  
  	 
  
	
  
  	$(document).on( "change", ".single-option-selector", function() {
		
        var $otherForm = $(this).parents('.prod_form').attr('data-other');
        var $thisform = $(this).parents('.prod_form');
    	var $thisid = $(this).attr('id');
    	var selectedVal = $(this).val();
        var selectedText = $(this).find("option[value='"+selectedVal+"']").text();
    	var productId = $thisform.attr('data-product_id');
    
//    	ale(selectedText);
		//alert('al');
    	$thisid = $thisid.replace('_Bottom', '_'+productId);
       	$thisidB = $thisid.replace('ProductSelect_'+productId+'-option', 'ProductSelect_Bottom-option');
        //alert($thisidB);
        $('.'+$otherForm).find('#'+$thisid).val(selectedVal);
    	//$('.'+$otherForm).find('#'+$thisid).trigger('change');
        $('.'+$otherForm).find('#'+$thisid).parent().find('.selected-text').text(selectedText);
        
    	$('.'+$otherForm).find('#'+$thisidB).val(selectedVal);
    	//$('.'+$otherForm).find('#'+$thisidB).trigger('change');
    	//alert($('.'+$otherForm).find('#'+$thisidB).parent().attr('class'));
        $('.'+$otherForm).find('#'+$thisidB).parent().find('.selected-text').text(selectedText);
       // alert('ya');
    	
        setTimeout(function(){
         // alert('ya here');
          	$('.discount_price_per_'+productId).hide();
            var varSel = $thisform.find('.product-single__variants').val();
          
          	var varOption = $thisform.find(".product-single__variants option[value='"+varSel+"']");
          	//alert(varOption.attr('data-compare_at_price_o'));	
          if(varOption.attr('data-compare_at_price_o') && varOption.attr('data-compare_at_price_o') != varOption.attr('data-price_o')){
          

             // var moneyFormat = $('.header-cart').data('header-cart');
              var offerPer = ((varOption.attr('data-compare_at_price_o') - varOption.attr('data-price_o'))/varOption.attr('data-compare_at_price_o')) * 100;
              var offerAmount = varOption.attr('data-compare_at_price_o') - varOption.attr('data-price_o');
              offerAmount = Shopify.formatMoney(offerAmount, moneyFormat);
              offerPer = Math.round(offerPer);

              $('.discount_price_amount_'+productId).html(offerAmount);
              $('.discount_price_percentage_'+productId).text(offerPer);
              $('.discount_price_per_'+productId).show();
            }
          	
            $('.'+$otherForm).find('.product-single__variants').val(varSel);
          
          $(".single-option-selector").selectric('refresh');
          

        }, 300);

        
    });
  	$(".MainImageHtmlWrap select").selectric({
      
    });
   	$("#blog_link").change(function(e){
      	window.location.href = $(this).val();
     });
  	 
    $('.upsell_cart').click(function(e){
      if(downsell_enable == true){
        e.stopImmediatePropagation();
      		$('.cart_upsell_popup').hide();
      		$('.cart_downsell_popup').fadeIn();
      	$('.cart_downsell_popup .productMainImage').slick('setPosition');
        return false;
      }else{
      		window.location.href = $(this).attr('href');
      }
    	
    });
  	$('.downsell_cart').click(function(e){
      window.location.href = $(this).attr('href');
    });
    $('.cart_button_checkout1,#CartUpsellPopup .productImages *,#CartUpsellPopup').click(function(e){
    	e.stopPropagation();
    });
  	$('.cart_button_checkout1').click(function(e){
    	e.preventDefault();
    });
  	
	
      setTimeout(function() {
           $(".selector-wrapper").trigger("load");
      },1000);
      $(".selector-wrapper").load(function() {
        $(".single-option-selector").selectric({
        	onChange: function(element) {
             $(element).trigger('change');
              
            },
          	onInit: function(element) {
            	$(element).trigger('change');
            }
        });
      });
  
  	
  
  	
  	
      $('body').on('submit', 'footer .contact-form', function() {
      
      if ($('#rgpdAgree').is(':checked')) {
        $(this).submit();
      }
      else {
        $('.rgpd_error').slideDown();
        return false;
      }
     });
   
  
  
  	
      $('body').on('submit', '#home-newsletter .contact-form', function(e) {
      
        //alert("5555");
      if ($('#rgpdAgree1').is(':checked')) {
        $(this).submit();
      }
      else {
        $('.rgpd_error1').slideDown();
        return false;
      }
     });
  	
      $('body').on('submit', '.b_newsletter .contact-form', function(e) {
      
        //alert("5555");
      if ($('#rgpdAgree1').is(':checked')) {
        $(this).submit();
      }
      else {
        $('.rgpd_error1').slideDown();
        return false;
      }
     });
   
  
  
  	
      $('body').on('submit', '#contactUs .contact-form', function() {
      
      if ($('#rgpdContactAgree').is(':checked')) {
        $(this).submit();
      }
      else {
        $('.rgpd_error2').slideDown();
        return false;
      }
     });
   
  

  

  //setTimeout(function(){ $('body').show(); }, 1000);
    // This button will increment the value
    $('.qtyplus').click(function(e){
        // Stop acting like a button
        e.preventDefault();
        // Get the field name
        var fieldName = $(this).parent().find('.qty');
        // Get its current value
        var currentVal = parseInt(fieldName.val());
        // If is not undefined
        if (!isNaN(currentVal)) {
            // Increment
            fieldName.val(currentVal + 1);
        } else {
            // Otherwise put a 0 there
            fieldName.val(0);
        }
      fieldName.trigger('change');
    });
    // This button will decrement the value till 0
    $(".qtyminus").click(function(e) {
        // Stop acting like a button
        e.preventDefault();
        // Get the field name
        var fieldName = $(this).parent().find('.qty');
        // Get its current value
        var currentVal = parseInt(fieldName.val());
        // If it isn't undefined or its greater than 0
        if (!isNaN(currentVal) && currentVal > 0) {
            // Decrement one
            fieldName.val(currentVal - 1);
          	
        } else {
            // Otherwise put a 0 there
            fieldName.val(0);
        }
      	fieldName.trigger('change');
    });

        var isOpera = (!!window.opr && !!opr.addons) || !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;

      // Firefox 1.0+
      var isFirefox = typeof InstallTrigger !== 'undefined';

      // Safari 3.0+ "[object HTMLElementConstructor]" 
      var isSafari = /constructor/i.test(window.HTMLElement) || (function (p) { return p.toString() === "[object SafariRemoteNotification]"; })(!window['safari'] || (typeof safari !== 'undefined' && safari.pushNotification));

      // Internet Explorer 6-11
      var isIE = /*@cc_on!@*/false || !!document.documentMode;

      // Edge 20+
      var isEdge = !isIE && !!window.StyleMedia;

      // Chrome 1+
      var isChrome = !!window.chrome && !!window.chrome.webstore;

      // Blink engine detection
      var isBlink = (isChrome || isOpera) && !!window.CSS;
  	  
  	  var classtoAdd = 'browser_webkitt';
      if(isFirefox){
        var classtoAdd = 'browser_firefox';
      }
	  
  	  $('.header_wrapper').addClass(classtoAdd);
    });

$('.nrl_data').click(function(){
	var strval =  "U2FsdGVkX1sdvs8ZUVvSh234FSES21qHsQEqZ%34XMxQ9zgHy+bu0=";
  	var dec = CryptoJS.AES.decrypt($(this).attr('data-nrl'),strval);
  	dec = dec.toString(CryptoJS.enc.Utf8);
  	document.location.href= dec;
  
  	
});

    

  showSectionByEffect();
  $(document).ready(function() {
      showSectionByEffect();
      /* Every time the window is scrolled ... */
      $(window).scroll( function(){
          showSectionByEffect();


      });

  });

if(inIframe()){
	$('body').addClass('body_live_editor');
  setInterval(function () {
  	$('.productImages').each(function(){
      var $t = $(this);
      if(!$t.find('.slick-initialized.slick-slider').length){
      	loadProductSlider($t);
      }
      

    });
   }, 1000);
//   	setInterval(function () {
//       if($('.main_image_slider_wrap').length){
//         $('.main_image_slider_wrap').each(function(){
//         	var mainid = $(this).attr('data-section-id');
//           	console.log(mainid);
//           	setInterval(function () {
        
//               if (!$('#flickySlider-'+mainid).hasClass('slick-initialized')) {
//                 	var fnName = 'runslick'+mainid;
// //                       window[fnName]();
// //                       window['fullscreenHeight'+mainid]();	
//             		}
//                }, 1000);
//         });
//       }
//     }, 1000);
}

if($('.blog_main_image').length){
  $(document).ready(function(){
  	blogBgImage();
  });

  function blogBgImage(){
  		var $t = $('.blog_main_image');
                 
        var topPos = $t.offset().top;
        var winHeight = $(window).height();
        var heightToUpdate = $(window).height() - topPos;
         
              heightToUpdate = heightToUpdate - 15;
        
      	
      	
      	
    	
     	
		if(heightToUpdate > 100){
          $t.css('height',heightToUpdate+'px');	
        }
        $t.removeClass('hidewhennoheight');
  }
  	$(window).bind("load resize scroll touchmove",function(e){
      
        
		blogBgImage();	

    });
}



if($('.product_main_img').length){
  productBgImage();

  function productBgImage(){
  		var $t = $('.product_main_img');
                 
        var topPos = $t.offset().top;
        var winHeight = $(window).height();
        var heightToUpdate = $(window).height() - topPos;
         
              heightToUpdate = heightToUpdate - 15;
        
      	
      	if($t.attr('data-height') == 'height_small'){
              heightToUpdate = heightToUpdate/4;
         }
   		 if($t.attr('data-height') == 'height_medium'){
              heightToUpdate = heightToUpdate/2;
         }
    	 if($t.attr('data-height') == 'height_large'){
              heightToUpdate = (heightToUpdate/4) * 3;
         }
      	 //console.log($t.attr('data-height'));
    
		if(heightToUpdate > 100){
          $t.css('height',heightToUpdate+'px');	
        }
    	$t.find('.product_fe_main_image_svg').css('opacity',1);
        $t.removeClass('hidewhennoheight');
  }
  	$(window).bind("load resize scroll touchmove",function(e){
      
        
		productBgImage();	

    });
}


$(window).bind("load",function(e){
  if($(window).width() < 736){
  var $t = $('.template-product .scroll_animation.productInfo');


  var delay = parseInt($(this).attr('data-animation_delay')) * 1000;

  if($(window).width() < 736){
    
    var delay = 0;
    
  }
  /* If the object is completely visible in the window, fade it it */

    //console.log($(this).attr('data-animation_delay'));
    setTimeout(function(){ 
      //console.log(delay);
      //$(this).animate({'opacity':'1'},1000);
      $t.css('opacity','1');
      $t.addClass($t.attr('data-animation_name'));
    }, delay);



  }
});
function inIframe () {
    try {
        return window.self !== window.top;
    } catch (e) {
        return true;
    }
}
  $(window).bind("resize",function(e){
      
    $('.productThumbs .slick-active img.zoomOutCustom').each(function(){
    	$(this).addClass('zoomOutCustom_done');
        $(this).removeClass('zoomOutCustom');
    });
		//console.log('resize event');

    });

function showSectionByEffect(){
  var valueGap = 0;

  
  $('.prodThumb').each( function(i){
    	var $t = $(this);
        if(!$t.hasClass('zoomOutCustom_completed')){
            if($t.parents('.slickSlider').length){
              if(!$t.parents('.slick-initialized').length){
              	return ;
              }
              if(!$t.parents('.slick-active').length){
              	return ;
              }
            }
            var bottom_of_object = $(this).offset().top;
            var bottom_of_window = $(window).scrollTop() + $(window).height();

            if( bottom_of_window > bottom_of_object ){
                $t.addClass('zoomOutCustom_completed');
               
                setTimeout(function(){
                   
                  $t.find('.imgWrap img').addClass('zoomOutCustom');
                  setTimeout(function(){
                  	
                  }, 2000);
                  //$t.find('.imgWrap img').css('opacity','1');

                 }, valueGap);
                //console.log(valueGap);
              valueGap = valueGap + 500;

            }
        }
  });
  
  $('.zoomOutEffect_trigger,.zoomOutImage img').each( function(i){
    	 var bottom_of_object = $(this).offset().top;
          var bottom_of_window = $(window).scrollTop() + $(window).height();

          /* If the object is completely visible in the window, fade it it */
          if( bottom_of_window > bottom_of_object ){

            $(this).removeClass('zoomOutEffect_trigger');
            $(this).css('opacity','1');
 			$(this).addClass('zoomOutCustom');
          }
            
  });

  $('.zoomOutCustom_trigger_product').each( function(i){
     
    if($(this).hasClass('zoomOut_added') == false && $(this).hasClass('slider_loading_zoom') == false && $(this).hasClass('thum_slider_loading_zoom') == false){
      
     var bottom_of_object = $(this).offset().top;
      var bottom_of_window = $(window).scrollTop() + $(window).height();

      /* If the object is completely visible in the window, fade it it */
      if( bottom_of_window > bottom_of_object ){
        $(this).addClass('zoomOut_added');

        $(this).find('.productMainImage .slick-active.slick-current img').addClass('zoomOutCustom');
		$(this).css('opacity','1');
        
        $(this).parents('.productImages').find('.productThumbs .slick-active img').css('opacity','0');
        
        
        $(this).parents('.productImages').find('.productThumbs').css('opacity','1');
        var delay = 0;
        $(this).parents('.productImages').find('.productThumbs .slick-active img:not(.zoomOutCustom)').each(function(){
       //   console.log('cioming');
          if($(this).hasClass('zoomOutCustom') == false){
            //console.log($(this).hasClass('zoomOutCustom')+' inga');

            $(this).css('animation-delay',delay+'ms');
            $(this).addClass('zoomOutCustom');
            setTimeout(function(){
  //             console.log('here');
  //           	$(this).addClass('zoomOutCustom_done');
  //             $(this).removeClass('zoomOutCustom');
            }, 2000);
            delay = delay + 500;
          }
          
         
        });
        
       // $(this).removeClass('zoomOutCustom_trigger_product');
        //$(this).animate({'opacity':'1'},1000);
        //$(this).css('opacity','1');
        //$(this).addClass('zoomOutCustom');
        //$(this).removeClass('zoomOutCustom_trigger');
      }
    }

  });
  
	/* Check the location of each desired element */
        $('.animation_effect').each( function(i){
         
          
          
              var bottom_of_object = $(this).offset().top;
              var bottom_of_window = $(window).scrollTop() + $(window).height();

              /* If the object is completely visible in the window, fade it it */
              if( bottom_of_window > bottom_of_object ){

                  //$(this).animate({'opacity':'1'},1000);
                $(this).css('opacity','1');
                $(this).addClass('fadeIn');
				$(this).addClass('animated');
              }
         
            
        });
    
         $('.no_animation_effect .scroll_animation').each( function(i){
         		
          
          	  var $t = $(this);
              var bottom_of_object = $(this).offset().top;
              var bottom_of_window = $(window).scrollTop() + $(window).height();
           	  var delay = parseInt($(this).attr('data-animation_delay')) * 1000;
           	 
               if($(window).width() < 736){
                 
                 	var delay = 0;
                 
               }
              /* If the object is completely visible in the window, fade it it */
              if( bottom_of_window > bottom_of_object ){
                //console.log($(this).attr('data-animation_delay'));
				setTimeout(function(){ 
                  //console.log(delay);
                	//$(this).animate({'opacity':'1'},1000);
                  $t.css('opacity','1');
                  $t.addClass($t.attr('data-animation_name'));
                }, delay);
                  

              }
         
            
        });
                 
}

  
$(document).ready(function($) {
  if($('.editor_app_grid').length){
    $.post( "https://www.kolt.io/site/api/permission", { app: "EDITOR",website:Shopify.shop }, function( data ) {
      
      if(data.status != 'active'){
      	
      }
    }, "json").fail(function(data, textStatus, xhr) {
      if(data.status == 401){
      	$('.editor_app_grid').hide();
      }
                
    });
  	
  }
 //$('.footer_menu_toggle').click(function(e){
  $(document).on("click",".footer_menu_toggle", function (event) {
    if($(event.target).parents('.footer_menu_wrap').length){
    	return;
    }
    $p = $(this);
   	if($(window).width() < 736){
     if($(this).find('.f_title_headings').length){
        if($p.hasClass('footer_menu_toggle_on')){


            //$p.find('.footer_menu_toggle').slideDown();    
            var el = $p.find('.footer_menu_wrap'),
            curHeight = el.height();

          el.height(curHeight).animate({height: "0px"},100,function(){
            $p.removeClass('footer_menu_toggle_on');
          });   
        }else{

            //$p.find('.footer_menu_toggle').slideDown();    
            var el = $p.find('.footer_menu_wrap'),
            curHeight = el.height(),
            autoHeight = el.css('height', 'auto').height();
          el.height(curHeight).animate({height: autoHeight},100,function(){
            $p.addClass('footer_menu_toggle_on');
          });
        }
     }
    }
  });
});

 function snapAddToCart(currency, price, productId){
   if (typeof(snaptr) !== 'undefined') {
  	snaptr('track', 'ADD_CART', {
        'currency': currency,
        'price' : price/100,
        'item_ids': [productId],
      });
   }
}
  //alert('ya');
 //   $( "body" ).on( "click", ".faq_question", function() {
//   //$( ".faq_question" ).on('click', function(evt) {
//     //console.log('here');
//     var $p = $(this).parents('.faq_question_answer');
//     if($p.hasClass('active')){
    	
//       	$p.find('.faq_answer_wrap').slideUp(400,'linear',function() {
//            $p.removeClass('active');
//         });
//     }else{

      
//       $p.find('.faq_answer_wrap').slideDown(400,'linear',function() {
//                	$p.addClass('active');
//         });
//     }
// 	return false;
//   });
    $(document).on("click",".faq_question", function (event) {
    
       	  var $p = $(this).parents('.faq_question_answer');


          if($p.hasClass('active')){
			 

              //$p.find('.footer_menu_toggle').slideDown();    
              var el = $p.find('.faq_answer_wrap'),
              curHeight = el.height();

            el.height(curHeight).animate({height: "0px"},400,function(){
				$p.removeClass('active');
            });   
          }else{
			  $p.addClass('active');
              //$p.find('.footer_menu_toggle').slideDown();    
              var el = $p.find('.faq_answer_wrap'),
              curHeight = (el.height()),
              autoHeight = el.css('height', 'auto').outerHeight(true);
			  
            	el.css('height', '0px');
            	console.log(autoHeight);
              el.height(curHeight).animate({height: autoHeight},400,function(){
				
              });
          }
       return false;
    
  });

  $('#applyCartSlideDisocunt').click(function(){
  	var codeDiscount = $('#cartSlideDiscount').val().toUpperCase();
    if($('.cart_discout').attr('data-redirect') == 'Checkout'){
    	window.location.href = '/checkout?discount='+codeDiscount;
      	return false;
    }
    $('.cart_discout').addClass('loader');
    //$.get( "/discount/"+codeDiscount, function( data ) {
      var xhr = new XMLHttpRequest();

      $.ajax({
          url: '/checkout?discount='+codeDiscount,
          type: 'post',

          xhr: function() {
            
               return xhr;
          },
        success: function (data1) {
          	 $('.cart_discout').removeClass('loader');
            if($(data1).find('#error-for-reduction_code').length){
				$('.cart_discout .err_msg').text($(data1).find('#error-for-reduction_code').text());
              	$('.cart_discout .err_msg').show();
                $('.cart_discout .success_msg').hide();
            }
    		//console.log(xhr.responseURL); 
            if($(data1).find('.total-line--reduction').length){
				var appliedCode = $(data1).find('.total-line--reduction').find('.reduction-code__text').text();
                if(appliedCode == codeDiscount){
					$('.voucher_discount_price_title').text('Code Promo - '+codeDiscount);
                  	var amountDiscounted = $(data1).find('span[data-checkout-discount-amount-target]').text();
                  	$('.voucher_discount_price').text(amountDiscounted);
                  	$('.voucher_discount_price_wrap').show();
                  	$('.cart_discout .success_msg').show();
                  	$('.cart_discout .err_msg').hide();
                  
                  var totalAmount = $(data1).find('.order-summary-toggle__total-recap').find('[data-checkout-payment-due-target]').text();
                  	$('[data-header-cart-total]').text(totalAmount);
                    
                }
				
            }else{
             
             	$('.cart_discout .err_msg').show();
                 $('.cart_discout .success_msg').hide();
            }
          	
        },
        error: function (data1) {
        	$('.cart_discout').removeClass('loader');
          $('.cart_discout .err_msg').show();
                 $('.cart_discout .success_msg').hide();
        }
      });
      
    //});
    return false;
  });
  $(document).ready(function(){
    if($('.cart_slide_timer').length){
      	var currentTime = parseInt($('.cart_slide_timer').attr('data-max_time')) * 60;
    	setInterval(function(){
          	
        	var min = parseInt(currentTime/60);
          	var sec = parseInt(currentTime%60);
          	sec = sec.toString();
          	sec = sec.length == 1 ? '0'+sec : sec;
          	min = min.toString();
          	min = min.length == 1 ? '0'+min : min;
          	//console.log(sec.size)
          	$('#timerCartSlide').text(min+":"+sec);
          	currentTime--;
            if(currentTime <= 0){
				currentTime = parseInt($('.cart_slide_timer').attr('data-max_time')) * 60;
            }
          $('.cart_slide_timer').show();
            if($('.header-cart-items .header-cart-item').length == 0){
				$('.cart_slide_timer').hide();
              	currentTime = parseInt($('.cart_slide_timer').attr('data-max_time')) * 60;
            }
        }, 1000);
    }
  });
  $('body').on('click', '.remove_cart_product', function(e) {
  	$(this).parents('article').find('.side_cart_qty input').val(0).trigger('change');
    
    return false;
  })

  function updateCartFully(openType){
    //$('.header-cart-items').html('');
    var htmlToAppend = '';
    var isOver = false;
    var totalDifferentAmount = 0;
    var totalWithoutDiscount = 0
    Shopify.getCart(async function(cart) {
      if(cart.items.length == 0){
      	isOver = true;
      }
      if (cart.item_count === 0) {
        $('.header-cart-empty').removeClass('hidden');
      } else {
        $('.header-cart-empty').addClass('hidden');
      }
      var counter = 1;
      	$.each(cart.items,async function(i, el) {
				
          	var cartItem = el;

          	await $.ajax({
              type: 'GET',
              async: false,
              url: '/products/'+cartItem.handle+'.js',
              dataType: 'json',
              fail: function(){
                  return true;
              },
              success: function(product) {
				
   			//	console.log(product);
		//	await Shopify.getProduct(cartItem.handle,async function(product) {
				//alert(cartItem.handle);

              var options = product.options;
              //console.log(product);
              var variant;

              for (var i in product.variants) {
                if (product.variants[i].id === cartItem.id) {
                  variant = product.variants[i];
                }
              }
              var varentTxt = '';
               for (var i in cartItem.options_with_values ) {

                if(cartItem.variant_options[i] != 'Default Title' && i != 'filterRelevantNotifications'){
                  varentTxt += '<span class="varient_cart_text">'+cartItem.options_with_values[i].value+'</span>'
                }

              }       
     
              var variantOptions = '';
              //console.log(cartItem);
              if (!cartItem.variant_options.length === 1 && cartItem.variant_options[0] === 'Default Title') {
                for (var i in cartItem.variant_options) {
                  //console.log(cartItem.variant_options[i]);
                 // variantOptions = variantOptions ? variantOptions + '<span>' + options[i].name + ' <strong>' + cartItem.variant_options[i] + '</strong></span>' : '<span>' + options[i].name + ' <strong>' + cartItem.variant_options[i] + '</strong></span>';
                }
              }
              var img = cartItem.image;
              if(typeof Shopify.Image != "undefined"){

                  img = Shopify.Image.getSizedImageUrl(cartItem.image, '160x');
              }
              var image = img,
                  price = Shopify.formatMoney(cartItem.final_line_price, moneyFormat),
                  quantityLabel = Theme.localization.cart.quantity;

              var variantQuantity = variant.inventory_management === 'shopify' && variant.inventory_policy === 'deny'
                                      ? variant.inventory_quantity
                                      : 0;
              variantQuantity = variantQuantity === 0
                                  ? ''
                                  : 'max="' + variantQuantity + '"';
              
                  var linkAtag = '<a href="' + cartItem.url + '">' + cartItem.product_title + '</a>';
              
              var variantComparePrice = '';
              var differentAmount = 0;
			  
              if(variant.compare_at_price){
				  
                  var differentAmount = (variant.compare_at_price - cartItem.price) * cartItem.quantity;
                  var variantComparePrice = ' <span class="money strip"> '+Shopify.formatMoney((variant.compare_at_price * cartItem.quantity), moneyFormat)+' </span>';
              	  totalWithoutDiscount = totalWithoutDiscount + (variant.compare_at_price * cartItem.quantity);
              }else{
              	 totalWithoutDiscount = totalWithoutDiscount + (variant.price * cartItem.quantity);
              }
			
              
                  //var minusIcon = '<?xml version="1.0" encoding="utf-8"?> <!-- Generator: Adobe Illustrator 17.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0) --> <!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd"> <svg version="1.1" id="Calque_3" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="20px" height="20px" viewBox="0 0 595.28 841.89" enable-background="new 0 0 595.28 841.89" xml:space="preserve"> <path fill="#FFFFFF" d="M572.401,398.176H22.85c-12.591,0-22.8,10.209-22.8,22.8c0,12.591,10.209,22.8,22.8,22.8h549.55 c12.591,0,22.8-10.209,22.8-22.8C595.201,408.385,584.992,398.176,572.401,398.176z"/> </svg>';
                var minusIcon = '<svg version="1.1" id="Calque_3" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 595.3 841.9" style="enable-background:new 0 0 595.3 841.9;" xml:space="preserve"> <path class="st0" d="M572.4,398.1H22.9c-12.6,0-22.8,10.2-22.8,22.8c0,12.6,10.2,22.8,22.8,22.8h549.5c12.6,0,22.8-10.2,22.8-22.8 C595.2,408.4,585,398.1,572.4,398.1z"/> </svg>'
                
                
              

              
                  var plusIcon = '<?xml version="1.0" encoding="utf-8"?> <!-- Generator: Adobe Illustrator 17.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0) --> <!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd"> <svg version="1.1" id="Calque_3" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="20px" height="20px" viewBox="0 0 595.28 841.89" enable-background="new 0 0 595.28 841.89" xml:space="preserve"> <path fill="#FFFFFF" d="M572.439,398.175H320.452V146.188c0-12.592-10.209-22.801-22.801-22.801 c-12.592,0-22.801,10.209-22.801,22.801v251.987H22.862c-12.592,0-22.801,10.21-22.801,22.801c0,12.592,10.21,22.801,22.801,22.801 h251.987v251.987c0,12.592,10.21,22.801,22.801,22.801c12.592,0,22.801-10.209,22.801-22.801V443.777h251.987 c12.592,0,22.801-10.209,22.801-22.801C595.24,408.384,585.031,398.175,572.439,398.175z"/> </svg>';
              
             // console.log(cartItem);
              quantityLabel = '';
              var varentTxtWrap = '';
              if(varentTxt != '' || variantOptions != ''){
                  varentTxtWrap = '<div class="header-cart-item-options" data-header-cart-options>' + varentTxt +
                      variantOptions +
                      '</div>';
              }
              var discountExtraTxt = '';
                if(cartItem.discounts.length){
                	discountExtraTxt = '<span class="extra_discount_txt">'+cartItem.discounts[0].title+' <span class="extra_discount_price">(-'+Shopify.formatMoney(cartItem.discounts[0].amount, moneyFormat)+')</span></span>'
                }
                totalDifferentAmount = totalDifferentAmount + differentAmount;
              htmlToAppend += 
                '<article data-lineItem="'+counter+'" class="header-cart-item" data-header-cart-item="' + cartItem.id + '" data-price="'+cartItem.final_price+'" data-product_id="'+cartItem.product_id +'">' +
                  '<a class="header-cart-item-image" href="' + cartItem.url + '">' +
                    '<img src="' + image + '">' +
                  '</a>' +
                  '<div class="header-cart-item-info"><span class="remove_cart_product"><svg width="9" viewBox="0 0 10 10"><path d="M9.677 8.118a1.102 1.102 0 11-1.559 1.56L5 6.558 1.882 9.677a1.102 1.102 0 11-1.56-1.559L3.442 5 .323 1.882A1.102 1.102 0 111.882.322L5 3.442 8.118.323a1.102 1.102 0 111.56 1.559L6.558 5l3.118 3.118z" fill="#cacaca" fill-rule="nonzero"></path></svg></span>' +
                    '<h3>'+linkAtag+'</h3>' + varentTxtWrap +
                      '<div class="cart_slide_price_qty_wrapper"><div class="cart_slide_price"><span class="money">' + price + variantComparePrice + '</span>' + 
                      '<span class="cart_offer_amount" data-amount="'+differentAmount+'" data-without-discount="'+variant.compare_at_price+'"></span></div>'+
                      '<div class="header-cart-item-options slide_cart_qty_wrap" data-header-cart-options=""><span class="side_cart_qty">' +
                        quantityLabel +'<button class="slide_card_minus" type="button" data-header-cart-quantity-decrease="' + cartItem.id  +'">'+minusIcon+'</button> ' +
                        '<input type="number" min="0" ' + variantQuantity + ' value="' + cartItem.quantity + '" data-header-cart-quantity-update="' + cartItem.id  +'">' +
                        '<button class="slide_card_plus" type="button" data-header-cart-quantity-increase="' + cartItem.id  +'">'+plusIcon+'</button> ' +
                      '</span></div>' +discountExtraTxt+
                    '</div></div>' +

                '</article>';
              // console.log('cart.item_count',cart.items.length);
              //console.log('counter',counter);
              if(cart.items.length == counter){
               
              	isOver = true;   
              }
              counter++;
                return true;
              
 }
  });
     // });
        });
          

      /* later */
      
     
    	//console.log(cart);
    });
      var refreshIntervalId = setInterval(function(){
			//console.log(htmlToAppend);
            
        if(isOver == true){

          	 $('[data-header-cart-saving]').html(Shopify.formatMoney(totalDifferentAmount, moneyFormat));
			$('[data-header-cart-total-wo-discount]').html(Shopify.formatMoney(totalWithoutDiscount, moneyFormat));
            if(totalDifferentAmount){
                $('.header-cart-footer-saving').show();
            }else{
                $('.header-cart-footer-saving').hide();    
            }
          	//
              	$('.header-cart-items').html(htmlToAppend)
                $('.header-cart-items .cart_slide_price').each(function(){
                    if($(this).height() > 25){
						$(this).attr('class','cart_slide_price cart_slide_price_line2');
                    }else{
                    	$(this).attr('class','cart_slide_price cart_slide_price_line1');
                    }
                	
                });
        //  
          	if(openType == 'open_cart'){
                    if(!$('html').hasClass('open_mobile_cart')){
                      $('html').addClass('open_mobile_cart');

                    }
              }
          if(openType == 'changed_item'){
          	if($('html').hasClass('open_mobile_cart')){
                      $('html').addClass('refresh_open_mobile_cart');
              	setTimeout(function(){
                  	$('html').removeClass('refresh_open_mobile_cart');
                 }, 200);

              }
          }
         // }, 500);
              
//               $('.header-cart-items').html('');
//               	var allHtml = '';
//               //console.log(htmlToAppend);
//               	for (var i = 1; i <= htmlToAppend.length; i++) {
//                     //allHtml += htmlToAppend[i];
//                     $('.header-cart-items').append(htmlToAppend[i]);
                  

//                 }
              //$('.header-cart-items').append(allHtml);
              	
            	
              	 addUpsellItemCartSlide();
        		addScrollBarEvent();
          clearInterval(refreshIntervalId);
            }
          }, 100);
  }
  updateCartFully();
  
    /* FE03 Start 18.03.2021 */
  
  $( "body" ).on( "click", ".faq_tab_questions .slick-slide", function() {
  	var tab_id = $(this).find('a').attr('data-counter');
    $(this).parents('.faq_tab_questions').find('.active').removeClass('active');
	$(this).addClass('active');
    
//     $(this).parents('.cd-faq-group').find('.faq_question_answer_wrapper .faq_question_answer.current').fadeOut('500', function() {
//       	$(this).parents('.cd-faq-group').find('.faq_question_answer_wrapper .faq_question_answer.current').removeClass('current');
// 		$(this).parents('.cd-faq-group').find('.faq_question_answer_wrapper .faq_question_answer:eq('+tab_id+') ').fadeIn('500', function() {
//         	$(this).parents('.cd-faq-group').find('.faq_question_answer_wrapper .faq_question_answer:eq('+tab_id+') ').addClass('current');
//         });
//     });
    if($(this).parents('.cd-faq-group').find('.faq_question_answer_wrapper .faq_question_answer.faq_effect_process').length){
    	$(this).parents('.cd-faq-group').find('.faq_question_answer_wrapper .faq_question_answer.faq_effect_process').hide();
    }
    $(this).parents('.cd-faq-group').find('.faq_question_answer_wrapper .faq_question_answer.current').hide().removeClass('current');
		$(this).parents('.cd-faq-group').find('.faq_question_answer_wrapper .faq_question_answer:eq('+tab_id+') ').addClass('faq_effect_process');
     	$(this).parents('.cd-faq-group').find('.faq_question_answer_wrapper .faq_question_answer:eq('+tab_id+') ').fadeIn('slow', function() {
//			$(this).parents('.cd-faq-group').find('.faq_question_answer_wrapper .faq_question_answer.current').hide().removeClass('current');
         	$(this).parents('.cd-faq-group').find('.faq_question_answer_wrapper .faq_question_answer:eq('+tab_id+') ').addClass('current');
          //console.log($(this).parents('.cd-faq-group').find('.faq_question_answer_wrapper .faq_question_answer.current').length);
          $(this).parents('.cd-faq-group').find('.faq_question_answer_wrapper .faq_question_answer:eq('+tab_id+') ').removeClass('faq_effect_process');
          if($(this).parents('.cd-faq-group').find('.faq_question_answer_wrapper .faq_question_answer.current').length > 1){
          	//$(this).parents('.cd-faq-group').find('.faq_question_answer_wrapper .faq_question_answer:eq('+tab_id+') ').hide().removeClass('current');
          }
          
         // $(this).parents('.cd-faq-group').find('.faq_question_answer_wrapper .faq_question_answer').not('eq('+tab_id+')').hide().removeClass('current');

//$( "li" ).not( ":nth-child(2n)" ).css( "background-color", "red" );

        });
    
    //$(this).parents('.cd-faq-group').find('.faq_question_answer_wrapper .faq_question_answer:eq('+tab_id+') ').fadeIn().addClass('current').show();
    //$( "td:eq( 2 )" ).css( "color", "red" );
    //console.log(tab_id); 
    return false;
  });
  
  
  function TabQuestionAnswerSlick() {
    $('.faq_tab_questions').each(function(){
     
    	var $t = $(this);
      
      var item_on_desktop = $t.attr('data-item_on_desktop') ? $t.attr('data-item_on_desktop') : 3; 
      $t.slick({
        speed: 500,
        slidesToShow: item_on_desktop,
        initialSlide: 0,
        infinite: true,
        swipeToSlide: true,
        touchMove: true,      
        touchThreshold: 100,
        accessibility: true,
        cssEase: 'ease',
        dots: false,
        arrows: true
      });
      $(this).parents('.cd-faq-group').find('.faq_question_answer_wrapper .faq_question_answer:eq(0) ').addClass('current');
      //$(this).parents('.cd-faq-group').find('.faq_question_answer_wrapper .faq_question_answer:eq(0) ').show();
	
      	var arrow_type = $t.attr('data-arrow_type') ? $t.attr('data-arrow_type') : 2; 
        if (arrow_type == 1) {
          $t.find('.slick-prev').append("<svg version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><path fill='#111' d='M306.069,171.713L56.834,420.942l249.235,249.235l53.216-53.222L163.272,420.942l196.012-195.639 L306.069,171.713z M484.089,171.713L235.236,420.942l248.853,249.235l53.598-53.222L341.674,420.942l196.013-195.639 L484.089,171.713z'/></svg>");
          $t.find('.slick-next').append("<svg transform='rotate(180)' version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><path fill='#111' d='M306.069,171.713L56.834,420.942l249.235,249.235l53.216-53.222L163.272,420.942l196.012-195.639 L306.069,171.713z M484.089,171.713L235.236,420.942l248.853,249.235l53.598-53.222L341.674,420.942l196.013-195.639 L484.089,171.713z'/></svg>");
        }
        else if (arrow_type == 2) {
          $t.find('.slick-prev').append("<svg version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><polygon fill='#111' points='56.703,420.972 462.036,826.314 538.597,749.753 210.286,420.972 538.597,92.668 462.036,15.638 '/></svg>");
          $t.find('.slick-next').append("<svg transform='rotate(180)' version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><polygon fill='#111' points='56.703,420.972 462.036,826.314 538.597,749.753 210.286,420.972 538.597,92.668 462.036,15.638 '/></svg>");
        }
        else if (arrow_type == 3) { 
          $t.find('.slick-prev').append("<svg version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><g id='Calque_1_1_'><path fill='#111' d='M325.989,319.384l-99.527,99.526c-1.125,1.126-1.125,3.002,0,4.134l99.527,99.151 c1.125,1.126,3.014,1.126,3.764,0l22.152-21.782l-77.738-77.369c-1.125-1.131-1.125-3.008,0-4.134l77.738-77.369l-22.152-22.157 C329.004,318.257,327.114,318.257,325.989,319.384L325.989,319.384z M297.446,180.044c-66.467,0-126.569,27.042-170.134,70.608 c-43.566,43.566-70.609,103.66-70.609,170.133c0,66.481,27.044,126.944,70.609,170.515 c43.564,43.566,103.666,70.608,170.134,70.608c66.856,0,126.943-27.042,170.509-70.608c43.579-43.57,70.608-104.035,70.608-170.515 c0-66.473-27.029-126.568-70.608-170.134C424.389,207.086,364.302,180.044,297.446,180.044L297.446,180.044z M163.748,287.081 c34.172-34.178,81.502-55.585,133.698-55.585c52.583,0,99.901,21.408,134.086,55.585c34.172,34.178,55.21,81.503,55.21,133.704 c0,52.208-21.039,99.526-55.21,134.08c-34.185,34.178-81.503,55.21-134.086,55.21c-52.197,0-99.526-21.032-133.698-55.21 c-34.185-34.553-55.21-81.871-55.21-134.08C108.537,368.584,129.563,321.26,163.748,287.081L163.748,287.081z'/></g></svg>"); 
          $t.find('.slick-next').append("<svg transform='rotate(180)' version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><g id='Calque_1_1_'><path fill='#111' d='M325.989,319.384l-99.527,99.526c-1.125,1.126-1.125,3.002,0,4.134l99.527,99.151 c1.125,1.126,3.014,1.126,3.764,0l22.152-21.782l-77.738-77.369c-1.125-1.131-1.125-3.008,0-4.134l77.738-77.369l-22.152-22.157 C329.004,318.257,327.114,318.257,325.989,319.384L325.989,319.384z M297.446,180.044c-66.467,0-126.569,27.042-170.134,70.608 c-43.566,43.566-70.609,103.66-70.609,170.133c0,66.481,27.044,126.944,70.609,170.515 c43.564,43.566,103.666,70.608,170.134,70.608c66.856,0,126.943-27.042,170.509-70.608c43.579-43.57,70.608-104.035,70.608-170.515 c0-66.473-27.029-126.568-70.608-170.134C424.389,207.086,364.302,180.044,297.446,180.044L297.446,180.044z M163.748,287.081 c34.172-34.178,81.502-55.585,133.698-55.585c52.583,0,99.901,21.408,134.086,55.585c34.172,34.178,55.21,81.503,55.21,133.704 c0,52.208-21.039,99.526-55.21,134.08c-34.185,34.178-81.503,55.21-134.086,55.21c-52.197,0-99.526-21.032-133.698-55.21 c-34.185-34.553-55.21-81.871-55.21-134.08C108.537,368.584,129.563,321.26,163.748,287.081L163.748,287.081z'/></g></svg>"); 
        }
        else if (arrow_type == 4) {
          $t.find('.slick-prev').append("<svg version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><path fill='#111' d='M502.87,4.198l18.004,18.585L130.676,412.98c-4.66,4.642-4.66,12.192,0,16.834l390.198,390.197 l-18.004,18.583c-4.64,4.062-12.202,4.062-16.263,0L77.246,429.814c-4.06-4.642-4.06-12.192,0-16.834L486.608,4.198 C490.668-0.442,498.23-0.442,502.87,4.198L502.87,4.198z'/></svg>"); 
          $t.find('.slick-next').append("<svg transform='rotate(180)' version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><path fill='#111' d='M502.87,4.198l18.004,18.585L130.676,412.98c-4.66,4.642-4.66,12.192,0,16.834l390.198,390.197 l-18.004,18.583c-4.64,4.062-12.202,4.062-16.263,0L77.246,429.814c-4.06-4.642-4.06-12.192,0-16.834L486.608,4.198 C490.668-0.442,498.23-0.442,502.87,4.198L502.87,4.198z'/></svg>"); 
        }
        else if (arrow_type == 5) {
          $t.find('.slick-prev').append("<svg version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><polygon fill='#111' points='316.614,421.157 538.593,692.345 56.703,421.157 538.593,149.607 '/></svg>"); 
          $t.find('.slick-next').append("<svg transform='rotate(180)' version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><polygon fill='#111' points='316.614,421.157 538.593,692.345 56.703,421.157 538.593,149.607 '/></svg>"); 
        }
        else if (arrow_type == 6) { 
          $t.find('.slick-prev').append("<svg version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><path fill='#111' d='M239.809,606.063L58.266,424.535c-2.085-1.682-2.085-5.019,0-7.104l181.542-181.542 c2.085-2.085,5.005-2.085,7.089,0l23.378,23.378l-143.156,143.14h391.037c11.271,0,20.458,9.188,20.458,20.445l0,0 c0,10.855-9.186,20.041-20.458,20.041H130.47l139.805,139.807l-23.378,23.363C244.813,608.148,241.893,608.148,239.809,606.063 L239.809,606.063z'/></svg>"); 
          $t.find('.slick-next').append("<svg transform='rotate(180)' version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><path fill='#111' d='M239.809,606.063L58.266,424.535c-2.085-1.682-2.085-5.019,0-7.104l181.542-181.542 c2.085-2.085,5.005-2.085,7.089,0l23.378,23.378l-143.156,143.14h391.037c11.271,0,20.458,9.188,20.458,20.445l0,0 c0,10.855-9.186,20.041-20.458,20.041H130.47l139.805,139.807l-23.378,23.363C244.813,608.148,241.893,608.148,239.809,606.063 L239.809,606.063z'/></svg>"); 
        }
        else if (arrow_type == 7) {
          $t.find('.slick-prev').append("<svg version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><polygon fill='#111' points='278.131,644.671 538.593,644.027 315.227,424.743 538.593,197.219 282.062,197.865 56.716,423.257'/></svg>"); 
          $t.find('.slick-next').append("<svg transform='rotate(180)' version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><polygon fill='#111' points='278.131,644.671 538.593,644.027 315.227,424.743 538.593,197.219 282.062,197.865 56.716,423.257'/></svg>"); 
        }
        else if (arrow_type == 8) {
          $t.find('.slick-prev').append("<svg version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><path fill='#111' d='M433.538,667.31L304.604,415.752l128.934-251.571L56.703,415.753L433.538,667.31L433.538,667.31z M538.593,774.187l-61.476-353.21l61.476-353.273L358.895,420.975L538.593,774.187L538.593,774.187z'/></svg>"); 
          $t.find('.slick-next').append("<svg transform='rotate(180)' version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><path fill='#111' d='M433.538,667.31L304.604,415.752l128.934-251.571L56.703,415.753L433.538,667.31L433.538,667.31z M538.593,774.187l-61.476-353.21l61.476-353.273L358.895,420.975L538.593,774.187L538.593,774.187z'/></svg>"); 
        }
        else if (arrow_type == 9) {
          $t.find('.slick-prev').append("<svg version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><g><polygon fill='#111' points='334.474,596.275 538.593,595.771 363.545,423.922 538.593,245.615 337.555,246.122 160.956,422.757 	'/><polygon fill='#FFFFFF' points='230.197,596.275 280.343,596.146 106.953,422.757 283.552,246.122 233.279,246.122 56.678,422.757 '/></g></svg>"); 
          $t.find('.slick-next').append("<svg transform='rotate(180)' version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><g><polygon fill='#111' points='334.474,596.275 538.593,595.771 363.545,423.922 538.593,245.615 337.555,246.122 160.956,422.757 	'/><polygon fill='#FFFFFF' points='230.197,596.275 280.343,596.146 106.953,422.757 283.552,246.122 233.279,246.122 56.678,422.757 '/></g></svg>"); 
        }

    	$('.faq_tab_questions .slick-center').addClass('active');
    })
    $('.faq_tab_questions .slick-current').addClass('active');
    
    
  }
  TabQuestionAnswerSlick();
  setTimeout(function () {
    
    if ($('.editor_app_preview').length) {
      setInterval(function () {
        
        if (!$('.faq_tab_questions ').hasClass('slick-initialized')) {
               	TabQuestionAnswerSlick();
      }
                  }, 1000);

    }
  }, 1000);

  /* FE03 End 18.03.2021 */
  
  if(reviewSliderStatus == '1'){
    if($('#shopify-product-reviews').length){
     var fineReviewTag = setInterval(reviewValAssets, 100);
       $(document).on('click', '.spr-pagination a', function(event) {

          var $t = $('.spr-reviews');
            if($t.hasClass('slick-initialized')){

              $t.slick('unslick');

            }
         //console.log($(this).attr('data-page'));
         $('#shopify-product-reviews').attr('data-page',$(this).attr('data-page'));
          fineReviewTag = setInterval(reviewValAssets, 100);
          });
      function reviewValAssets(){         
  //     
         if($('.spr-review').length && $('#shopify-product-reviews').attr('data-lastid') != $('.spr-review:first').attr('id')){
          clearInterval(fineReviewTag);
          $('#shopify-product-reviews').attr('data-lastid',$('.spr-review:first').attr('id'));
           var page = parseInt($('.spr-pagination-page.is-active:first').text());
          var count = $('.spr-review').length;
          $('#shopify-product-reviews').attr('data-count',count);
          fetchAssetsReview(page,count);

        }
      }
      function fetchAssetsReview(page,count){
          //console.log(page);
          //console.log(count);

          //ProductsReviewsSlick();
  //       	var reviewImages = JSON.stringify(reviewImages);
  //       	console.log(reviewImages);
          var counter = 1;
          $('.spr-reviews .spr-review').each(function(){
            var countData = counter + ((page - 1) * count);
            //console.log(countData);
            if (typeof reviewImages[countData] !== 'undefined') {
              //console.log(reviewImages[countData]);
              //html = '';
              var html = '<div class="review_assets"><img src="'+reviewImages[countData]+'"></div>';
              $(this).find('.spr-review-header').before(html);               
            }
            counter++;
          }).promise().done( function(){
              ProductsReviewsSlick();
          });

      }
      function fetchAssetsReview_(page,count){

      $.post( "https://lic.ecomacademy.io/fl_review/", { shop: Shopify.shop, handle: $('#shopify-product-reviews').attr('data-handle'),page:page,count:count })
          .done(function( data ) {
            var counter = 1;
            $.each(data, function(index,jsonObject){
              var selectorEle = $('.spr-reviews .spr-review:nth-child('+counter+')');
              var html = '';
              if(jsonObject.images){
                $.each(jsonObject.images, function(index1,img){
                html += '<img src="'+img+'">';
                });
              }

              if(jsonObject.video){
              html += '<video autoplay="" muted="" loop="" playsinline=""> <source src="'+jsonObject.video+'" type="video/mp4"> <source src="movie.ogg" type="video/ogg">  </video>';	

              }

              if(html){
                html = '<div class="review_assets">'+html+'</div>';
  //               selectorEle.find('.spr-review-content-body').prepend(html);
                selectorEle.find('.spr-review-header').before(html);               
              }            

              counter++;

            });
          setTimeout(function () {
              ProductsReviewsSlick();
        }, 1000);




          }, "json");
      }


        function ProductsReviewsSlick() {

            var $t = $('.spr-reviews');
            if($t.hasClass('slick-initialized')){

  //           	$t.slick('unslick');
  //             return false;
            }

            var PaginationHTml = $('.spr-reviews .spr-pagination').html();
          $('.spr-pagination').remove();

          $('.spr-content').append('<div class="spr-pagination">'+PaginationHTml+'</div>');


          $('.spr-reviews').mousedown(function(){
           $(".spr-reviews").addClass("is-pointer-down");
          });
          $('.spr-reviews').mouseup(function(){
           $(".spr-reviews").removeClass("is-pointer-down");
          });



          var StarRatingsHtml = $('.spr-reviews .spr-starratings').html(); 
          $('.spr-starratings').remove();
          $('.spr-review-header').append('<div class="spr-starratings">'+StarRatingsHtml+'</div>'); 

          $('.spr-header').append('<span class="cv__line"></span>');


            $t.slick({
              slidesToShow: 5,            
              draggable:true,
              infinite: true,
              centerMode: false,
              slidesToScroll: 5,
              draggable: true,
              swipeToSlide: true,
              dots: true,
              focusOnSelect: true,
              autoplay: $('#shopify-product-reviews').attr('data-autoslide') == '2' ? false:true,            
              autoplaySpeed: parseInt($('#shopify-product-reviews').attr('loop-duration')) * 1000,      

            //  touchThreshold:-5,
              responsive: [
                {
                  breakpoint: 600,
                  settings: {
                    slidesToShow: 1,
                  }
                }
              ]            
            });
          // On swipe event
  // 			$t.on('swipe', function(event, slick, direction){
  //             console.log(direction);
  //             // left
  //           });



            var arrow_type = $('#shopify-product-reviews').attr('data-arrow-type'); 
          if (arrow_type == 1) {          
            $t.find('.slick-prev').append("<svg version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><path fill='#111' d='M306.069,171.713L56.834,420.942l249.235,249.235l53.216-53.222L163.272,420.942l196.012-195.639 L306.069,171.713z M484.089,171.713L235.236,420.942l248.853,249.235l53.598-53.222L341.674,420.942l196.013-195.639 L484.089,171.713z'/></svg>");
            $t.find('.slick-next').append("<svg transform='rotate(180)' version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><path fill='#111' d='M306.069,171.713L56.834,420.942l249.235,249.235l53.216-53.222L163.272,420.942l196.012-195.639 L306.069,171.713z M484.089,171.713L235.236,420.942l248.853,249.235l53.598-53.222L341.674,420.942l196.013-195.639 L484.089,171.713z'/></svg>");
          }
          else if (arrow_type == 2) {
            $t.find('.slick-prev').append("<svg version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><polygon fill='#111' points='56.703,420.972 462.036,826.314 538.597,749.753 210.286,420.972 538.597,92.668 462.036,15.638 '/></svg>");
            $t.find('.slick-next').append("<svg transform='rotate(180)' version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><polygon fill='#111' points='56.703,420.972 462.036,826.314 538.597,749.753 210.286,420.972 538.597,92.668 462.036,15.638 '/></svg>");
          }
          else if (arrow_type == 3) { 
            $t.find('.slick-prev').append("<svg version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><g id='Calque_1_1_'><path fill='#111' d='M325.989,319.384l-99.527,99.526c-1.125,1.126-1.125,3.002,0,4.134l99.527,99.151 c1.125,1.126,3.014,1.126,3.764,0l22.152-21.782l-77.738-77.369c-1.125-1.131-1.125-3.008,0-4.134l77.738-77.369l-22.152-22.157 C329.004,318.257,327.114,318.257,325.989,319.384L325.989,319.384z M297.446,180.044c-66.467,0-126.569,27.042-170.134,70.608 c-43.566,43.566-70.609,103.66-70.609,170.133c0,66.481,27.044,126.944,70.609,170.515 c43.564,43.566,103.666,70.608,170.134,70.608c66.856,0,126.943-27.042,170.509-70.608c43.579-43.57,70.608-104.035,70.608-170.515 c0-66.473-27.029-126.568-70.608-170.134C424.389,207.086,364.302,180.044,297.446,180.044L297.446,180.044z M163.748,287.081 c34.172-34.178,81.502-55.585,133.698-55.585c52.583,0,99.901,21.408,134.086,55.585c34.172,34.178,55.21,81.503,55.21,133.704 c0,52.208-21.039,99.526-55.21,134.08c-34.185,34.178-81.503,55.21-134.086,55.21c-52.197,0-99.526-21.032-133.698-55.21 c-34.185-34.553-55.21-81.871-55.21-134.08C108.537,368.584,129.563,321.26,163.748,287.081L163.748,287.081z'/></g></svg>"); 
            $t.find('.slick-next').append("<svg transform='rotate(180)' version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><g id='Calque_1_1_'><path fill='#111' d='M325.989,319.384l-99.527,99.526c-1.125,1.126-1.125,3.002,0,4.134l99.527,99.151 c1.125,1.126,3.014,1.126,3.764,0l22.152-21.782l-77.738-77.369c-1.125-1.131-1.125-3.008,0-4.134l77.738-77.369l-22.152-22.157 C329.004,318.257,327.114,318.257,325.989,319.384L325.989,319.384z M297.446,180.044c-66.467,0-126.569,27.042-170.134,70.608 c-43.566,43.566-70.609,103.66-70.609,170.133c0,66.481,27.044,126.944,70.609,170.515 c43.564,43.566,103.666,70.608,170.134,70.608c66.856,0,126.943-27.042,170.509-70.608c43.579-43.57,70.608-104.035,70.608-170.515 c0-66.473-27.029-126.568-70.608-170.134C424.389,207.086,364.302,180.044,297.446,180.044L297.446,180.044z M163.748,287.081 c34.172-34.178,81.502-55.585,133.698-55.585c52.583,0,99.901,21.408,134.086,55.585c34.172,34.178,55.21,81.503,55.21,133.704 c0,52.208-21.039,99.526-55.21,134.08c-34.185,34.178-81.503,55.21-134.086,55.21c-52.197,0-99.526-21.032-133.698-55.21 c-34.185-34.553-55.21-81.871-55.21-134.08C108.537,368.584,129.563,321.26,163.748,287.081L163.748,287.081z'/></g></svg>"); 
          }
          else if (arrow_type == 4) {
            $t.find('.slick-prev').append("<svg version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><path fill='#111' d='M502.87,4.198l18.004,18.585L130.676,412.98c-4.66,4.642-4.66,12.192,0,16.834l390.198,390.197 l-18.004,18.583c-4.64,4.062-12.202,4.062-16.263,0L77.246,429.814c-4.06-4.642-4.06-12.192,0-16.834L486.608,4.198 C490.668-0.442,498.23-0.442,502.87,4.198L502.87,4.198z'/></svg>"); 
            $t.find('.slick-next').append("<svg transform='rotate(180)' version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><path fill='#111' d='M502.87,4.198l18.004,18.585L130.676,412.98c-4.66,4.642-4.66,12.192,0,16.834l390.198,390.197 l-18.004,18.583c-4.64,4.062-12.202,4.062-16.263,0L77.246,429.814c-4.06-4.642-4.06-12.192,0-16.834L486.608,4.198 C490.668-0.442,498.23-0.442,502.87,4.198L502.87,4.198z'/></svg>"); 
          }
          else if (arrow_type == 5) {
            $t.find('.slick-prev').append("<svg version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><polygon fill='#111' points='316.614,421.157 538.593,692.345 56.703,421.157 538.593,149.607 '/></svg>"); 
            $t.find('.slick-next').append("<svg transform='rotate(180)' version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><polygon fill='#111' points='316.614,421.157 538.593,692.345 56.703,421.157 538.593,149.607 '/></svg>"); 
          }
          else if (arrow_type == 6) { 
            $t.find('.slick-prev').append("<svg version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><path fill='#111' d='M239.809,606.063L58.266,424.535c-2.085-1.682-2.085-5.019,0-7.104l181.542-181.542 c2.085-2.085,5.005-2.085,7.089,0l23.378,23.378l-143.156,143.14h391.037c11.271,0,20.458,9.188,20.458,20.445l0,0 c0,10.855-9.186,20.041-20.458,20.041H130.47l139.805,139.807l-23.378,23.363C244.813,608.148,241.893,608.148,239.809,606.063 L239.809,606.063z'/></svg>"); 
            $t.find('.slick-next').append("<svg transform='rotate(180)' version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><path fill='#111' d='M239.809,606.063L58.266,424.535c-2.085-1.682-2.085-5.019,0-7.104l181.542-181.542 c2.085-2.085,5.005-2.085,7.089,0l23.378,23.378l-143.156,143.14h391.037c11.271,0,20.458,9.188,20.458,20.445l0,0 c0,10.855-9.186,20.041-20.458,20.041H130.47l139.805,139.807l-23.378,23.363C244.813,608.148,241.893,608.148,239.809,606.063 L239.809,606.063z'/></svg>"); 
          }
          else if (arrow_type == 7) {
            $t.find('.slick-prev').append("<svg version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><polygon fill='#111' points='278.131,644.671 538.593,644.027 315.227,424.743 538.593,197.219 282.062,197.865 56.716,423.257'/></svg>"); 
            $t.find('.slick-next').append("<svg transform='rotate(180)' version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><polygon fill='#111' points='278.131,644.671 538.593,644.027 315.227,424.743 538.593,197.219 282.062,197.865 56.716,423.257'/></svg>"); 
          }
          else if (arrow_type == 8) {
            $t.find('.slick-prev').append("<svg version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><path fill='#111' d='M433.538,667.31L304.604,415.752l128.934-251.571L56.703,415.753L433.538,667.31L433.538,667.31z M538.593,774.187l-61.476-353.21l61.476-353.273L358.895,420.975L538.593,774.187L538.593,774.187z'/></svg>"); 
            $t.find('.slick-next').append("<svg transform='rotate(180)' version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><path fill='#111' d='M433.538,667.31L304.604,415.752l128.934-251.571L56.703,415.753L433.538,667.31L433.538,667.31z M538.593,774.187l-61.476-353.21l61.476-353.273L358.895,420.975L538.593,774.187L538.593,774.187z'/></svg>"); 
          }
          else if (arrow_type == 9) {
            $t.find('.slick-prev').append("<svg version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><g><polygon fill='#111' points='334.474,596.275 538.593,595.771 363.545,423.922 538.593,245.615 337.555,246.122 160.956,422.757 	'/><polygon fill='#FFFFFF' points='230.197,596.275 280.343,596.146 106.953,422.757 283.552,246.122 233.279,246.122 56.678,422.757 '/></g></svg>"); 
            $t.find('.slick-next').append("<svg transform='rotate(180)' version='1.1' id='Calque_3' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 595.28 841.89' enable-background='new 0 0 595.28 841.89' xml:space='preserve'><g><polygon fill='#111' points='334.474,596.275 538.593,595.771 363.545,423.922 538.593,245.615 337.555,246.122 160.956,422.757 	'/><polygon fill='#FFFFFF' points='230.197,596.275 280.343,596.146 106.953,422.757 283.552,246.122 233.279,246.122 56.678,422.757 '/></g></svg>"); 
          }

        //  })

  //         if($('#yourID').css('display') == 'none')

  //         if($('#shopify-product-reviews .spr-form').css('display') == 'none'){
  //         $('.slick-arrow').css('display', 'none');           
  //         }

  //         if ($('#shopify-product-reviews').attr('data-titletag') == "1"){
  //           $('.spr-header-title').replaceWith(function() {
  //             return $("<h1>", {
  //               class: this.className      
  //             });
  //           });          
  //         } else if ($('#shopify-product-reviews').attr('data-titletag') == "2"){
  //           $('.spr-header-title').replaceWith(function() {
  //             return $("<h2>", {
  //               class: this.className      
  //             });
  //           });  
  //         } else if ($('#shopify-product-reviews').attr('data-titletag') == "3"){
  //           $('.spr-header-title').replaceWith(function() {
  //             return $("<h3>", {
  //               class: this.className      
  //             });
  //           });  
  //         } else if ($('#shopify-product-reviews').attr('data-titletag') == "4"){
  //           $('.spr-header-title').replaceWith(function() {
  //             return $("<h4>", {
  //               class: this.className      
  //             });
  //           });  
  //         } else if ($('#shopify-product-reviews').attr('data-titletag') == "5"){
  //           $('.spr-header-title').replaceWith(function() {
  //             return $("<h5>", {
  //               class: this.className      
  //             });
  //           });  
  //         } else if ($('#shopify-product-reviews').attr('data-titletag') == "6"){
  //           $('.spr-header-title').replaceWith(function() {
  //             return $("<h6>", {
  //               class: this.className      
  //             });
  //           });  
  //         } 

  //         $('.spr-header-title').text($('#shopify-product-reviews').attr('data-title')); 

  //          $(".slick-track").css("display", "flex");



        }

  // FE 03 End



    }

    $( document ).ready(function() {
      setTimeout(function(){
        if($('#shopify-product-reviews .spr-reviews .review_assets').length){
        var position_arrow = ($('#shopify-product-reviews .spr-reviews .review_assets').height() / 2) + $('#shopify-product-reviews .spr-reviews .review_assets').position().top; 
        $('#shopify-product-reviews .slick-arrow').css('top', position_arrow+'px');
        }
      }, 2000);   
    });
  }
  
  
  

  
