/*
Add you custom JavaScript code at this file.

1. Rename file from "custom-example.js" to "custom.js"
2. Enable custom JS at general settings -> developer section
3. Write your awesome JS code here.
 */

alert('Hi there!');
