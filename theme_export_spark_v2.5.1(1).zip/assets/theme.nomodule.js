System.register(['./theme-1f534762.nomodule.js'], (function () {
	'use strict';
	return {
		setters: [function () {}],
		execute: (function () {



		})
	};
}));
//# sourceMappingURL=theme.nomodule.js.map
